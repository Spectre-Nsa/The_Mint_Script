#!/usr/bin/env bash
# Local Policies — Linux Mint 21 / Ubuntu Jammy
# Safe to source from harden.sh; changes are limited to sudo policy and sysctl.
if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then set -euo pipefail; fi

LP_PASS=0 LP_FAIL=0
lp_pass(){ printf '[PASS] %s\n' "$*"; LP_PASS=$((LP_PASS+1)); }
lp_fail(){ printf '[FAIL] %s\n' "$*"; LP_FAIL=$((LP_FAIL+1)); }
lp_info(){ printf '[INFO] %s\n' "$*"; }
lp_backup(){
  local f="$1" stamp dest
  [[ -e "$f" ]] || return 0
  stamp=$(date +%Y%m%d_%H%M%S)_$$
  dest="${f}.${stamp}.bak"
  if cp -a -- "$f" "$dest"; then lp_info "Backup created: $dest"; else lp_fail "Could not back up $f"; return 1; fi
}

# Desired persistent and runtime sysctl values.
# IMPORTANT: writing net.ipv4.ip_forward changes the kernel's
# net.ipv4.conf.all.accept_redirects value automatically. Keep ip_forward
# before the explicit accept_redirects assignment in the list below.
lp_sysctl_pairs(){ cat <<'PAIRS'
net.ipv6.conf.all.accept_ra=0
net.ipv6.conf.all.accept_redirects=0
net.ipv6.conf.all.accept_source_route=0
net.ipv6.conf.all.forwarding=0
net.ipv6.conf.default.accept_ra=0
net.ipv6.conf.default.accept_redirects=0
net.ipv6.conf.default.accept_source_route=0
net.ipv4.ip_forward=0
net.ipv4.conf.all.accept_redirects=0
net.ipv4.conf.all.accept_source_route=0
net.ipv4.conf.all.log_martians=1
net.ipv4.conf.all.rp_filter=1
net.ipv4.conf.all.secure_redirects=0
net.ipv4.conf.all.send_redirects=0
net.ipv4.conf.default.accept_redirects=0
net.ipv4.conf.default.accept_source_route=0
net.ipv4.conf.default.log_martians=1
net.ipv4.conf.default.rp_filter=1
net.ipv4.conf.default.secure_redirects=0
net.ipv4.conf.default.send_redirects=0
net.ipv4.icmp_echo_ignore_broadcasts=1
net.ipv4.icmp_ignore_bogus_error_responses=1
net.ipv4.tcp_syncookies=1
fs.protected_hardlinks=1
fs.protected_symlinks=1
fs.suid_dumpable=0
kernel.randomize_va_space=2
PAIRS
}

# Find and neutralize only conflicting assignments for keys managed by this
# module. Original files are backed up; unrelated sysctl settings are kept.
lp_sysctl_clean_conflicts(){
  local desired_tmp count_tmp f real tmp changed total=0 errors=0 nullglob_was_set=0
  local -A seen=()
  shopt -q nullglob && nullglob_was_set=1 || true
  desired_tmp=$(mktemp) || { lp_fail 'Could not create sysctl comparison file.'; return 1; }
  count_tmp=$(mktemp) || { rm -f "$desired_tmp"; lp_fail 'Could not create sysctl counter file.'; return 1; }
  lp_sysctl_pairs > "$desired_tmp"

  shopt -s nullglob
  for f in /etc/sysctl.conf /etc/sysctl.d/*.conf; do
    [[ -f "$f" ]] || continue
    real=$(readlink -f -- "$f" 2>/dev/null || printf '%s' "$f")
    [[ -f "$real" ]] || continue
    [[ "$real" == /etc/sysctl.d/99-hardening.conf ]] && continue
    [[ -n "${seen[$real]+x}" ]] && continue
    seen[$real]=1

    tmp=$(mktemp "${real}.lp.XXXXXX") || { lp_fail "Could not create temporary file for $real."; errors=$((errors+1)); continue; }
    if ! awk -F= -v countfile="$count_tmp" '
      NR==FNR {
        k=$1; v=$2
        gsub(/^[[:space:]]+|[[:space:]]+$/, "", k)
        gsub(/^[[:space:]]+|[[:space:]]+$/, "", v)
        wanted[k]=v
        next
      }
      {
        original=$0
        if ($0 !~ /^[[:space:]]*#/ && index($0, "=") > 0) {
          split($0, part, "=")
          key=part[1]
          gsub(/[[:space:]]/, "", key)
          value=part[2]
          sub(/[[:space:]]*#.*/, "", value)
          gsub(/^[[:space:]]+|[[:space:]]+$/, "", value)
          if ((key in wanted) && value != wanted[key]) {
            print "# Disabled by Local Policy: expected " wanted[key] " for " key "; original: " original
            changed++
            next
          }
        }
        print original
      }
      END { print changed+0 > countfile }
    ' "$desired_tmp" "$real" > "$tmp"; then
      lp_fail "Could not read or process sysctl configuration $real."
      errors=$((errors+1))
      rm -f "$tmp"
      continue
    fi
    changed=$(cat "$count_tmp" 2>/dev/null || printf '0')
    if [[ "$changed" =~ ^[0-9]+$ ]] && (( changed > 0 )); then
      if lp_backup "$real" && install -o root -g root -m 0644 "$tmp" "$real"; then
        lp_info "Disabled $changed conflicting managed sysctl assignment(s) in $real; unrelated settings were preserved."
        total=$((total+changed))
      else
        lp_fail "Could not safely update conflicting assignments in $real."
        errors=$((errors+1))
      fi
    fi
    rm -f "$tmp"
  done
  if (( nullglob_was_set == 0 )); then shopt -u nullglob; fi
  rm -f "$desired_tmp" "$count_tmp"
  if (( total == 0 )); then lp_info 'No conflicting managed sysctl assignments needed to be changed in /etc/sysctl.conf or /etc/sysctl.d/.'; fi
  (( errors == 0 ))
}

lp_sysctl_persist_and_reload(){
  local config=/etc/sysctl.d/99-hardening.conf tmp key value actual failures=0
  mkdir -p /etc/sysctl.d || { lp_fail 'Could not create /etc/sysctl.d.'; return 1; }
  lp_backup "$config" || return 1
  tmp=$(mktemp) || return 1
  lp_sysctl_pairs > "$tmp"
  if ! install -o root -g root -m 0644 "$tmp" "$config"; then rm -f "$tmp"; lp_fail "Could not install $config"; return 1; fi
  rm -f "$tmp"
  lp_info "Persistent sysctl policy written to $config."

  if ! lp_sysctl_clean_conflicts; then lp_fail 'Could not clean all detected sysctl conflicts.'; fi

  if sysctl --system >/tmp/lp-sysctl-reload.log 2>&1; then lp_pass 'sysctl --system completed.'; else lp_fail 'sysctl --system reported errors; see /tmp/lp-sysctl-reload.log'; cat /tmp/lp-sysctl-reload.log; fi

  # Re-assert the managed values after the persistent reload. This catches
  # settings changed by later-loaded sources or service-side sysctl writes.
  local apply_failures=0
  while IFS='=' read -r key value; do
    if ! sysctl -w "$key=$value" >/dev/null 2>&1; then
      lp_fail "Could not apply runtime sysctl value $key=$value."
      apply_failures=$((apply_failures+1))
    fi
  done < <(lp_sysctl_pairs)
  if (( apply_failures == 0 )); then lp_pass 'Re-applied all managed sysctl values to the running kernel.'; fi

  while IFS='=' read -r key value; do
    actual=$(sysctl -n "$key" 2>/dev/null || printf 'UNAVAILABLE')
    if [[ "$actual" == "$value" ]]; then lp_pass "$key=$actual"; else lp_fail "$key expected $value, effective value is $actual (review remaining overrides or kernel support)."; failures=$((failures+1)); fi
  done < <(lp_sysctl_pairs)
  (( failures == 0 ))
}

# Remove only clearly unsafe broad sudo rules and environment/authentication
# overrides. Do not wipe sudoers.d or invent access for unknown users.
lp_sudo_harden_main(){
  local file=/etc/sudoers tmp
  [[ -f "$file" ]] || { lp_fail '/etc/sudoers is missing.'; return 1; }
  tmp=$(mktemp /etc/sudoers.lp.XXXXXX) || { lp_fail 'Could not create temporary sudoers file.'; return 1; }
  awk '
    /^[[:space:]]*#/ { print; next }
    {
      original=$0
      active=$0
      sub(/[[:space:]]+#.*/, "", active)
      reason=""
      if (active ~ /^[[:space:]]*Defaults[[:space:]]+!authenticate([[:space:]]|$)/) reason="global password authentication disabled"
      else if (active ~ /^[[:space:]]*Defaults/ && active ~ /env_keep/ && (active ~ /LD_PRELOAD/ || active ~ /LD_LIBRARY_PATH/ || active ~ /HOME/)) reason="unsafe environment variable preservation"
      else if (active ~ /^[[:space:]]*Defaults[[:space:]]+!secure_path([[:space:]]|$)/) reason="secure_path explicitly disabled"
      else if (active ~ /^[[:space:]]*Defaults[[:space:]]+!tty_tickets([[:space:]]|$)/) reason="shared sudo timestamp tickets enabled"
      else if (active ~ /^[[:space:]]*Defaults[[:space:]]+!logfile([[:space:]]|$)/) reason="sudo logfile setting explicitly disabled"
      else if (active ~ /^[[:space:]]*Defaults[[:space:]]+!requiretty([[:space:]]|$)/) reason="legacy tty requirement override removed"
      else if (active ~ /^[[:space:]]*ALL[[:space:]]+ALL[[:space:]]*=[[:space:]]*\(ALL\)[[:space:]]+ALL[[:space:]]*$/) reason="unrestricted sudo grant to every local account"
      else if (active ~ /^[[:space:]]*root[[:space:]]+ALL[[:space:]]*=[[:space:]]*\(ALL\)[[:space:]]+NOPASSWD:[[:space:]]*ALL[[:space:]]*$/) reason="unneeded passwordless sudo rule for root"
      else if (active ~ /^[[:space:]]*%sudo[[:space:]]+ALL[[:space:]]*=[[:space:]]*\(ALL\)[[:space:]]+NOPASSWD:[[:space:]]*ALL[[:space:]]*$/) {
        print "%sudo ALL=(ALL:ALL) ALL  # Local Policy: require authentication for sudo-group administrators"
        changed++
        next
      }
      if (reason != "") {
        print "# Disabled by Local Policy (" reason "): " original
        changed++
        next
      }
      print original
    }
    END { if (changed > 0) print "[INFO] Hardened " changed " unsafe sudoers entry/entries in the main file." > "/dev/stderr"; else print "[INFO] No targeted unsafe sudoers entries found in the main file." > "/dev/stderr" }
  ' "$file" > "$tmp" || { rm -f "$tmp"; lp_fail 'Could not process /etc/sudoers.'; return 1; }

  # Add a normal authenticated sudo-group grant only if no full authenticated
  # grant is already present. Existing restricted custom rules remain intact.
  if ! grep -Eq '^[[:space:]]*%sudo[[:space:]]+ALL[[:space:]]*=[[:space:]]*\(ALL(:ALL)?\)[[:space:]]+ALL([[:space:]]|$)' "$tmp"; then
    printf '\n# Local Policy: standard authenticated administrator access\n%%sudo ALL=(ALL:ALL) ALL\n' >> "$tmp"
    lp_info 'Added standard authenticated sudo-group administrator rule.'
  fi
  chmod 0440 "$tmp"
  if ! visudo -cf "$tmp" >/tmp/lp-visudo-temp.log 2>&1; then
    lp_fail 'Sanitized sudoers candidate failed validation; original file left untouched.'
    cat /tmp/lp-visudo-temp.log
    rm -f "$tmp"
    return 1
  fi
  if ! cmp -s "$file" "$tmp"; then
    if install -o root -g root -m 0440 "$tmp" "$file"; then
      lp_pass 'Applied targeted sudoers hardening; the original policy is backed up.'
    else
      lp_fail 'Could not install sanitized /etc/sudoers.'
      rm -f "$tmp"
      return 1
    fi
  else
    lp_info 'Main sudoers file already contains the targeted hardening changes.'
  fi
  rm -f "$tmp"
}

lp_sudo_review_dropins(){
  local f line found=0
  while IFS= read -r -d '' f; do
    [[ -f "$f" && -r "$f" ]] || continue
    while IFS= read -r line; do
      [[ "$line" =~ ^[[:space:]]*# ]] && continue
      if [[ "$line" =~ NOPASSWD: ]] || [[ "$line" =~ !authenticate ]] || [[ "$line" =~ LD_PRELOAD ]] || [[ "$line" =~ LD_LIBRARY_PATH ]] || [[ "$line" =~ ^[[:space:]]*ALL[[:space:]]+ALL[[:space:]]*= ]]; then
        lp_fail "Potentially unsafe custom sudoers rule needs review: $f: $line"
        found=1
      fi
    done < "$f"
  done < <(find /etc/sudoers.d -maxdepth 1 -type f -print0 2>/dev/null)
  (( found == 0 )) && lp_pass 'No targeted passwordless, global-authentication, or all-user sudo rules found in sudoers.d.'
  return 0
}

lp_secure_sudo(){
  [[ ${EUID:-$(id -u)} -eq 0 ]] || { lp_fail 'Sudo repair must run as root.'; return 1; }
  local backup_dir stamp f sudo_group_members=() admin_fail=0 user
  stamp=$(date +%Y%m%d_%H%M%S)_$$
  backup_dir="/var/backups/sudo-before-local-policy-$stamp"
  mkdir -p -m 0700 "$backup_dir" || { lp_fail 'Cannot create sudo backup directory.'; return 1; }

  mkdir -p /etc/sudoers.d || { lp_fail 'Could not ensure /etc/sudoers.d exists.'; return 1; }
  cp -a /etc/sudoers "$backup_dir/sudoers" 2>/dev/null || { lp_fail 'Could not back up /etc/sudoers.'; return 1; }
  mkdir -p "$backup_dir/sudoers.d"
  cp -a /etc/sudoers.d/. "$backup_dir/sudoers.d/" 2>/dev/null || true
  lp_info "Complete sudoers backup: $backup_dir"

  lp_info 'Existing sudo policy inventory (review; custom files are preserved):'
  if [[ -r /etc/sudoers ]]; then nl -ba /etc/sudoers; fi
  while IFS= read -r -d '' f; do
    printf '\n--- %s ---\n' "$f"; nl -ba "$f" 2>/dev/null || true
  done < <(find /etc/sudoers.d -maxdepth 1 -type f -print0 2>/dev/null | sort -z)

  if getent group sudo >/dev/null; then
    IFS=, read -r -a sudo_group_members <<< "$(getent group sudo | awk -F: '{print $4}')"
    lp_info "Existing sudo-group members: ${sudo_group_members[*]:-(none)}"
  fi

  if dpkg-query -W -f='${Status}' sudo 2>/dev/null | grep -q '^install ok installed$'; then
    if DEBIAN_FRONTEND=noninteractive apt-get install --reinstall -y sudo; then lp_pass 'Sudo package reinstalled.'; else lp_fail 'Sudo package reinstallation failed.'; return 1; fi
  else
    if DEBIAN_FRONTEND=noninteractive apt-get install -y sudo; then lp_pass 'Sudo package installed.'; else lp_fail 'Sudo package installation failed.'; return 1; fi
  fi

  if [[ ! -x /usr/bin/sudo ]]; then lp_fail '/usr/bin/sudo is missing or not executable.'; return 1; fi
  if chmod 0440 /etc/sudoers; then lp_pass 'Corrected /etc/sudoers permissions to 0440.'; else lp_fail 'Could not correct /etc/sudoers permissions.'; fi
  while IFS= read -r -d '' f; do chmod 0440 "$f" 2>/dev/null || lp_fail "Could not set secure permissions on $f"; done < <(find /etc/sudoers.d -maxdepth 1 -type f -print0 2>/dev/null)

  if ! lp_sudo_harden_main; then lp_fail 'Main sudoers hardening did not complete.'; return 1; fi
  lp_sudo_review_dropins

  if visudo -c >/tmp/lp-visudo-after.log 2>&1; then lp_pass 'Final sudoers main file and included files pass visudo -c.'; else lp_fail 'Final sudoers validation failed; see output below.'; cat /tmp/lp-visudo-after.log; return 1; fi

  if ((${#sudo_group_members[@]})); then
    for user in "${sudo_group_members[@]}"; do
      [[ -n "$user" ]] || continue
      if id "$user" >/dev/null 2>&1 && sudo -l -U "$user" >/tmp/lp-sudo-list-$$ 2>&1; then
        if grep -qE '\([[:space:]]*ALL([[:space:]]*:[[:space:]]*ALL)?[[:space:]]*\)[[:space:]]+(NOPASSWD:[[:space:]]*)?ALL' /tmp/lp-sudo-list-$$; then
          lp_pass "Administrator sudo access verified for $user."
        else
          lp_fail "Could not confirm full administrator sudo access for $user; inspect sudo -l -U output."
          cat /tmp/lp-sudo-list-$$
          admin_fail=1
        fi
      else
        lp_fail "Could not query sudo privileges for $user."
        admin_fail=1
      fi
    done
  else
    lp_info 'No explicit sudo-group members were listed; no human administrator could be tested from this group.'
  fi
  rm -f /tmp/lp-sudo-list-$$
  (( admin_fail == 0 ))
}

invoke_local_policy(){
  LP_PASS=0; LP_FAIL=0
  printf '\n============================================================\n[Local Policy] Applying and verifying local policies\n============================================================\n'
  if ! lp_secure_sudo; then lp_info 'Sudo hardening/verification requires review.'; fi
  if ! lp_sysctl_persist_and_reload; then lp_info 'One or more sysctl checks failed; review the reported effective values and overrides.'; fi
  printf '\n---------------- Local Policy Results ----------------\n'
  printf '[PASS] Successful checks: %s\n' "$LP_PASS"
  printf '[FAIL] Failed checks:     %s\n' "$LP_FAIL"
  if (( LP_FAIL == 0 )); then lp_pass 'Local Policy completed; all implemented checks passed.'; else lp_fail 'Local Policy completed with failures. Review before considering the machine hardened.'; fi
  return $(( LP_FAIL > 0 ))
}
