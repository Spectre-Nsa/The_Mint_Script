#!/usr/bin/env bash

# Account Policy module for Linux Mint / Ubuntu PAM layouts.
# When sourced by harden.sh, this file does not alter the caller's shell options.
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  set -euo pipefail
fi

# -------------------------------------------------------------------
# Reporting / common helpers
# -------------------------------------------------------------------
ap_policy_pass () { printf '\033[32m[PASS]\033[0m %s\n' "$*"; }
ap_policy_fail () { printf '\033[31m[FAIL]\033[0m %s\n' "$*" >&2; }
ap_policy_warn () { printf '\033[33m[WARN]\033[0m %s\n' "$*"; }
ap_policy_info () { printf '[INFO] %s\n' "$*"; }

ap_policy_backup () {
  local file="$1" stamp backup
  [[ -f "$file" ]] || return 1
  stamp=$(date +%Y%m%d_%H%M%S_%N)
  backup="${file}.${stamp}.bak"
  sudo cp -a -- "$file" "$backup" || return 1
  ap_policy_info "Backup created: $backup"
}

# Install a generated temporary file while preserving the target's owner,
# group, and mode. The temporary file must already exist.
ap_policy_install_preserving_metadata () {
  local tmp="$1" target="$2" owner group mode
  owner=$(stat -c '%u' "$target") || return 1
  group=$(stat -c '%g' "$target") || return 1
  mode=$(stat -c '%a' "$target") || return 1
  sudo install -o "$owner" -g "$group" -m "$mode" -- "$tmp" "$target"
}

ap_pam_module_exists () {
  local module="$1"
  find -L /lib /usr/lib -type f -name "$module" -print -quit 2>/dev/null | grep -q .
}

ap_policy_run_step () {
  local label="$1" function_name="$2"
  if "$function_name"; then
    AP_POLICY_PASS_COUNT=$((AP_POLICY_PASS_COUNT + 1))
    ap_policy_pass "$label"
  else
    AP_POLICY_FAIL_COUNT=$((AP_POLICY_FAIL_COUNT + 1))
    ap_policy_fail "$label"
  fi
}

# Return success only when dpkg reports the package fully installed.
ap_package_installed () {
  local package="$1" status
  status=$(dpkg-query -W -f='${Status}' "$package" 2>/dev/null || true)
  [[ "$status" == 'install ok installed' ]]
}

# Check the PAM shared objects this module intends to use. If a module is
# missing, map it to its Mint/Ubuntu package and offer a guarded APT install
# or reinstall. No PAM configuration is edited by this preflight.
ap_ensure_pam_modules () {
  local module package reply
  local install_pwquality=0 reinstall_pwquality=0
  local install_pam_modules=0 reinstall_pam_modules=0
  local -a missing_modules=() to_install=() to_reinstall=()

  if ! command -v dpkg-query >/dev/null 2>&1; then
    ap_policy_fail 'dpkg-query is unavailable; cannot verify PAM package state.'
    return 1
  fi

  for module in pam_pwquality.so pam_pwhistory.so pam_unix.so pam_faillock.so; do
    if ap_pam_module_exists "$module"; then
      continue
    fi

    missing_modules+=("$module")
    case "$module" in
      pam_pwquality.so) package='libpam-pwquality' ;;
      pam_pwhistory.so|pam_unix.so|pam_faillock.so) package='libpam-modules' ;;
      *)
        ap_policy_fail "No package mapping is defined for missing PAM module $module."
        return 1
        ;;
    esac

    if ap_package_installed "$package"; then
      if [[ "$package" == 'libpam-pwquality' ]]; then
        reinstall_pwquality=1
      else
        reinstall_pam_modules=1
      fi
    else
      if [[ "$package" == 'libpam-pwquality' ]]; then
        install_pwquality=1
      else
        install_pam_modules=1
      fi
    fi
  done

  if ((${#missing_modules[@]} == 0)); then
    ap_policy_info 'All required PAM module files are present: pwquality, pwhistory, unix, and faillock.'
    return 0
  fi

  ap_policy_warn 'One or more required PAM module files are missing:'
  for module in "${missing_modules[@]}"; do
    case "$module" in
      pam_pwquality.so) package='libpam-pwquality' ;;
      *) package='libpam-modules' ;;
    esac
    printf '  - %s (provided by %s)\n' "$module" "$package"
  done

  if (( install_pwquality )); then to_install+=('libpam-pwquality'); fi
  if (( install_pam_modules )); then to_install+=('libpam-modules'); fi
  if (( reinstall_pwquality )); then to_reinstall+=('libpam-pwquality'); fi
  if (( reinstall_pam_modules )); then to_reinstall+=('libpam-modules'); fi

  if ((${#to_install[@]})); then
    ap_policy_info "Package(s) to install: ${to_install[*]}"
  fi
  if ((${#to_reinstall[@]})); then
    ap_policy_info "Package(s) to reinstall because module files are missing: ${to_reinstall[*]}"
  fi

  if ! command -v apt-get >/dev/null 2>&1; then
    ap_policy_fail 'apt-get is unavailable; cannot install missing PAM modules.'
    return 1
  fi

  if ! read -r -p '[PROMPT] Install/repair the missing PAM package(s) now? [y/N] ' reply; then
    ap_policy_fail 'Could not read the PAM package-install confirmation.'
    return 1
  fi
  case "$reply" in
    y|Y|yes|YES|Yes) ;;
    *)
      ap_policy_warn 'PAM package installation declined. Dependent PAM configuration steps will not modify their files.'
      return 1
      ;;
  esac

  # Avoid removing packages or upgrading unrelated installed packages during
  # this focused dependency repair. A pre-existing APT problem can still make
  # the operation fail; in that case the PAM stack is left untouched.
  if ((${#to_install[@]})); then
    ap_policy_info "Installing missing PAM package(s): ${to_install[*]}"
    if ! sudo env DEBIAN_FRONTEND=noninteractive apt-get install -y --no-remove --no-upgrade "${to_install[@]}"; then
      ap_policy_fail 'APT could not install the missing PAM package(s). No dependent PAM configuration files were changed.'
      return 1
    fi
  fi

  if ((${#to_reinstall[@]})); then
    ap_policy_info "Reinstalling PAM package(s): ${to_reinstall[*]}"
    if ! sudo env DEBIAN_FRONTEND=noninteractive apt-get install --reinstall -y --no-remove --no-upgrade "${to_reinstall[@]}"; then
      ap_policy_fail 'APT could not reinstall the PAM package(s). No dependent PAM configuration files were changed.'
      return 1
    fi
  fi

  local still_missing=0
  for module in "${missing_modules[@]}"; do
    if ! ap_pam_module_exists "$module"; then
      ap_policy_fail "PAM module $module is still missing after the package operation."
      still_missing=1
    else
      ap_policy_info "Verified module file is now present: $module"
    fi
  done

  if (( still_missing )); then
    return 1
  fi

  ap_policy_info 'All previously missing PAM module files are now present.'
  return 0
}

# -------------------------------------------------------------------
# Entry point
# -------------------------------------------------------------------
invoke_account_policy () {
  AP_POLICY_PASS_COUNT=0
  AP_POLICY_FAIL_COUNT=0

  printf '\n%s\n' '============================================================'
  printf '%s\n' '[Account Policy] Applying and verifying password policies'
  printf '%s\n' '============================================================'

  # Resolve missing PAM module dependencies before modifying PAM files.
  # A failed/declined package operation must not leave a partial password stack.
  ap_policy_run_step 'Required PAM module availability' ap_ensure_pam_modules

  ap_policy_run_step '/etc/login.defs defaults (60 / 10 / 7)' ap_secure_login_defs
  ap_policy_run_step 'PAM password stack (pwquality / pwhistory / pam_unix)' ap_pam_password_stack
  ap_policy_run_step '/etc/security/pwquality.conf settings' ap_pwquality_conf_file
  ap_policy_run_step 'Null-password options removed from common-auth' ap_remove_nullok
  ap_policy_run_step 'PAM faillock stack retained and verified' ap_lockout_faillock

  printf '\n%s\n' '---------------- Account Policy Results ----------------'
  printf '\033[32m[PASS]\033[0m Successful checks: %s\n' "$AP_POLICY_PASS_COUNT"
  printf '\033[31m[FAIL]\033[0m Failed checks:     %s\n' "$AP_POLICY_FAIL_COUNT"

  if (( AP_POLICY_FAIL_COUNT == 0 )); then
    ap_policy_pass 'Account Policy completed; all implemented checks passed.'
    return 0
  fi

  ap_policy_fail 'Account Policy completed with failures. Review the messages above before considering the machine hardened.'
  return 1
}

# -------------------------------------------------------------------
# /etc/login.defs hardening and persistence verification
# -------------------------------------------------------------------
ap_secure_login_defs () {
  local file='/etc/login.defs' tmp
  [[ -f "$file" ]] || { ap_policy_fail "$file is missing."; return 1; }

  ap_policy_backup "$file" || { ap_policy_fail "Could not back up $file."; return 1; }
  tmp=$(mktemp) || return 1

  if ! awk '
    BEGIN {
      values["PASS_MAX_DAYS"] = "60"
      values["PASS_MIN_DAYS"] = "10"
      values["PASS_WARN_AGE"] = "7"
      values["UMASK"] = "077"
    }
    /^[[:space:]]*#/ || /^[[:space:]]*$/ { print; next }
    {
      key = $1
      if (key in values) {
        if (!seen[key]++) print key, values[key]
        next
      }
      print
    }
    END {
      if (!seen["PASS_MAX_DAYS"]) print "PASS_MAX_DAYS 60"
      if (!seen["PASS_MIN_DAYS"]) print "PASS_MIN_DAYS 10"
      if (!seen["PASS_WARN_AGE"]) print "PASS_WARN_AGE 7"
      if (!seen["UMASK"]) print "UMASK 077"
    }
  ' "$file" > "$tmp"; then
    rm -f "$tmp"
    ap_policy_fail "Could not prepare $file."
    return 1
  fi

  if ! ap_policy_install_preserving_metadata "$tmp" "$file"; then
    rm -f "$tmp"
    ap_policy_fail "Could not write $file."
    return 1
  fi
  rm -f "$tmp"

  if sudo awk '
    /^[[:space:]]*#/ || /^[[:space:]]*$/ { next }
    $1 == "PASS_MAX_DAYS" { nmax++; vmax=$2 }
    $1 == "PASS_MIN_DAYS" { nmin++; vmin=$2 }
    $1 == "PASS_WARN_AGE" { nwarn++; vwarn=$2 }
    END {
      if (nmax != 1 || vmax != 60 || nmin != 1 || vmin != 10 || nwarn != 1 || vwarn != 7) exit 1
    }
  ' "$file"; then
    ap_policy_pass 'Verified PASS_MAX_DAYS=60, PASS_MIN_DAYS=10, and PASS_WARN_AGE=7 persist exactly once.'
    ap_policy_info 'login.defs supplies defaults for newly created accounts; existing accounts are governed by their current chage values.'
  else
    ap_policy_fail 'One or more login.defs values did not verify after writing.'
    return 1
  fi

  return 0
}

# -------------------------------------------------------------------
# Configure password stack:
#   pam_pwquality -> pam_pwhistory -> pam_unix
# Existing pam_unix control expression and unrelated options are preserved.
# -------------------------------------------------------------------
ap_pam_password_stack () {
  local file='/etc/pam.d/common-password' tmp
  local have_pwquality=1 have_pwhistory=1
  local -a missing_modules=()

  [[ -f "$file" ]] || { ap_policy_fail "$file is missing."; return 1; }

  # Require the complete module set before changing common-password. This
  # prevents the old partial-configuration behavior when one module is absent.
  local module
  for module in pam_pwquality.so pam_pwhistory.so pam_unix.so; do
    if ! ap_pam_module_exists "$module"; then
      missing_modules+=("$module")
    fi
  done
  if ((${#missing_modules[@]})); then
    ap_policy_fail "Required PAM module(s) are unavailable: ${missing_modules[*]}. No changes were made to $file."
    return 1
  fi

  # Ensure there is a pam_unix password rule before making any edits.
  if ! grep -Eq '^[[:space:]]*password[[:space:]].*pam_unix\.so([[:space:]]|$)' "$file"; then
    ap_policy_fail "Could not find an active password pam_unix.so rule in $file; leaving the PAM stack unchanged."
    return 1
  fi

  ap_policy_backup "$file" || { ap_policy_fail "Could not back up $file."; return 1; }
  tmp=$(mktemp) || return 1

  if ! awk -v have_pwquality="$have_pwquality" -v have_pwhistory="$have_pwhistory" '
    function add_extra(target, line,    clean,n,a,i) {
      clean = line
      sub(/^[[:space:]]+/, "", clean)
      sub(/[[:space:]]+#.*/, "", clean)
      n = split(clean, a, /[[:space:]]+/)
      for (i = 4; i <= n; i++) {
        if (target == "pwquality") {
          if (a[i] !~ /^(retry|minlen|difok|ucredit|lcredit|dcredit|ocredit)=/) {
            if (a[i] != "") pwquality_extra = pwquality_extra " " a[i]
          }
        } else {
          if (a[i] !~ /^(remember)=/ && a[i] != "use_authtok") {
            if (a[i] != "") pwhistory_extra = pwhistory_extra " " a[i]
          }
        }
      }
    }
    function fix_unix(line,    comment) {
      comment = ""
      if (match(line, /[[:space:]]+#/)) {
        comment = substr(line, RSTART)
        line = substr(line, 1, RSTART - 1)
      }
      gsub(/[[:space:]]yescrypt([[:space:]]|$)/, " ", line)
      gsub(/[[:space:]]try_first_pass([[:space:]]|$)/, " ", line)
      gsub(/[[:space:]]use_authtok([[:space:]]|$)/, " ", line)
      gsub(/[[:space:]]obscure([[:space:]]|$)/, " ", line)
      sub(/[[:space:]]+$/, "", line)
      return line " yescrypt try_first_pass use_authtok obscure" comment
    }
    BEGIN { inserted = 0; unix_count = 0; pwquality_extra = ""; pwhistory_extra = "" }
    /^[[:space:]]*#/ { print; next }
    {
      if ($0 ~ /^[[:space:]]*password[[:space:]]/ && $0 ~ /pam_pwquality\.so/) {
        add_extra("pwquality", $0)
        next
      }
      if ($0 ~ /^[[:space:]]*password[[:space:]]/ && $0 ~ /pam_pwhistory\.so/) {
        add_extra("pwhistory", $0)
        next
      }
      if ($0 ~ /^[[:space:]]*password[[:space:]]/ && $0 ~ /pam_unix\.so([[:space:]]|$)/) {
        if (!inserted) {
          if (have_pwquality == 1) print "password requisite pam_pwquality.so retry=3 minlen=10 difok=5 ucredit=-1 lcredit=-1 dcredit=-1 ocredit=-1" pwquality_extra
          if (have_pwhistory == 1) print "password required pam_pwhistory.so remember=10 use_authtok" pwhistory_extra
          inserted = 1
        }
        print fix_unix($0)
        unix_count++
        next
      }
      print
    }
    END { if (!inserted || unix_count < 1) exit 2 }
  ' "$file" > "$tmp"; then
    rm -f "$tmp"
    ap_policy_fail "Could not safely construct the password stack in $file; original file was not replaced."
    return 1
  fi

  if ! ap_policy_install_preserving_metadata "$tmp" "$file"; then
    rm -f "$tmp"
    ap_policy_fail "Could not install the updated $file."
    return 1
  fi
  rm -f "$tmp"

  local verify_failed=0
  if (( have_pwquality )); then
    if grep -Eq '^[[:space:]]*password[[:space:]]+requisite[[:space:]]+pam_pwquality\.so([[:space:]].*)?minlen=10' "$file" \
      && grep -Eq '^[[:space:]]*password[[:space:]]+requisite[[:space:]]+pam_pwquality\.so.*difok=5' "$file" \
      && grep -Eq '^[[:space:]]*password[[:space:]]+requisite[[:space:]]+pam_pwquality\.so.*ucredit=-1.*lcredit=-1.*dcredit=-1.*ocredit=-1' "$file"; then
      ap_policy_pass 'pam_pwquality.so is installed and active in common-password with minlen=10, difok=5, and all four character-class requirements.'
    else
      ap_policy_fail 'pam_pwquality rule or required options failed post-write verification.'
      verify_failed=1
    fi
  fi

  if (( have_pwhistory )); then
    if grep -Eq '^[[:space:]]*password[[:space:]]+required[[:space:]]+pam_pwhistory\.so.*remember=10.*use_authtok' "$file"; then
      ap_policy_pass 'pam_pwhistory.so is active with remember=10 and use_authtok.'
    else
      ap_policy_fail 'pam_pwhistory rule failed post-write verification.'
      verify_failed=1
    fi
  fi

  if awk -v have_pwquality="$have_pwquality" -v have_pwhistory="$have_pwhistory" '
    /^[[:space:]]*#/ { next }
    /^[[:space:]]*password[[:space:]]/ && /pam_pwquality\.so/ && !pwq { pwq=NR }
    /^[[:space:]]*password[[:space:]]/ && /pam_pwhistory\.so/ && !hist { hist=NR }
    /^[[:space:]]*password[[:space:]]/ && /pam_unix\.so([[:space:]]|$)/ && !unix { unix=NR }
    END {
      if (!unix) exit 1
      if (have_pwquality && (!pwq || pwq >= unix)) exit 1
      if (have_pwhistory && (!hist || hist >= unix)) exit 1
      if (have_pwquality && have_pwhistory && pwq >= hist) exit 1
    }
  ' "$file"; then
    ap_policy_pass 'Verified available password modules are ordered before pam_unix; any missing module remains a reported failure.'
  else
    ap_policy_fail 'PAM password module order did not verify.'
    verify_failed=1
  fi

  if awk '
    /^[[:space:]]*#/ { next }
    /^[[:space:]]*password[[:space:]]/ && /pam_unix\.so([[:space:]]|$)/ {
      line=$0
      if (line !~ /(^|[[:space:]])yescrypt([[:space:]]|$)/) bad=1
      if (line !~ /(^|[[:space:]])try_first_pass([[:space:]]|$)/) bad=1
      if (line !~ /(^|[[:space:]])use_authtok([[:space:]]|$)/) bad=1
      if (line !~ /(^|[[:space:]])obscure([[:space:]]|$)/) bad=1
      found++
    }
    END { if (!found || bad) exit 1 }
  ' "$file"; then
    ap_policy_pass 'pam_unix.so password rule contains yescrypt, try_first_pass, use_authtok, and obscure.'
  else
    ap_policy_fail 'pam_unix.so required password options failed post-write verification.'
    verify_failed=1
  fi

  if (( verify_failed )); then
    return 1
  fi
  return 0
}

# -------------------------------------------------------------------
# /etc/security/pwquality.conf settings and verification
# -------------------------------------------------------------------
ap_pwquality_conf_file () {
  local file='/etc/security/pwquality.conf' tmp existed=0

  if ! ap_pam_module_exists 'pam_pwquality.so'; then
    ap_policy_fail 'pam_pwquality.so is unavailable; leaving pwquality.conf unchanged until libpam-pwquality is installed.'
    return 1
  fi

  if [[ -e "$file" ]]; then
    [[ -f "$file" ]] || { ap_policy_fail "$file exists but is not a regular file."; return 1; }
    existed=1
    ap_policy_backup "$file" || { ap_policy_fail "Could not back up $file."; return 1; }
  fi

  tmp=$(mktemp) || return 1
  if (( existed )); then
    if ! awk '
      BEGIN {
        values["minlen"] = "10"
        values["minclass"] = "2"
        values["maxrepeat"] = "2"
        values["maxclassrepeat"] = "6"
        values["lcredit"] = "-1"
        values["ucredit"] = "-1"
        values["dcredit"] = "-1"
        values["ocredit"] = "-1"
        values["maxsequence"] = "2"
        values["difok"] = "5"
        values["gecoscheck"] = "1"
      }
      /^[[:space:]]*#/ || /^[[:space:]]*$/ { print; next }
      {
        key = $1
        sub(/=.*/, "", key)
        if (key in values) {
          if (!seen[key]++) print key " = " values[key]
          next
        }
        print
      }
      END {
        if (!seen["minlen"]) print "minlen = 10"
        if (!seen["minclass"]) print "minclass = 2"
        if (!seen["maxrepeat"]) print "maxrepeat = 2"
        if (!seen["maxclassrepeat"]) print "maxclassrepeat = 6"
        if (!seen["lcredit"]) print "lcredit = -1"
        if (!seen["ucredit"]) print "ucredit = -1"
        if (!seen["dcredit"]) print "dcredit = -1"
        if (!seen["ocredit"]) print "ocredit = -1"
        if (!seen["maxsequence"]) print "maxsequence = 2"
        if (!seen["difok"]) print "difok = 5"
        if (!seen["gecoscheck"]) print "gecoscheck = 1"
      }
    ' "$file" > "$tmp"; then
      rm -f "$tmp"
      ap_policy_fail "Could not prepare $file."
      return 1
    fi
    if ! ap_policy_install_preserving_metadata "$tmp" "$file"; then
      rm -f "$tmp"
      ap_policy_fail "Could not write $file."
      return 1
    fi
  else
    cat > "$tmp" <<'SETTINGS'
# Managed by the Linux competition Account Policy module.
minlen = 10
minclass = 2
maxrepeat = 2
maxclassrepeat = 6
lcredit = -1
ucredit = -1
dcredit = -1
ocredit = -1
maxsequence = 2
difok = 5
gecoscheck = 1
SETTINGS
    if ! sudo install -o root -g root -m 0644 -- "$tmp" "$file"; then
      rm -f "$tmp"
      ap_policy_fail "Could not create $file."
      return 1
    fi
  fi
  rm -f "$tmp"

  if sudo awk '
    /^[[:space:]]*#/ || /^[[:space:]]*$/ { next }
    {
      key=$1; sub(/=.*/, "", key)
      value=$0; sub(/^[^=]*=[[:space:]]*/, "", value); gsub(/[[:space:]]+$/, "", value)
      if (key in expected) { count[key]++; actual[key]=value }
    }
    BEGIN {
      expected["minlen"]="10"; expected["minclass"]="2"
      expected["maxrepeat"]="2"; expected["maxclassrepeat"]="6"
      expected["lcredit"]="-1"; expected["ucredit"]="-1"
      expected["dcredit"]="-1"; expected["ocredit"]="-1"
      expected["maxsequence"]="2"; expected["difok"]="5"
      expected["gecoscheck"]="1"
    }
    END {
      for (key in expected) if (count[key] != 1 || actual[key] != expected[key]) exit 1
    }
  ' "$file"; then
    ap_policy_pass 'Verified minlen=10, difok=5, minclass, repeat/sequence limits, four character credits, and gecoscheck.'
    return 0
  fi

  ap_policy_fail 'pwquality.conf did not retain all required values exactly once.'
  return 1
}

# -------------------------------------------------------------------
# Remove nullok / nullok_secure from common-auth and verify no active
# authentication rule in /etc/pam.d continues to request null passwords.
# -------------------------------------------------------------------
ap_remove_nullok () {
  local file='/etc/pam.d/common-auth' tmp
  [[ -f "$file" ]] || { ap_policy_fail "$file is missing."; return 1; }

  if ! awk '
    /^[[:space:]]*#/ { next }
    /(^|[[:space:]])nullok(_secure)?([[:space:]]|$)/ { found=1 }
    END { exit !found }
  ' "$file"; then
    ap_policy_pass 'No active nullok or nullok_secure option found in common-auth.'
  else
    ap_policy_backup "$file" || { ap_policy_fail "Could not back up $file."; return 1; }
    tmp=$(mktemp) || return 1
    if ! awk '
      /^[[:space:]]*#/ { print; next }
      {
        line=$0
        while (match(line, /(^|[[:space:]])nullok(_secure)?([[:space:]]|$)/)) {
          prefix=substr(line, 1, RSTART - 1)
          hit=substr(line, RSTART, RLENGTH)
          suffix=substr(line, RSTART + RLENGTH)
          lead=(hit ~ /^[[:space:]]/) ? " " : ""
          line=prefix lead suffix
        }
        print line
      }
    ' "$file" > "$tmp"; then
      rm -f "$tmp"
      ap_policy_fail "Could not prepare $file for null-password cleanup."
      return 1
    fi
    if ! ap_policy_install_preserving_metadata "$tmp" "$file"; then
      rm -f "$tmp"
      ap_policy_fail "Could not write $file."
      return 1
    fi
    rm -f "$tmp"
  fi

  if awk '
    /^[[:space:]]*#/ { next }
    /(^|[[:space:]])nullok(_secure)?([[:space:]]|$)/ { bad=1 }
    END { if (bad) exit 1 }
  ' "$file"; then
    ap_policy_pass 'Verified common-auth contains no active nullok/nullok_secure option.'
  else
    ap_policy_fail 'A nullok/nullok_secure option remains in common-auth.'
    return 1
  fi

  # Catch an alternate active auth rule elsewhere in the PAM configuration.
  # Do not rewrite unrelated service files automatically; surface the path.
  local other_hits
  other_hits=$(find /etc/pam.d -maxdepth 1 -type f ! -name '*.bak' ! -name '*~' -print0 2>/dev/null | xargs -0 -r awk '
    FNR == 1 { file=FILENAME }
    /^[[:space:]]*#/ { next }
    /^[[:space:]]*auth[[:space:]]/ && /pam_unix\.so/ && /(^|[[:space:]])nullok(_secure)?([[:space:]]|$)/ {
      print file ":" FNR ":" $0
    }
  ' 2>/dev/null || true)
  if [[ -n "$other_hits" ]]; then
    ap_policy_fail 'Another active PAM auth rule still permits null passwords:'
    printf '%s\n' "$other_hits" >&2
    return 1
  fi

  ap_policy_pass 'No active pam_unix auth rule under /etc/pam.d permits null passwords.'
  return 0
}

# -------------------------------------------------------------------
# Retain / construct pam_faillock in common-auth/common-account, preserving
# the pam_unix success=N jump and checking the final rule order.
# -------------------------------------------------------------------
ap_lockout_faillock () {
  local auth_file='/etc/pam.d/common-auth'
  local account_file='/etc/pam.d/common-account'
  local timestamp pam_unix_line success_skip tmp_auth tmp_account

  [[ -f "$auth_file" && -f "$account_file" ]] || {
    ap_policy_fail 'Required common-auth/common-account PAM files are missing.'
    return 1
  }
  if ! ap_pam_module_exists 'pam_faillock.so'; then
    ap_policy_fail 'pam_faillock.so is unavailable; common-auth/common-account were not changed.'
    return 1
  fi
  if ! ap_pam_module_exists 'pam_unix.so'; then
    ap_policy_fail 'pam_unix.so is unavailable; common-auth/common-account were not changed.'
    return 1
  fi

  pam_unix_line=$(grep -m1 -E '^[[:space:]]*auth[[:space:]]+\[[^]]*\][[:space:]]+pam_unix\.so([[:space:]]|$)' "$auth_file" || true)
  if [[ -z "$pam_unix_line" ]]; then
    ap_policy_fail 'Could not find the bracketed auth pam_unix.so rule needed to preserve the existing PAM jump; common-auth was not changed.'
    return 1
  fi
  if [[ "$pam_unix_line" =~ \[[^]]*success=([0-9]+)[^]]*\] ]]; then
    success_skip="${BASH_REMATCH[1]}"
  else
    ap_policy_fail 'Could not parse pam_unix success=N; common-auth was not changed.'
    return 1
  fi

  ap_policy_backup "$auth_file" || { ap_policy_fail "Could not back up $auth_file."; return 1; }
  ap_policy_backup "$account_file" || { ap_policy_fail "Could not back up $account_file."; return 1; }
  tmp_auth=$(mktemp) || return 1
  tmp_account=$(mktemp) || { rm -f "$tmp_auth"; return 1; }

  if ! awk -v success_skip="$success_skip" '
    BEGIN {
      found=0; succ_inserted=0
      remaining=success_skip-1
      if (remaining < 0) remaining=0
    }
    /^[[:space:]]*#/ { print; next }
    /^[[:space:]]*auth[[:space:]].*pam_faillock\.so.*preauth([[:space:]]|$)/ { next }
    /^[[:space:]]*auth[[:space:]].*pam_faillock\.so.*authfail([[:space:]]|$)/ { next }
    /^[[:space:]]*auth[[:space:]].*pam_faillock\.so.*authsucc([[:space:]]|$)/ { next }
    {
      if (!found && $0 ~ /^[[:space:]]*auth[[:space:]]+\[[^]]*\][[:space:]]+pam_unix\.so([[:space:]]|$)/) {
        print "auth required pam_faillock.so preauth"
        print
        print "auth [default=die] pam_faillock.so authfail"
        found=1
        next
      }
      if (found && !succ_inserted) {
        if ($0 ~ /^[[:space:]]*$/ || $0 ~ /^[[:space:]]*#/) { print; next }
        if (remaining == 0) {
          print "auth sufficient pam_faillock.so authsucc"
          succ_inserted=1
        } else {
          remaining--
        }
      }
      print
    }
    END { if (!found || !succ_inserted) exit 2 }
  ' "$auth_file" > "$tmp_auth"; then
    rm -f "$tmp_auth" "$tmp_account"
    ap_policy_fail 'Could not safely reconstruct the faillock auth stack; original PAM files were left in place.'
    return 1
  fi

  if ! awk '
    /^[[:space:]]*#/ { print; next }
    /^[[:space:]]*account[[:space:]].*pam_faillock\.so/ { next }
    { print }
    END { print "account required pam_faillock.so" }
  ' "$account_file" > "$tmp_account"; then
    rm -f "$tmp_auth" "$tmp_account"
    ap_policy_fail "Could not prepare $account_file."
    return 1
  fi

  # Both complete temporary files are ready before either is installed.
  if ! ap_policy_install_preserving_metadata "$tmp_auth" "$auth_file"; then
    rm -f "$tmp_auth" "$tmp_account"
    ap_policy_fail "Could not install updated $auth_file."
    return 1
  fi
  if ! ap_policy_install_preserving_metadata "$tmp_account" "$account_file"; then
    rm -f "$tmp_auth" "$tmp_account"
    ap_policy_fail "Could not install updated $account_file. Restore the timestamped backups if necessary."
    return 1
  fi
  rm -f "$tmp_auth" "$tmp_account"

  if awk '
    /^[[:space:]]*#/ { next }
    /^[[:space:]]*auth[[:space:]].*pam_faillock\.so.*preauth([[:space:]]|$)/ { pre=NR }
    /^[[:space:]]*auth[[:space:]]+\[[^]]*\][[:space:]]+pam_unix\.so([[:space:]]|$)/ { unix=NR }
    /^[[:space:]]*auth[[:space:]].*pam_faillock\.so.*authfail([[:space:]]|$)/ { fail=NR }
    /^[[:space:]]*auth[[:space:]].*pam_faillock\.so.*authsucc([[:space:]]|$)/ { succ=NR }
    END { if (!(pre && unix && fail && succ && pre < unix && unix < fail && fail < succ)) exit 1 }
  ' "$auth_file" && [[ $(grep -Ec '^[[:space:]]*account[[:space:]]+required[[:space:]]+pam_faillock\.so([[:space:]]|$)' "$account_file") -eq 1 ]]; then
    ap_policy_pass "Verified faillock preauth -> pam_unix (success=$success_skip) -> authfail/authsucc ordering and one required account rule."
    if [[ -f /etc/security/faillock.conf ]]; then
      ap_policy_info 'Existing /etc/security/faillock.conf retained; lockout thresholds continue to come from that file and pam_faillock defaults.'
    else
      ap_policy_info 'No /etc/security/faillock.conf found; pam_faillock module defaults remain in effect.'
    fi
    return 0
  fi

  ap_policy_fail 'faillock rules failed post-write ordering/count verification.'
  return 1
}
