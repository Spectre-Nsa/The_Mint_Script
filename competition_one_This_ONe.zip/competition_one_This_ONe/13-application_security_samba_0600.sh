#!/usr/bin/env bash

# Application Security module for Linux Mint/Ubuntu competition images.
# This file is normally sourced by harden.sh. Strict mode is local when
# executed directly so it cannot leak into the parent script.
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  set -euo pipefail
fi

# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------
appsec_log() { printf '[%s] %s\n' "$1" "$2"; }
appsec_info() { appsec_log INFO "$1"; }
appsec_pass() { appsec_log PASS "$1"; }
appsec_warn() { appsec_log WARN "$1"; }
appsec_fail() { appsec_log FAIL "$1"; }

appsec_require_root() {
  if [[ "${EUID:-$(id -u)}" -ne 0 ]]; then
    appsec_fail "This Application Security action requires root. Run the main script with sudo."
    return 1
  fi
}

# Usage: appsec_yes_no "Question" default(Y|N). Result is stored in REPLY.
appsec_yes_no() {
  local prompt="$1" default="${2:-N}" answer suffix
  [[ "$default" == "Y" ]] && suffix='[Y/n]' || suffix='[y/N]'
  if ! read -r -p "$prompt $suffix " answer; then answer=""; fi
  answer="${answer:-$default}"
  case "$answer" in
    y|Y|yes|YES|Yes) REPLY=Y ;;
    n|N|no|NO|No) REPLY=N ;;
    *) REPLY="$default" ;;
  esac
}

appsec_timestamp() { date '+%Y%m%d_%H%M%S'; }

appsec_backup_file() {
  local path="$1" backup
  [[ -e "$path" || -L "$path" ]] || return 0
  backup="${path}.appsec-$(appsec_timestamp).bak"
  cp -a -- "$path" "$backup" || return 1
  printf '%s\n' "$backup"
}

appsec_is_installed_package() {
  local package="$1"
  dpkg-query -W -f='${Status}' "$package" 2>/dev/null | grep -q '^install ok installed$'
}

appsec_human_users() {
  # UID >= 1000, real home directory, and an interactive shell. Root is excluded.
  getent passwd | awk -F: '$3 >= 1000 && $3 < 60000 && $6 ~ /^\// && $7 !~ /(nologin|false)$/ {print $1 ":" $3 ":" $4 ":" $6}'
}

# Merge our managed policy keys while preserving any unrelated policies already
# present in the JSON file. A malformed existing file is not overwritten.
appsec_write_policy_json() {
  local destination="$1" policy_json="$2" backup
  mkdir -p "$(dirname "$destination")" || return 1
  chown root:root "$(dirname "$destination")" 2>/dev/null || return 1
  chmod 0755 "$(dirname "$destination")" || return 1
  if [[ -e "$destination" ]]; then
    backup="$(appsec_backup_file "$destination")" || return 1
    [[ -n "$backup" ]] && appsec_info "Existing policy backed up to $backup"
  fi
  python3 - "$destination" "$policy_json" <<'PY'
import json, os, sys, tempfile
path, incoming_text = sys.argv[1:]
try:
    incoming = json.loads(incoming_text)
    if not isinstance(incoming, dict) or not isinstance(incoming.get("policies"), dict):
        raise ValueError("incoming policy must contain a policies object")
    existing = {"policies": {}}
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            existing = json.load(f)
        if not isinstance(existing, dict) or not isinstance(existing.get("policies", {}), dict):
            raise ValueError("existing JSON does not contain a valid policies object")
    existing.setdefault("policies", {}).update(incoming["policies"])
    directory = os.path.dirname(path)
    fd, temp_path = tempfile.mkstemp(prefix=".appsec-policy-", dir=directory, text=True)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(existing, f, indent=2, sort_keys=True)
            f.write("\n")
        os.chmod(temp_path, 0o644)
        os.chown(temp_path, 0, 0)
        os.replace(temp_path, path)
    finally:
        if os.path.exists(temp_path):
            os.unlink(temp_path)
except Exception as exc:
    print(f"Policy JSON error: {exc}", file=sys.stderr)
    sys.exit(1)
PY
}

appsec_verify_policy_json() {
  local path="$1" key="$2" expected="$3"
  python3 - "$path" "$key" "$expected" <<'PY'
import json, sys
path, key, expected = sys.argv[1:]
try:
    with open(path, encoding="utf-8") as f:
        value = json.load(f).get("policies", {}).get(key)
    if isinstance(value, bool):
        actual = "true" if value else "false"
    else:
        actual = str(value)
    if actual != expected:
        raise SystemExit(1)
except Exception:
    raise SystemExit(1)
PY
}

# A deliberately small INI editor for mimeapps.list. It changes only the four
# browser defaults and leaves unrelated MIME associations intact.
appsec_set_mime_defaults() {
  local file="$1" desktop_id="$2" owner_uid="${3:-0}" owner_gid="${4:-0}" backup
  mkdir -p "$(dirname "$file")" || return 1
  if [[ -e "$file" ]]; then
    backup="$(appsec_backup_file "$file")" || return 1
    [[ -n "$backup" ]] && appsec_info "MIME defaults backed up to $backup"
  fi
  python3 - "$file" "$desktop_id" <<'PY'
import os, sys, tempfile
path, desktop = sys.argv[1:]
keys = ["text/html", "application/xhtml+xml", "x-scheme-handler/http", "x-scheme-handler/https"]
try:
    lines = []
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            lines = f.readlines()
    out, in_section, found_section, inserted = [], False, False, False
    def put_keys():
        for key in keys:
            out.append(f"{key}={desktop};\n")
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("[") and stripped.endswith("]"):
            if in_section and not inserted:
                put_keys(); inserted = True
            in_section = stripped.lower() == "[default applications]"
            if in_section:
                found_section = True
            out.append(line)
            continue
        if in_section and "=" in line and line.split("=", 1)[0].strip() in keys:
            continue
        out.append(line)
    if in_section and not inserted:
        put_keys(); inserted = True
    if not found_section:
        if out and not out[-1].endswith("\n"):
            out[-1] += "\n"
        if out and out[-1].strip():
            out.append("\n")
        out.append("[Default Applications]\n")
        put_keys()
    directory = os.path.dirname(path)
    fd, tmp = tempfile.mkstemp(prefix=".mimeapps-", dir=directory, text=True)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.writelines(out)
        os.chmod(tmp, 0o644)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)
except Exception as exc:
    print(f"Could not update {path}: {exc}", file=sys.stderr)
    sys.exit(1)
PY
  chown "$owner_uid:$owner_gid" "$file" 2>/dev/null || return 1
  chmod 0644 "$file" || return 1
}

appsec_verify_mime_defaults() {
  local file="$1" desktop_id="$2"
  python3 - "$file" "$desktop_id" <<'PY'
import sys
path, desktop = sys.argv[1:]
keys = {"text/html", "application/xhtml+xml", "x-scheme-handler/http", "x-scheme-handler/https"}
try:
    in_default = False
    found = {}
    with open(path, encoding="utf-8") as f:
        for line in f:
            value = line.strip()
            if value.startswith("[") and value.endswith("]"):
                in_default = value.lower() == "[default applications]"
                continue
            if in_default and "=" in line:
                key, setting = line.split("=", 1)
                key = key.strip()
                if key in keys:
                    found[key] = setting.strip().split(";", 1)[0]
    if any(found.get(key) != desktop for key in keys):
        raise SystemExit(1)
except Exception:
    raise SystemExit(1)
PY
}

appsec_find_desktop_id() {
  local kind="$1" candidate dir file base
  local -a candidates=()
  case "$kind" in
    firefox) candidates=(firefox.desktop org.mozilla.firefox.desktop firefox-esr.desktop) ;;
    chromium) candidates=(chromium.desktop chromium-browser.desktop org.chromium.Chromium.desktop google-chrome.desktop com.google.Chrome.desktop) ;;
    *) return 1 ;;
  esac
  for candidate in "${candidates[@]}"; do
    for dir in /usr/share/applications /usr/local/share/applications /var/lib/flatpak/exports/share/applications; do
      [[ -f "$dir/$candidate" ]] && { printf '%s\n' "$candidate"; return 0; }
    done
  done
  return 1
}

appsec_apply_browser_default() {
  local kind="$1" desktop_id="$2" user uid gid home
  appsec_info "Setting $desktop_id as the browser default for existing users and future accounts."
  appsec_set_mime_defaults /etc/xdg/mimeapps.list "$desktop_id" 0 0 || return 1
  appsec_set_mime_defaults /etc/skel/.config/mimeapps.list "$desktop_id" 0 0 || return 1
  while IFS=: read -r user uid gid home; do
    [[ -d "$home" ]] || continue
    if [[ ! -d "$home/.config" ]]; then
      install -d -m 0700 -o "$uid" -g "$gid" "$home/.config" || {
        appsec_warn "Could not create $home/.config for $user."
        continue
      }
    fi
    appsec_set_mime_defaults "$home/.config/mimeapps.list" "$desktop_id" "$uid" "$gid" || {
      appsec_warn "Could not set the browser default for $user ($home)."
      continue
    }
    appsec_verify_mime_defaults "$home/.config/mimeapps.list" "$desktop_id" || appsec_warn "Could not verify the browser default for $user."
  done < <(appsec_human_users)
  appsec_verify_mime_defaults /etc/xdg/mimeapps.list "$desktop_id" || return 1
  appsec_verify_mime_defaults /etc/skel/.config/mimeapps.list "$desktop_id" || return 1
  if command -v update-desktop-database >/dev/null 2>&1; then
    update-desktop-database /usr/share/applications >/dev/null 2>&1 || true
  fi
  appsec_pass "System, new-user skeleton, and accessible existing-user MIME defaults updated."
  appsec_info "Per-user mimeapps.list files can override /etc/xdg/mimeapps.list; the module writes each existing human user's config as well."
}

# ---------------------------------------------------------------------------
# Main submenu
# ---------------------------------------------------------------------------
invoke_application_security_menu () {
  while true; do
    echo
    echo "============================================================"
    echo "APPLICATION SECURITY MENU"
    echo "============================================================"
    echo "  1) Secure Firefox"
    echo "  2) Secure Chrome/Chromium"
    echo "  3) Secure OpenSSH"
    echo "  4) Secure Samba (including share listing)"
    echo "  5) Audit / secure DNS resolvers"
    echo "  6) Secure NGINX / Apache"
    echo "  7) Return to Main Menu"
    local app_choice
    if ! read -r -p $'\nEnter choice: ' app_choice; then return; fi
    case "$app_choice" in
      1) appsec_secure_firefox || appsec_warn "Firefox security workflow reported a problem." ;;
      2) appsec_secure_chromium || appsec_warn "Chromium security workflow reported a problem." ;;
      3) appsec_secure_ssh || appsec_warn "OpenSSH security workflow reported a problem." ;;
      4) appsec_secure_samba || appsec_warn "Samba security workflow reported a problem." ;;
      5) appsec_secure_dns || appsec_warn "DNS audit reported a problem." ;;
      6) appsec_secure_web || appsec_warn "Web-server security workflow reported a problem." ;;
      7) return ;;
      *) echo "Invalid option." ;;
    esac
  done
}

# ---------------------------------------------------------------------------
# A. Firefox
# ---------------------------------------------------------------------------
appsec_secure_firefox () {
  appsec_require_root || return 1
  echo
  echo "============================================================"
  echo "FIREFOX SECURITY"
  echo "============================================================"

  local detected=0 firefox_version="unknown" policy_json policy_path="" arch branch flatpak_seen=0
  local user uid gid home desktop_id
  policy_json='{"policies":{"DisableTelemetry":true,"DisableFirefoxStudies":true,"DisablePocket":true,"EnableTrackingProtection":{"Value":true,"Locked":true},"PopupBlocking":{"Default":false,"Locked":true},"Preferences":{"browser.safebrowsing.malware.enabled":{"Value":true,"Status":"locked"},"browser.safebrowsing.phishing.enabled":{"Value":true,"Status":"locked"}}}}'

  if command -v firefox >/dev/null 2>&1; then
    detected=1
    firefox_version="$(firefox --version 2>/dev/null | head -n1 || true)"
  elif appsec_is_installed_package firefox; then
    detected=1
    firefox_version="$(dpkg-query -W -f='${Version}' firefox 2>/dev/null || echo installed)"
  fi
  if command -v flatpak >/dev/null 2>&1; then
    if flatpak list --system --app --columns=application 2>/dev/null | grep -qx 'org.mozilla.firefox'; then
      detected=1; flatpak_seen=1
      [[ "$firefox_version" == unknown ]] && firefox_version="$(flatpak info org.mozilla.firefox 2>/dev/null | awk -F': ' '/^Version:/ {print $2; exit}')"
    fi
    while IFS=: read -r user uid gid home; do
      [[ -d "$home" ]] || continue
      if runuser -u "$user" -- env HOME="$home" flatpak list --user --app --columns=application 2>/dev/null | grep -qx 'org.mozilla.firefox'; then
        detected=1; flatpak_seen=1
        if [[ "$firefox_version" == unknown ]]; then
          firefox_version="$(runuser -u "$user" -- env HOME="$home" flatpak info --user org.mozilla.firefox 2>/dev/null | awk -F': ' '/^Version:/ {print $2; exit}')"
        fi
      fi
    done < <(appsec_human_users)
  fi

  if (( ! detected )); then
    appsec_warn "Firefox is not detected. No browser was installed or updated; package updates belong to the update modules."
    return 0
  fi
  appsec_info "Detected Firefox version/build: $firefox_version"
  appsec_info "This workflow does not install or update Firefox."

  local policy_written=0
  if command -v flatpak >/dev/null 2>&1; then
    while read -r arch branch; do
      [[ -n "$arch" && -n "$branch" ]] || continue
      policy_path="/var/lib/flatpak/extension/org.mozilla.firefox.systemconfig/$arch/$branch/policies/policies.json"
      if appsec_write_policy_json "$policy_path" "$policy_json"; then
        appsec_pass "Installed system-wide Firefox Flatpak policy at $policy_path"
        policy_written=1
      else
        appsec_fail "Could not install the system Firefox Flatpak policy at $policy_path"
      fi
    done < <(flatpak list --system --app --columns=application,arch,branch 2>/dev/null | awk '$1=="org.mozilla.firefox" {print $2, $3}')

    while IFS=: read -r user uid gid home; do
      [[ -d "$home" ]] || continue
      while read -r arch branch; do
        [[ -n "$arch" && -n "$branch" ]] || continue
        policy_path="$home/.local/share/flatpak/extension/org.mozilla.firefox.systemconfig/$arch/$branch/policies/policies.json"
        if appsec_write_policy_json "$policy_path" "$policy_json"; then
          chown -R root:root "$home/.local/share/flatpak/extension/org.mozilla.firefox.systemconfig/$arch/$branch" 2>/dev/null || true
          find "$home/.local/share/flatpak/extension/org.mozilla.firefox.systemconfig/$arch/$branch" -type d -exec chmod 0755 {} + 2>/dev/null || true
          appsec_pass "Installed root-managed Firefox Flatpak policy for user $user."
          policy_written=1
        else
          appsec_fail "Could not install Firefox Flatpak policy for user $user."
        fi
      done < <(runuser -u "$user" -- env HOME="$home" flatpak list --user --app --columns=application,arch,branch 2>/dev/null | awk '$1=="org.mozilla.firefox" {print $2, $3}')
    done < <(appsec_human_users)
  fi

  if appsec_is_installed_package firefox || appsec_is_installed_package firefox-esr || { command -v firefox >/dev/null 2>&1 && [[ "$(readlink -f "$(command -v firefox)" 2>/dev/null)" != *flatpak* ]]; }; then
    policy_path=/etc/firefox/policies/policies.json
    if appsec_write_policy_json "$policy_path" "$policy_json"; then
      appsec_pass "Installed machine-wide Firefox policy at $policy_path"
      policy_written=1
    else
      appsec_fail "Could not install machine-wide Firefox policy."
    fi
  fi

  if (( ! policy_written )); then
    appsec_warn "Firefox was detected but no supported policy target was configured. Check the installed package/Flatpak scope."
  fi

  if [[ -n "$policy_path" && -f "$policy_path" ]] && appsec_verify_policy_json "$policy_path" DisableTelemetry true; then
    appsec_pass "Firefox managed policy JSON parsed and core security policy verified."
  else
    appsec_info "Restart Firefox and inspect about:policies to confirm the application actually loaded the policies."
  fi
  appsec_info "Enforced controls: telemetry/studies/Pocket disabled, tracking protection locked on, popup blocking locked on, and Safe Browsing checks enabled."

  appsec_yes_no "Make Firefox the default browser for this machine and existing users?" N
  if [[ "$REPLY" == Y ]]; then
    desktop_id="$(appsec_find_desktop_id firefox 2>/dev/null || true)"
    if [[ -n "$desktop_id" ]]; then
      appsec_apply_browser_default firefox "$desktop_id" || appsec_fail "Firefox MIME defaults could not be applied."
    else
      appsec_warn "No Firefox desktop entry was found; default-browser selection was skipped."
    fi
  else
    appsec_info "Default browser settings were left unchanged. Firefox security policies were still applied."
  fi
}

# ---------------------------------------------------------------------------
# B. Chromium / Google Chrome
# ---------------------------------------------------------------------------
appsec_secure_chromium () {
  appsec_require_root || return 1
  echo
  echo "============================================================"
  echo "CHROMIUM / CHROME SECURITY"
  echo "============================================================"

  local detected=0 version="unknown" policy_json="{\"policies\":{\"DefaultPopupsSetting\":2}}"
  local desktop_id path conflict app arch branch user uid gid home extension_dir target
  if command -v chromium >/dev/null 2>&1; then detected=1; version="$(chromium --version 2>/dev/null | head -n1 || echo installed)"; fi
  if command -v chromium-browser >/dev/null 2>&1; then detected=1; version="$(chromium-browser --version 2>/dev/null | head -n1 || echo installed)"; fi
  if command -v google-chrome >/dev/null 2>&1; then detected=1; version="$(google-chrome --version 2>/dev/null | head -n1 || echo installed)"; fi
  if command -v flatpak >/dev/null 2>&1; then
    if flatpak list --system --app --columns=application 2>/dev/null | grep -qxE 'org\.chromium\.Chromium|com\.google\.Chrome'; then
      detected=1
      [[ "$version" == unknown ]] && version="$(flatpak info org.chromium.Chromium 2>/dev/null | awk -F': ' '/^Version:/ {print $2; exit}')"
    fi
    while IFS=: read -r user uid gid home; do
      [[ -d "$home" ]] || continue
      if runuser -u "$user" -- env HOME="$home" flatpak list --user --app --columns=application 2>/dev/null | grep -qxE 'org\.chromium\.Chromium|com\.google\.Chrome'; then
        detected=1
        if [[ "$version" == unknown ]]; then
          version="$(runuser -u "$user" -- env HOME="$home" flatpak info --user org.chromium.Chromium 2>/dev/null | awk -F': ' '/^Version:/ {print $2; exit}')"
          [[ -n "$version" ]] || version="$(runuser -u "$user" -- env HOME="$home" flatpak info --user com.google.Chrome 2>/dev/null | awk -F': ' '/^Version:/ {print $2; exit}')"
        fi
      fi
    done < <(appsec_human_users)
  fi
  if (( ! detected )); then
    appsec_warn "Chromium/Chrome is not detected. No browser was installed or updated."
    return 0
  fi
  appsec_info "Detected browser build: $version"
  appsec_info "No browser installation or update is performed by this module."

  # Detect conflicting managed-policy files before setting the required value.
  for path in /etc/chromium/policies/managed /etc/chromium-browser/policies/managed /etc/opt/chrome/policies/managed; do
    [[ -d "$path" ]] || continue
    conflict="$(grep -RIl --include='*.json' 'DefaultPopupsSetting' "$path" 2>/dev/null | grep -v '/00-noje-application-security.json$' || true)"
    if [[ -n "$conflict" ]]; then
      appsec_warn "Existing managed policy file(s) also define DefaultPopupsSetting: $conflict"
      appsec_warn "Resolve duplicate definitions before treating the browser policy as unambiguous."
    fi
  done

  local wrote=0
  if command -v chromium >/dev/null 2>&1 || command -v chromium-browser >/dev/null 2>&1; then
    for path in /etc/chromium/policies/managed /etc/chromium-browser/policies/managed; do
      if [[ "$path" == /etc/chromium-browser/policies/managed ]] && ! command -v chromium-browser >/dev/null 2>&1; then continue; fi
      if appsec_write_policy_json "$path/00-noje-application-security.json" "$policy_json"; then
        appsec_pass "Installed mandatory machine policy: $path/00-noje-application-security.json"
        wrote=1
      else
        appsec_fail "Could not write Chromium managed policy in $path"
      fi
    done
  fi
  if command -v google-chrome >/dev/null 2>&1; then
    path=/etc/opt/chrome/policies/managed/00-noje-application-security.json
    if appsec_write_policy_json "$path" "$policy_json"; then
      appsec_pass "Installed mandatory Google Chrome machine policy at $path"
      wrote=1
    else
      appsec_fail "Could not write Google Chrome managed policy."
    fi
  fi

  # Flathub Chromium documents an unmanaged Extension.system-policies extension
  # whose version-1 root links to /etc/chromium-browser. The root contains
  # policies/managed. Never replace an unrelated extension already at that path.
  if command -v flatpak >/dev/null 2>&1; then
    while read -r app arch branch; do
      [[ -n "$app" && -n "$arch" ]] || continue
      if [[ "$app" == org.chromium.Chromium ]]; then
        path=/etc/chromium-browser/policies/managed/00-noje-application-security.json
        appsec_write_policy_json "$path" "$policy_json" || { appsec_fail "Could not create Flatpak Chromium policy."; continue; }
        extension_dir="/var/lib/flatpak/extension/org.chromium.Chromium.Extension.system-policies/$arch/1"
        target=/etc/chromium-browser
        mkdir -p "$(dirname "$extension_dir")"
        if [[ -L "$extension_dir" && "$(readlink "$extension_dir")" == "$target" ]]; then
          :
        elif [[ -e "$extension_dir" || -L "$extension_dir" ]]; then
          appsec_warn "Flatpak Chromium policy extension path is already occupied: $extension_dir"
          continue
        else
          ln -s "$target" "$extension_dir" || { appsec_fail "Could not create $extension_dir"; continue; }
        fi
        appsec_pass "Connected Flatpak Chromium's system-policy extension to /etc/chromium-browser."
        wrote=1
      elif [[ "$app" == com.google.Chrome ]]; then
        appsec_warn "Google Chrome Flatpak was detected; this module does not assume it supports Chromium's Flathub extension point."
      fi
    done < <(flatpak list --system --app --columns=application,arch,branch 2>/dev/null | awk '$1=="org.chromium.Chromium" || $1=="com.google.Chrome" {print $1, $2, $3}')

    while IFS=: read -r user uid gid home; do
      [[ -d "$home" ]] || continue
      while read -r app arch branch; do
        [[ -n "$app" && -n "$arch" ]] || continue
        if [[ "$app" == org.chromium.Chromium ]]; then
          path=/etc/chromium-browser/policies/managed/00-noje-application-security.json
          appsec_write_policy_json "$path" "$policy_json" || { appsec_fail "Could not create shared Chromium policy for $user."; continue; }
          extension_dir="$home/.local/share/flatpak/extension/org.chromium.Chromium.Extension.system-policies/$arch/1"
          target=/etc/chromium-browser
          mkdir -p "$(dirname "$extension_dir")"
          if [[ -L "$extension_dir" && "$(readlink "$extension_dir")" == "$target" ]]; then
            :
          elif [[ -e "$extension_dir" || -L "$extension_dir" ]]; then
            appsec_warn "System Flatpak extension path is already occupied: $extension_dir"
            continue
          else
            ln -s "$target" "$extension_dir" || { appsec_fail "Could not create the system Flatpak policy extension for user-installed Chromium."; continue; }
          fi
          appsec_pass "Connected Chromium's unmanaged system-policy extension for user-installed app $user. The policy file itself is root-managed under /etc/chromium-browser."
          wrote=1
        fi
      done < <(runuser -u "$user" -- env HOME="$home" flatpak list --user --app --columns=application,arch,branch 2>/dev/null | awk '$1=="org.chromium.Chromium" {print $1, $2, $3}')
    done < <(appsec_human_users)
  fi

  if (( wrote )); then
    if appsec_verify_policy_json /etc/chromium/policies/managed/00-noje-application-security.json DefaultPopupsSetting 2 2>/dev/null || \
       appsec_verify_policy_json /etc/chromium-browser/policies/managed/00-noje-application-security.json DefaultPopupsSetting 2 2>/dev/null || \
       appsec_verify_policy_json /etc/opt/chrome/policies/managed/00-noje-application-security.json DefaultPopupsSetting 2 2>/dev/null; then
      appsec_pass "Managed policy JSON contains DefaultPopupsSetting=2."
    fi
    appsec_info "In the browser, open chrome://policy and confirm DefaultPopupsSetting shows value 2, source Platform, scope Machine, level Mandatory, and status OK. The file check alone cannot prove the running browser loaded it."
  else
    appsec_warn "No supported Chromium/Chrome machine-policy destination was configured. Review the detected package/Flatpak type."
  fi

  appsec_yes_no "Make Chromium/Chrome the default browser for this machine and existing users?" N
  if [[ "$REPLY" == Y ]]; then
    desktop_id="$(appsec_find_desktop_id chromium 2>/dev/null || true)"
    if [[ -n "$desktop_id" ]]; then
      appsec_apply_browser_default chromium "$desktop_id" || appsec_fail "Chromium MIME defaults could not be applied."
    else
      appsec_warn "No Chromium/Chrome desktop entry was found; default-browser selection was skipped."
    fi
  else
    appsec_info "Default browser settings were left unchanged. Chromium/Chrome hardening was still applied."
  fi
}

# Restore prior SSH config after a validation or service-reload failure.
appsec_ssh_rollback_config() {
  local config="$1" dropin="$2" backup_main="$3" backup_drop="$4" service="${5:-}" was_active="${6:-0}"
  if [[ -n "$backup_drop" && -f "$backup_drop" ]]; then
    cp -a "$backup_drop" "$dropin" || appsec_fail "Could not restore SSH drop-in backup: $backup_drop"
  else
    rm -f "$dropin"
  fi
  if [[ -n "$backup_main" && -f "$backup_main" ]]; then
    cp -a "$backup_main" "$config" || appsec_fail "Could not restore SSH main-config backup: $backup_main"
  fi
  if [[ "$was_active" == 1 && -n "$service" ]]; then
    systemctl reload "$service" >/dev/null 2>&1 || appsec_warn "Could not reload the restored SSH configuration; inspect sshd before relying on the daemon."
  fi
}

# ---------------------------------------------------------------------------
# C. OpenSSH - drop-in based, scenario-aware, validated before reload
# ---------------------------------------------------------------------------
appsec_secure_ssh () {
  appsec_require_root || return 1
  echo
  echo "============================================================"
  echo "OPENSSH SECURITY"
  echo "============================================================"

  local package=openssh-server config=/etc/ssh/sshd_config dropdir=/etc/ssh/sshd_config.d
  local service= backup_main="" backup_drop="" tmp="" effective="" enable_answer="" scenario_answer="" forwarding_answer=""
  local installed=0 active=0 enable_service=0 scenario_auth=0 forwarding=0 value

  if command -v sshd >/dev/null 2>&1 || appsec_is_installed_package openssh-server; then
    installed=1
    appsec_pass "OpenSSH server is installed."
  else
    appsec_warn "OpenSSH server is not installed."
    appsec_yes_no "Install openssh-server for this round?" N
    if [[ "$REPLY" == Y ]]; then
      if ! DEBIAN_FRONTEND=noninteractive apt-get -o Dpkg::Options::='--force-confold' install -y "$package"; then
        appsec_fail "OpenSSH installation failed."
        return 1
      fi
      installed=1
    else
      appsec_info "SSH installation skipped. No SSH configuration was changed."
      return 0
    fi
  fi

  if [[ ! -f "$config" ]]; then
    appsec_fail "$config is missing; cannot apply a safe drop-in configuration."
    return 1
  fi
  if systemctl cat ssh.service >/dev/null 2>&1; then service=ssh
  elif systemctl cat sshd.service >/dev/null 2>&1; then service=sshd
  else appsec_warn "No SSH systemd unit was found; the configuration will be validated but not started."; fi
  [[ -n "$service" ]] && systemctl is-active --quiet "$service" && active=1

  appsec_yes_no "Is SSH required by the current competition round (enable/start it)?" N
  [[ "$REPLY" == Y ]] && enable_service=1
  appsec_yes_no "Apply scenario authentication defaults (PasswordAuthentication yes, PubkeyAuthentication yes, UsePAM yes)?" N
  [[ "$REPLY" == Y ]] && scenario_auth=1
  appsec_yes_no "Disable SSH agent and TCP forwarding? This can break required tunnels/port-forwarding." N
  [[ "$REPLY" == Y ]] && forwarding=1

  mkdir -p "$dropdir" || return 1
  install -d -m 0755 /run/sshd || return 1

  # Put the Include at the very beginning so the lexically early managed drop-in
  # is evaluated before stock/cloud-init settings. Existing main config is backed up.
  if ! head -n 5 "$config" | grep -Eq '^[[:space:]]*Include[[:space:]]+/etc/ssh/sshd_config\.d/\*\.conf'; then
    [[ -n "$backup_main" ]] || backup_main="$(appsec_backup_file "$config")" || return 1
    tmp="$(mktemp /etc/ssh/.sshd_config.appsec.XXXXXX)" || return 1
    { printf 'Include /etc/ssh/sshd_config.d/*.conf\n\n'; cat "$config"; } > "$tmp"
    chown root:root "$tmp" && chmod 0600 "$tmp" && mv -f "$tmp" "$config" || { rm -f "$tmp"; return 1; }
    appsec_info "Added the sshd_config.d Include directive; original main config backed up to ${backup_main:-unknown}."
  fi
  if [[ "$(stat -c '%U:%G %a' "$config" 2>/dev/null || true)" != "root:root 600" ]]; then
    [[ -n "$backup_main" ]] || backup_main="$(appsec_backup_file "$config")" || return 1
    chown root:root "$config" && chmod 0600 "$config" || return 1
  fi

  local dropin="$dropdir/00-noje-application-security.conf"
  backup_drop="$(appsec_backup_file "$dropin")" || return 1
  tmp="$(mktemp "$dropdir/.appsec-ssh.XXXXXX")" || return 1
  {
    cat <<'SSHBASE'
# Managed by NOJE Application Security. Edit the module, not this file.
PermitRootLogin no
PermitEmptyPasswords no
MaxAuthTries 4
LoginGraceTime 60
X11Forwarding no
PermitUserEnvironment no
ClientAliveInterval 300
ClientAliveCountMax 2
HostbasedAuthentication no
IgnoreRhosts yes
PermitUserRC no
StrictModes yes
LogLevel VERBOSE
SSHBASE
    if (( scenario_auth )); then
      cat <<'SSHSCENARIO'
# Scenario-compatible authentication baseline (explicitly selected).
PasswordAuthentication yes
PubkeyAuthentication yes
UsePAM yes
KbdInteractiveAuthentication yes
SSHSCENARIO
    fi
    if (( forwarding )); then
      cat <<'SSHFWD'
# Forwarding disabled only because the operator explicitly selected it.
AllowTcpForwarding no
AllowAgentForwarding no
SSHFWD
    fi
  } > "$tmp"
  chown root:root "$tmp" && chmod 0600 "$tmp" && mv -f "$tmp" "$dropin" || { rm -f "$tmp"; return 1; }
  chown root:root "$config" "$dropin" && chmod 0600 "$config" "$dropin" || return 1

  if ! sshd -t -f "$config"; then
    appsec_fail "sshd rejected the new configuration. Rolling back the managed drop-in and main configuration."
    [[ -n "$backup_drop" ]] && cp -a "$backup_drop" "$dropin" || rm -f "$dropin"
    [[ -n "$backup_main" ]] && cp -a "$backup_main" "$config"
    return 1
  fi
  effective="$(sshd -T -f "$config" 2>/dev/null)" || {
    appsec_fail "Could not read sshd effective configuration."
    [[ -n "$backup_drop" ]] && cp -a "$backup_drop" "$dropin" || rm -f "$dropin"
    [[ -n "$backup_main" ]] && cp -a "$backup_main" "$config"
    return 1
  }

  for value in 'permitrootlogin no' 'permitemptypasswords no' 'maxauthtries 4' 'logingracetime 60' 'x11forwarding no' 'permituserenvironment no' 'clientaliveinterval 300' 'clientalivecountmax 2' 'hostbasedauthentication no' 'ignorerhosts yes' 'permituserrc no' 'strictmodes yes' 'loglevel VERBOSE'; do
    if ! grep -Fxq "$value" <<< "$effective"; then
      appsec_fail "Effective sshd setting did not match: $value"
      appsec_ssh_rollback_config "$config" "$dropin" "$backup_main" "$backup_drop" "$service" "$active"
      return 1
    fi
  done
  if (( forwarding )); then
    for value in 'allowtcpforwarding no' 'allowagentforwarding no'; do
      if ! grep -Fxq "$value" <<< "$effective"; then
        appsec_fail "SSH forwarding restriction not effective: $value"
        appsec_ssh_rollback_config "$config" "$dropin" "$backup_main" "$backup_drop" "$service" "$active"
        return 1
      fi
    done
  fi
  if (( scenario_auth )); then
    for value in 'passwordauthentication yes' 'pubkeyauthentication yes' 'usepam yes'; do
      if ! grep -Fxq "$value" <<< "$effective"; then
        appsec_fail "Scenario SSH setting not effective: $value"
        appsec_ssh_rollback_config "$config" "$dropin" "$backup_main" "$backup_drop" "$service" "$active"
        return 1
      fi
    done
  fi
  appsec_pass "SSH drop-in syntax and effective universal baseline verified."

  if (( enable_service )); then
    [[ -n "$service" ]] || { appsec_fail "SSH is required, but no ssh.service/sshd.service unit exists."; return 1; }
    systemctl unmask "$service" >/dev/null 2>&1 || true
    if ! systemctl enable "$service"; then
      appsec_fail "Could not enable $service."
      appsec_ssh_rollback_config "$config" "$dropin" "$backup_main" "$backup_drop" "$service" "$active"
      return 1
    fi
    if ! systemctl is-active --quiet "$service"; then
      if ! systemctl start "$service"; then
        appsec_fail "Could not start $service."
        appsec_ssh_rollback_config "$config" "$dropin" "$backup_main" "$backup_drop" "$service" "$active"
        return 1
      fi
    elif ! systemctl reload "$service"; then
      appsec_fail "SSH reload failed; restoring the previous configuration."
      appsec_ssh_rollback_config "$config" "$dropin" "$backup_main" "$backup_drop" "$service" "$active"
      return 1
    fi
    if ! systemctl is-active --quiet "$service" || ! systemctl is-enabled --quiet "$service"; then
      appsec_fail "SSH service did not reach active+enabled state; restoring its previous configuration."
      appsec_ssh_rollback_config "$config" "$dropin" "$backup_main" "$backup_drop" "$service" "$active"
      return 1
    fi
    appsec_pass "SSH service is active and enabled as requested."
  elif (( active )); then
    if ! systemctl reload "$service"; then
      appsec_fail "SSH config validated but the active service reload failed; restoring the previous configuration."
      appsec_ssh_rollback_config "$config" "$dropin" "$backup_main" "$backup_drop" "$service" "$active"
      return 1
    fi
    appsec_pass "Existing SSH service reloaded; enablement state was not changed."
  else
    appsec_info "SSH service state was left unchanged (not required/selected). Configuration was validated."
  fi

  appsec_info "Managed drop-in: $dropin"
  appsec_info "Password/public-key/PAM authentication settings were only changed when the scenario option was selected."
  appsec_info "TCP/agent forwarding were only disabled when explicitly selected."
}

# ---------------------------------------------------------------------------
# D. Samba: share inventory + configuration hardening
# ---------------------------------------------------------------------------
# Print extended ACL entries when getfacl is available. POSIX ACLs can grant
# access that is not obvious from the three ordinary mode-bit classes.
appsec_samba_print_acl () {
  local path="$1" label="$2" acl named_acl
  command -v getfacl >/dev/null 2>&1 || {
    appsec_info "getfacl is unavailable; extended ACLs were not inspected for $label."
    return 0
  }
  acl="$(getfacl -cp -- "$path" 2>/dev/null || true)"
  [[ -n "$acl" ]] || return 0
  named_acl="$(printf '%s\n' "$acl" | awk '/^(user|group):[^:]+:/ || /^default:/ {print}')"
  if [[ -n "$named_acl" ]]; then
    appsec_warn "$label has named/default ACL entries in addition to its ordinary mode bits:"
    printf '%s\n' "$named_acl" | sed 's/^/    /'
  else
    appsec_info "$label has no named-user, named-group, or default ACL entries."
  fi
}

# Read-only report of smb.conf metadata. The competition-tested baseline is
# exact root:root ownership and mode 0600 (only root may read or write it).
appsec_samba_report_config_permissions () {
  local config="${1:-/etc/samba/smb.conf}" stat_line owner group mode symbolic mode_value
  echo
  echo "--- Samba configuration file permissions ---"
  if [[ ! -e "$config" && ! -L "$config" ]]; then
    appsec_warn "Samba configuration file is missing: $config"
    return 0
  fi
  if [[ -L "$config" ]]; then
    appsec_warn "$config is a symbolic link ($(readlink -- "$config" 2>/dev/null || echo unknown target)); resolve it manually before changing its ownership or permissions."
    return 0
  fi
  stat_line="$(stat -c '%U|%G|%a|%A' -- "$config" 2>/dev/null)" || {
    appsec_warn "Could not inspect ownership/permissions for $config."
    return 0
  }
  IFS='|' read -r owner group mode symbolic <<< "$stat_line"
  printf '  %s | owner: %s:%s | mode: %s (%s)\n' "$config" "$owner" "$group" "$mode" "$symbolic"
  mode_value=$((8#$mode))
  if [[ "$owner" != root || "$group" != root || "$mode_value" -ne 0600 ]]; then
    appsec_warn "smb.conf does not meet the required root:root 0600 baseline."
    if (( mode_value & 0002 )); then
      appsec_warn "CRITICAL: smb.conf is world-writable. Any local user may be able to alter Samba's security configuration."
    elif (( mode_value & 0020 )); then
      appsec_warn "CRITICAL: smb.conf is group-writable. A member of its owning group may be able to alter Samba's security configuration."
    fi
    (( mode_value & 0111 )) && appsec_warn "smb.conf has execute permission bits; a configuration file should not be executable."
    [[ "$owner" == root ]] || appsec_warn "smb.conf is owned by '$owner', not root."
    [[ "$group" == root ]] || appsec_warn "smb.conf belongs to group '$group', not root."
    appsec_warn "Required baseline for this competition profile: root:root 0600 (read/write by root only)."
  else
    appsec_pass "smb.conf matches the required root:root 0600 baseline (read/write by root only)."
  fi
  appsec_samba_print_acl "$config" "smb.conf"
}

# Samba has four independent effective creation-permission controls.
# "create mode" aliases "create mask"; "directory mode" aliases
# "directory mask". testparm normalizes those aliases to canonical names.
appsec_samba_mode_parameters=(
  "create mask"
  "directory mask"
  "force create mode"
  "force directory mode"
)

# Retrieve an effective octal value, including inherited/default values.
# testparm -v is necessary because ordinary -s output omits defaulted options.
appsec_samba_effective_mode () {
  local config="$1" section="$2" parameter="$3" output value
  output="$(testparm -s -v --section-name="$section" --parameter-name="$parameter" "$config" 2>/dev/null)" || return 1
  value="$(printf '%s\n' "$output" | tail -n 1 | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')"
  if [[ "$value" == *=* ]]; then value="${value##*=}"; fi
  value="$(printf '%s' "$value" | tr -d '[:space:]' | tr -d "'\"")"
  [[ "$value" =~ ^[0-7]{1,4}$ ]] || return 1
  printf -v value '%04o' "$((8#$value))"
  printf '%s\n' "$value"
}

appsec_samba_mode_has_world_write () {
  local value="${1//[[:space:]]/}" numeric
  [[ "$value" =~ ^[0-7]{1,4}$ ]] || return 2
  numeric=$((8#$value))
  (( numeric & 0002 ))
}

# Check whether a permission directive is explicitly present in this section
# of the file being edited. This avoids repeatedly asking about every share
# that merely inherits an unsafe global value.
appsec_samba_mode_is_explicit () {
  local config="$1" section="$2" parameter="$3"
  python3 - "$config" "$section" "$parameter" <<'PY'
import re, sys
path, target_section, parameter = sys.argv[1:]
aliases = {
    "create mask": {"create mask", "create mode"},
    "directory mask": {"directory mask", "directory mode"},
    "force create mode": {"force create mode"},
    "force directory mode": {"force directory mode"},
}
accepted = aliases.get(parameter.lower())
if accepted is None:
    raise SystemExit(2)
section = ""
found = False
header = re.compile(r"^\s*\[([^]]+)\]")
try:
    with open(path, encoding="utf-8", errors="replace") as stream:
        for raw in stream:
            match = header.match(raw)
            if match:
                section = match.group(1).strip().lower()
                continue
            stripped = raw.lstrip()
            if section != target_section.lower() or stripped.startswith(("#", ";")) or "=" not in raw:
                continue
            key = raw.split("=", 1)[0].strip().lower()
            if key in accepted:
                found = True
                break
except OSError:
    raise SystemExit(2)
raise SystemExit(0 if found else 1)
PY
}

# Replace aliases/duplicates for one directive in one section, appending the
# canonical value at the section's end. This edits a temporary candidate, not
# the live smb.conf, until all checks have passed.
appsec_samba_set_effective_mode () {
  local config="$1" section="$2" parameter="$3" value="$4"
  python3 - "$config" "$section" "$parameter" "$value" <<'PY'
import os, re, sys, tempfile
path, target_section, parameter, value = sys.argv[1:]
target_section = target_section.lower()
aliases = {
    "create mask": {"create mask", "create mode"},
    "directory mask": {"directory mask", "directory mode"},
    "force create mode": {"force create mode"},
    "force directory mode": {"force directory mode"},
}
accepted = aliases.get(parameter.lower())
if accepted is None:
    raise SystemExit("Unsupported Samba permission parameter")
header = re.compile(r"^\s*\[([^]]+)\]")
try:
    if os.path.islink(path):
        raise OSError("refusing to edit a symbolic-link configuration")
    st = os.stat(path, follow_symlinks=False)
    with open(path, encoding="utf-8", errors="replace") as stream:
        lines = stream.readlines()
except OSError as exc:
    print(f"Could not read candidate smb.conf: {exc}", file=sys.stderr)
    raise SystemExit(1)

out = []
section = ""
section_found = False
body = []

def flush_section(section_name, section_body):
    if section_name != target_section:
        return section_body, False
    filtered = []
    for raw in section_body:
        stripped = raw.lstrip()
        if stripped.startswith(("#", ";")) or "=" not in raw:
            filtered.append(raw)
            continue
        key = raw.split("=", 1)[0].strip().lower()
        if key in accepted:
            continue
        filtered.append(raw)
    if filtered and not filtered[-1].endswith("\n"):
        filtered[-1] += "\n"
    filtered.append(f"    {parameter} = {value}\n")
    return filtered, True

for raw in lines:
    match = header.match(raw)
    if match:
        processed, found = flush_section(section, body)
        out.extend(processed)
        section_found = section_found or found
        out.append(raw)
        section = match.group(1).strip().lower()
        body = []
        continue
    body.append(raw)
processed, found = flush_section(section, body)
out.extend(processed)
section_found = section_found or found

if not section_found:
    if target_section != "global":
        print(f"Section [{target_section}] was not found in candidate smb.conf", file=sys.stderr)
        raise SystemExit(1)
    if out and out[-1].strip():
        out.append("\n")
    out.extend(["[global]\n", f"    {parameter} = {value}\n"])

directory = os.path.dirname(os.path.abspath(path))
fd, temp_path = tempfile.mkstemp(prefix=".smb-mode-", dir=directory, text=True)
try:
    os.fchown(fd, st.st_uid, st.st_gid)
    os.fchmod(fd, st.st_mode & 0o7777)
    with os.fdopen(fd, "w", encoding="utf-8") as stream:
        stream.writelines(out)
    os.replace(temp_path, path)
except Exception as exc:
    try:
        os.close(fd)
    except OSError:
        pass
    try:
        os.unlink(temp_path)
    except OSError:
        pass
    print(f"Could not update candidate smb.conf: {exc}", file=sys.stderr)
    raise SystemExit(1)
PY
}

appsec_samba_report_creation_modes () {
  local config="${1:-/etc/samba/smb.conf}" test_output section parameter value
  local -a sections=()
  echo
  echo "--- Effective Samba file/directory creation masks and modes ---"
  if ! test_output="$(testparm -s "$config" 2>/dev/null)"; then
    appsec_warn "Could not enumerate Samba sections for creation-permission auditing."
    return 1
  fi
  mapfile -t sections < <(printf '%s\n' "$test_output" | awk '
    /^[[:space:]]*\[[^]]+\][[:space:]]*$/ {
      n=$0; gsub(/^[[:space:]]*\[/, "", n); gsub(/\][[:space:]]*$/, "", n); print n
    }
  ')
  appsec_info "The names 'create mode' and 'directory mode' are aliases; testparm reports their canonical mask names."
  for section in "${sections[@]}"; do
    printf '\n  [%s]\n' "$section"
    for parameter in "${appsec_samba_mode_parameters[@]}"; do
      if ! value="$(appsec_samba_effective_mode "$config" "$section" "$parameter")"; then
        appsec_warn "Could not read effective '$parameter' for [$section]."
        continue
      fi
      if appsec_samba_mode_has_world_write "$value"; then
        appsec_warn "WORLD-WRITE BIT SET: $parameter = $value in [$section]."
      else
        appsec_pass "$parameter = $value (no world-write bit)."
      fi
    done
  done
}

# Prompt for any effective mask/force-mode carrying the world-write bit.
# Changes are made to the candidate smb.conf supplied by the caller; the live
# file is replaced only after the existing syntax and policy checks pass.
appsec_samba_prompt_creation_modes () {
  local config="$1" test_output section parameter value global_value requested numeric
  local suggested verify_value changes=0 failures=0
  local -a sections=()
  test_output="$(testparm -s "$config" 2>/dev/null)" || {
    appsec_fail "Could not enumerate Samba sections for creation-mode remediation."
    return 1
  }
  mapfile -t sections < <(printf '%s\n' "$test_output" | awk '
    /^[[:space:]]*\[[^]]+\][[:space:]]*$/ {
      n=$0; gsub(/^[[:space:]]*\[/, "", n); gsub(/\][[:space:]]*$/, "", n); print n
    }
  ')
  if (( ${#sections[@]} == 0 )); then
    appsec_info "No Samba sections were found for creation-mode remediation."
    return 0
  fi

  echo
  echo "============================================================"
  echo "SAMBA FILE/DIRECTORY CREATION-PERMISSION AUDIT"
  echo "============================================================"
  appsec_info "Checking effective create mask, directory mask, force create mode, and force directory mode in [global] and every share."
  appsec_info "create mode aliases create mask; directory mode aliases directory mask."

  # Process global first so inherited share settings are evaluated after any
  # accepted global correction.
  for section in "${sections[@]}"; do
    [[ "${section,,}" == global ]] || continue
    for parameter in "${appsec_samba_mode_parameters[@]}"; do
      if ! value="$(appsec_samba_effective_mode "$config" "$section" "$parameter")"; then
        appsec_warn "Could not read effective '$parameter' in [$section]; skipped."
        failures=1
        continue
      fi
      if ! appsec_samba_mode_has_world_write "$value"; then
        continue
      fi
      appsec_warn "[$section] $parameter = $value permits world-write permissions."
      case "$parameter" in
        "create mask") suggested=0664 ;;
        "directory mask") suggested=0775 ;;
        "force create mode"|"force directory mode") suggested=0000 ;;
      esac
      appsec_yes_no "Correct [$section] $parameter now?" N
      [[ "$REPLY" == Y ]] || {
        appsec_warn "[$section] $parameter was left at $value by request."
        continue
      }
      requested=""
      while true; do
        if ! read -r -p "Enter replacement octal value for [$section] $parameter [recommended $suggested; blank cancels]: " requested; then requested=""; fi
        if [[ -z "$requested" ]]; then
          appsec_info "No replacement entered; [$section] $parameter was left unchanged."
          break
        fi
        if [[ ! "$requested" =~ ^[0-7]{3,4}$ ]]; then
          appsec_warn "Enter three or four octal digits (for example 0664 or 0775)."
          continue
        fi
        numeric=$((8#$requested))
        printf -v requested '%04o' "$numeric"
        if (( numeric & 0002 )); then
          appsec_warn "The replacement $requested still includes the world-write bit (0002). Choose a value without that bit."
          continue
        fi
        break
      done
      [[ -n "$requested" ]] || continue
      if ! appsec_samba_set_effective_mode "$config" "$section" "$parameter" "$requested"; then
        appsec_fail "Could not update [$section] $parameter in the candidate configuration."
        failures=1
        continue
      fi
      if ! verify_value="$(appsec_samba_effective_mode "$config" "$section" "$parameter")" || [[ "$verify_value" != "$requested" ]]; then
        appsec_fail "[$section] $parameter verification failed (wanted $requested, got ${verify_value:-unavailable})."
        failures=1
      else
        appsec_pass "[$section] $parameter changed from $value to $verify_value."
        changes=$((changes + 1))
      fi
    done
  done

  # Now check share-specific settings. Inherited global problems are reported
  # once rather than prompting separately for every share that inherits them.
  for section in "${sections[@]}"; do
    [[ "${section,,}" == global ]] && continue
    for parameter in "${appsec_samba_mode_parameters[@]}"; do
      if ! value="$(appsec_samba_effective_mode "$config" "$section" "$parameter")"; then
        appsec_warn "Could not read effective '$parameter' in [$section]; skipped."
        failures=1
        continue
      fi
      if ! appsec_samba_mode_has_world_write "$value"; then
        continue
      fi
      if ! global_value="$(appsec_samba_effective_mode "$config" global "$parameter")"; then
        global_value=""
      fi
      if [[ "$value" == "$global_value" ]] && ! appsec_samba_mode_is_explicit "$config" "$section" "$parameter"; then
        appsec_warn "[$section] inherits world-writable $parameter = $value from [global]; correct the global setting rather than adding a redundant share override."
        continue
      fi

      appsec_warn "[$section] $parameter = $value permits world-write permissions."
      case "$parameter" in
        "create mask") suggested=0664 ;;
        "directory mask") suggested=0775 ;;
        "force create mode"|"force directory mode") suggested=0000 ;;
      esac
      appsec_yes_no "Correct [$section] $parameter now?" N
      [[ "$REPLY" == Y ]] || {
        appsec_warn "[$section] $parameter was left at $value by request."
        continue
      }
      requested=""
      while true; do
        if ! read -r -p "Enter replacement octal value for [$section] $parameter [recommended $suggested; blank cancels]: " requested; then requested=""; fi
        if [[ -z "$requested" ]]; then
          appsec_info "No replacement entered; [$section] $parameter was left unchanged."
          break
        fi
        if [[ ! "$requested" =~ ^[0-7]{3,4}$ ]]; then
          appsec_warn "Enter three or four octal digits (for example 0664 or 0775)."
          continue
        fi
        numeric=$((8#$requested))
        printf -v requested '%04o' "$numeric"
        if (( numeric & 0002 )); then
          appsec_warn "The replacement $requested still includes the world-write bit (0002). Choose a value without that bit."
          continue
        fi
        break
      done
      [[ -n "$requested" ]] || continue
      if ! appsec_samba_set_effective_mode "$config" "$section" "$parameter" "$requested"; then
        appsec_fail "Could not update [$section] $parameter in the candidate configuration."
        failures=1
        continue
      fi
      if ! verify_value="$(appsec_samba_effective_mode "$config" "$section" "$parameter")" || [[ "$verify_value" != "$requested" ]]; then
        appsec_fail "[$section] $parameter verification failed (wanted $requested, got ${verify_value:-unavailable})."
        failures=1
      else
        appsec_pass "[$section] $parameter changed from $value to $verify_value."
        changes=$((changes + 1))
      fi
    done
  done

  if (( changes )); then
    appsec_info "Updated $changes Samba creation-permission setting(s) in the candidate configuration."
  else
    appsec_info "No Samba creation-permission settings were changed."
  fi
  (( failures == 0 ))
}

appsec_samba_list_shares () {
  local config="${1:-/etc/samba/smb.conf}"
  echo
  echo "============================================================"
  echo "SAMBA SHARE INVENTORY / PERMISSION AUDIT"
  echo "============================================================"
  if ! command -v testparm >/dev/null 2>&1 || [[ ! -f "$config" ]]; then
    appsec_warn "Samba/testparm configuration not found."
    return 1
  fi
  appsec_samba_report_config_permissions "$config"
  appsec_samba_report_creation_modes "$config" || appsec_warn "Samba creation-permission audit was incomplete."

  local test_output
  if ! test_output="$(testparm -s "$config" 2>/dev/null)"; then
    appsec_fail "testparm could not parse $config."
    return 1
  fi
  printf '%s\n' "$test_output" | awk '
    /^[[:space:]]*\[[^]]+\][[:space:]]*$/ {
      name=$0; gsub(/^[[:space:]]*\[/,"",name); gsub(/\][[:space:]]*$/,"",name)
      if (tolower(name)!="global") print name
    }
  ' | while IFS= read -r share; do
    [[ -n "$share" ]] || continue
    printf '\n[%s]\n' "$share"
    local section_details share_path stat_line owner group mode symbolic mode_value
    section_details="$(testparm -s --section-name="$share" "$config" 2>/dev/null || true)"
    printf '%s\n' "$section_details" | awk -F= '
      /^[[:space:]]*(path|guest ok|public|read only|wide links|follow symlinks|valid users|write list|hosts allow|hosts deny|browseable|available)[[:space:]]*=/ {
        key=$1; val=$2; gsub(/^[[:space:]]+|[[:space:]]+$/, "", key); gsub(/^[[:space:]]+|[[:space:]]+$/, "", val); print "  " key " = " val
      }
    '
    share_path="$(awk -F= 'tolower($1) ~ /^[[:space:]]*path[[:space:]]*$/ {sub(/^[[:space:]]+/, "", $2); sub(/[[:space:]]+$/, "", $2); print $2; exit}' <<< "$section_details")"
    if [[ -n "$share_path" && "$share_path" != *%* && -d "$share_path" ]]; then
      if [[ -L "$share_path" ]]; then
        appsec_warn "Share path is a symbolic link: $share_path -> $(readlink -f -- "$share_path" 2>/dev/null || echo unknown target). The hardening prompt will not chmod through symlinks."
      fi
      stat_line="$(stat -Lc '%U|%G|%a|%A' -- "$share_path" 2>/dev/null)" || stat_line=""
      if [[ -n "$stat_line" ]]; then
        IFS='|' read -r owner group mode symbolic <<< "$stat_line"
        printf '  filesystem path: %s | owner: %s:%s | mode: %s (%s)\n' "$share_path" "$owner" "$group" "$mode" "$symbolic"
        mode_value=$((8#$mode))
        if (( mode_value & 0002 )); then
          if (( mode_value & 01000 )); then
            appsec_warn "Share path is world-writable but has the sticky bit set ($mode); this is common for spool directories, but still permits broad directory access."
          else
            appsec_warn "CRITICAL: Share path is world-writable without the sticky bit ($mode): $share_path"
          fi
        elif (( mode_value & 0020 )); then
          appsec_info "Share path is group-writable ($mode); verify that group '$group' matches the intended Samba users."
        else
          appsec_pass "Share root has no group/world write bits."
        fi
        appsec_samba_print_acl "$share_path" "Share [$share] path"
      else
        appsec_warn "Could not inspect filesystem permissions for share path: $share_path"
      fi
    elif [[ -n "$share_path" && "$share_path" != *%* ]]; then
      appsec_warn "Configured share path is not currently present: $share_path"
    elif [[ -n "$share_path" ]]; then
      appsec_info "Share path contains Samba variables and is resolved per connection: $share_path"
    fi
  done
  echo
  if command -v smbclient >/dev/null 2>&1; then
    appsec_info "Runtime share enumeration (anonymous, may be denied by policy):"
    smbclient -L localhost -N 2>&1 | sed -n '1,45p' || true
  fi
}

# In the hardening workflow, ask before changing smb.conf metadata. This
# profile uses the competition-verified root:root 0600 requirement, not 0644.
appsec_samba_harden_config_permissions () {
  local config="${1:-/etc/samba/smb.conf}" stat_line owner group mode symbolic mode_value backup verify_line verify_owner verify_group verify_mode
  APPSEC_SAMBA_CONFIG_0600_APPROVED=0
  [[ -f "$config" ]] || return 1
  if [[ -L "$config" ]]; then
    appsec_warn "Refusing to change permissions through a symbolic-link smb.conf. Resolve the link manually first."
    return 1
  fi
  stat_line="$(stat -c '%U|%G|%a|%A' -- "$config" 2>/dev/null)" || return 1
  IFS='|' read -r owner group mode symbolic <<< "$stat_line"
  mode_value=$((8#$mode))
  if [[ "$owner" == root && "$group" == root ]] && (( mode_value == 0600 )); then
    APPSEC_SAMBA_CONFIG_0600_APPROVED=1
    appsec_pass "smb.conf already matches root:root 0600."
    return 0
  fi

  appsec_warn "smb.conf currently has owner/group/mode $owner:$group $mode ($symbolic); required baseline is root:root 0600."
  appsec_yes_no "Secure smb.conf as root:root 0600 (read/write by root only)?" Y
  if [[ "$REPLY" != Y ]]; then
    appsec_warn "smb.conf metadata was left unchanged by request. The candidate configuration will preserve its current owner/group/mode and will remain outside the 0600 baseline."
    return 0
  fi

  backup="$(appsec_backup_file "$config")" || {
    appsec_fail "Could not back up smb.conf before changing its metadata. No change was made."
    return 1
  }
  if ! chown root:root -- "$config" || ! chmod 0600 -- "$config"; then
    appsec_fail "Could not secure smb.conf metadata; attempting to restore its backup."
    [[ -n "$backup" ]] && cp -a -- "$backup" "$config"
    return 1
  fi

  verify_line="$(stat -c '%U|%G|%a' -- "$config" 2>/dev/null)" || verify_line=""
  IFS='|' read -r verify_owner verify_group verify_mode <<< "$verify_line"
  if [[ "$verify_owner" != root || "$verify_group" != root || "$verify_mode" != 600 ]]; then
    appsec_fail "smb.conf metadata verification failed (found ${verify_owner:-?}:${verify_group:-?} ${verify_mode:-?}; expected root:root 600). Restoring backup."
    [[ -n "$backup" ]] && cp -a -- "$backup" "$config"
    return 1
  fi

  APPSEC_SAMBA_CONFIG_0600_APPROVED=1
  appsec_pass "smb.conf ownership and permissions set and verified as root:root 0600."
  [[ -n "$backup" ]] && appsec_info "Original smb.conf metadata/content backup: $backup"
  return 0
}

# Save the current share-root ACL/ownership/mode before applying a chmod.
# getfacl output is directly usable with `setfacl --restore` when available.
appsec_samba_backup_share_permissions () {
  local path="$1" backup backup_dir=/var/backups/samba-permissions
  install -d -o root -g root -m 0700 "$backup_dir" || return 1
  backup="$(mktemp "$backup_dir/share-root.XXXXXX")" || return 1
  if command -v getfacl >/dev/null 2>&1; then
    if ! getfacl -p -- "$path" > "$backup" 2>/dev/null; then
      rm -f -- "$backup"
      return 1
    fi
  else
    {
      printf '# getfacl was unavailable; this file records the share-root metadata for manual restoration.\n'
      stat -c 'path=%n owner_uid=%u group_gid=%g mode=%a symbolic=%A' -- "$path"
    } > "$backup" || { rm -f -- "$backup"; return 1; }
  fi
  chmod 0600 -- "$backup" || { rm -f -- "$backup"; return 1; }
  printf '%s\n' "$backup"
}

# Ask for an operator-selected octal mode on each clearly world-writable share
# directory. Only the share root is changed; contents are never chmod -R'd.
appsec_samba_prompt_share_permissions () {
  local config=/etc/samba/smb.conf test_output share section_details share_path
  local stat_line owner group mode symbolic mode_value requested metadata_backup failures=0
  test_output="$(testparm -s "$config" 2>/dev/null)" || {
    appsec_warn "Could not enumerate shares for filesystem-permission review."
    return 1
  }
  while IFS= read -r share <&3; do
    [[ -n "$share" ]] || continue
    section_details="$(testparm -s --section-name="$share" "$config" 2>/dev/null || true)"
    share_path="$(awk -F= 'tolower($1) ~ /^[[:space:]]*path[[:space:]]*$/ {sub(/^[[:space:]]+/, "", $2); sub(/[[:space:]]+$/, "", $2); print $2; exit}' <<< "$section_details")"
    [[ -n "$share_path" && "$share_path" != *%* ]] || continue
    [[ -d "$share_path" ]] || continue
    if [[ -L "$share_path" ]]; then
      appsec_warn "Skipping [$share]: its share path is a symbolic link ($share_path). Review the target manually."
      continue
    fi
    stat_line="$(stat -c '%U|%G|%a|%A' -- "$share_path" 2>/dev/null)" || continue
    IFS='|' read -r owner group mode symbolic <<< "$stat_line"
    mode_value=$((8#$mode))

    if (( (mode_value & 0002) == 0 )); then
      continue
    fi
    if (( mode_value & 01000 )); then
      appsec_info "[$share] is world-writable but sticky-bit protected ($mode); leaving this common spool-style configuration alone."
      continue
    fi

    appsec_warn "[$share] has unsafe world-writable filesystem permissions: $share_path (owner/group $owner:$group, mode $mode / $symbolic)."
    appsec_yes_no "This share has insecure permissions. Change its directory mode?" N
    [[ "$REPLY" == Y ]] || {
      appsec_info "Filesystem permissions for [$share] were left unchanged."
      continue
    }

    requested=""
    if ! read -r -p "Enter the new octal mode for [$share] (3-4 digits, e.g. 2770; blank skips): " requested; then requested=""; fi
    if [[ -z "$requested" ]]; then
      appsec_info "No new mode entered; [$share] was left unchanged."
      continue
    fi
    if [[ ! "$requested" =~ ^[0-7]{3,4}$ ]]; then
      appsec_warn "Invalid octal mode '$requested'; expected three or four octal digits. [$share] was not changed."
      continue
    fi
    appsec_samba_print_acl "$share_path" "Share [$share] path"
    appsec_yes_no "Apply chmod $requested to $share_path only (not recursively)? Existing ACL masks may be affected." N
    if [[ "$REPLY" != Y ]]; then
      appsec_info "Permission change for [$share] cancelled."
      continue
    fi
    metadata_backup="$(appsec_samba_backup_share_permissions "$share_path")" || {
      appsec_fail "Could not back up [$share] ownership/permissions/ACL; no permission change was made."
      failures=1
      continue
    }
    appsec_info "Share-root permission backup saved to $metadata_backup"
    if command -v getfacl >/dev/null 2>&1; then
      appsec_info "When needed, restore this ACL/ownership snapshot with: setfacl --restore='$metadata_backup'"
    else
      appsec_info "getfacl/setfacl are unavailable; the backup records the original numeric owner/group and mode for manual restoration."
    fi
    if chmod -- "$requested" "$share_path"; then
      stat_line="$(stat -c '%U|%G|%a|%A' -- "$share_path" 2>/dev/null)" || stat_line=""
      if [[ -n "$stat_line" ]]; then
        IFS='|' read -r owner group mode symbolic <<< "$stat_line"
        appsec_pass "[$share] directory mode is now $mode ($symbolic), owner/group remains $owner:$group. Backup: $metadata_backup"
      else
        appsec_warn "chmod completed for [$share], but the new mode could not be read back."
      fi
    else
      appsec_fail "Could not change permissions on [$share] path $share_path."
      failures=1
    fi
  done 3< <(printf '%s\n' "$test_output" | awk '
    /^[[:space:]]*\[[^]]+\][[:space:]]*$/ {
      n=$0
      gsub(/^[[:space:]]*\[/, "", n)
      gsub(/\][[:space:]]*$/, "", n)
      if (tolower(n) != "global") print n
    }
  ')
  (( failures == 0 ))
}

appsec_samba_rewrite_config () {
  local source="$1" destination="$2" disable_guest="$3"
  # Buffer each section and append managed settings at its END. This avoids
  # existing duplicate directives later in the section overriding our policy.
  awk -v disable_guest="$disable_guest" '
    function trim(s) {
      sub(/^[[:space:]]+/, "", s)
      sub(/[[:space:]]+$/, "", s)
      return s
    }
    function emit_global() {
      print "   # NOJE Application Security baseline"
      print "   server min protocol = SMB2_10"
      print "   server signing = mandatory"
      print "   ntlm auth = ntlmv2-only"
      print "   lanman auth = no"
      print "   wide links = no"
      print "   allow insecure wide links = no"
      if (disable_guest == 1) {
        print "   map to guest = Never"
        print "   restrict anonymous = 2"
        print "   usershare allow guests = no"
      }
    }
    function emit_share() {
      if (disable_guest == 1) {
        print "   # Guest access disabled by NOJE Application Security"
        print "   guest ok = no"
        print "   public = no"
        print "   wide links = no"
      }
    }
    function emit_body_line(raw, clean, key) {
      if (raw ~ /^[[:space:]]*[#;][[:space:]]*NOJE Application Security baseline[[:space:]]*$/ ||
          raw ~ /^[[:space:]]*[#;][[:space:]]*Guest access disabled by NOJE Application Security[[:space:]]*$/) return
      clean = raw
      sub(/[;#].*$/, "", clean)
      if (clean ~ /^[[:space:]]*[^=]+=/) {
        key = tolower(trim(clean))
        sub(/[[:space:]]*=.*/, "", key)
        if (section_name == "global") {
          if (key == "server min protocol" || key == "server signing" ||
              key == "ntlm auth" || key == "lanman auth" ||
              key == "wide links" || key == "allow insecure wide links") return
          if (disable_guest == 1 &&
              (key == "map to guest" || key == "restrict anonymous" ||
               key == "usershare allow guests")) return
        } else if (section_name != "") {
          if (key == "wide links") return
          if (disable_guest == 1 && (key == "guest ok" || key == "public")) return
        }
      }
      print raw
    }
    function flush_section(i) {
      for (i = 1; i <= body_count; i++) emit_body_line(body[i])
      if (section_name == "global") emit_global()
      else if (section_name != "") emit_share()
      for (i in body) delete body[i]
      body_count = 0
    }
    BEGIN {
      section_name = ""
      body_count = 0
      global_seen = 0
    }
    /^[[:space:]]*\[[^]]+\][[:space:]]*$/ {
      flush_section()
      print $0
      name = $0
      sub(/^[[:space:]]*\[/, "", name)
      sub(/\][[:space:]]*$/, "", name)
      section_name = tolower(trim(name))
      if (section_name == "global") global_seen = 1
      next
    }
    { body[++body_count] = $0 }
    END {
      flush_section()
      if (!global_seen) {
        print "[global]"
        emit_global()
      }
    }
  ' "$source" > "$destination"
}

# Return a single effective Samba parameter value for a named section.
# testparm's diagnostics are on stderr; the requested parameter is stdout.
appsec_samba_effective_parameter () {
  local config="$1" section="$2" parameter="$3" output
  output="$(testparm -s --section-name="$section" --parameter-name="$parameter" "$config" 2>/dev/null)" || return 1
  output="$(printf '%s\n' "$output" | tail -n 1 | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')"
  [[ -n "$output" ]] || return 1
  printf '%s\n' "$output"
}

# Samba 4.15's testparm may print documented equivalent spellings instead
# of the exact value written in smb.conf:
#   server min protocol SMB2_10 -> SMB2 (SMB2 defaults to the SMB2_10 dialect)
#   server signing mandatory     -> required (a supported synonym)
# Treat only these two documented aliases as equivalent. Other mismatches
# must still fail verification.
appsec_samba_parameter_matches () {
  local parameter="${1,,}" actual="${2,,}" expected="${3,,}"
  case "$parameter:$actual:$expected" in
    'server min protocol:smb2:smb2_10'|'server signing:required:mandatory')
      return 0
      ;;
  esac
  [[ "$actual" == "$expected" ]]
}

# Validate the generated file before it is installed, then validate it again
# after installation. Values are read from testparm's effective per-section
# output rather than grepping the entire rendered smb.conf.
appsec_samba_verify_config () {
  local config="$1" disable_guest="$2"
  local parameter expected actual share_name effective failures=0 check
  local -a global_checks=(
    'server min protocol|SMB2_10'
    'server signing|mandatory'
    'ntlm auth|ntlmv2-only'
    'lanman auth|no'
    'wide links|no'
    'allow insecure wide links|no'
  )

  for check in "${global_checks[@]}"; do
    parameter="${check%%|*}"
    expected="${check#*|}"
    if ! actual="$(appsec_samba_effective_parameter "$config" global "$parameter")"; then
      appsec_fail "Could not read effective Samba global parameter '$parameter' from '$config'."
      failures=1
      continue
    fi
    if ! appsec_samba_parameter_matches "$parameter" "$actual" "$expected"; then
      appsec_fail "Samba global parameter '$parameter' is '$actual'; expected '$expected'."
      failures=1
    fi
  done

  if (( disable_guest )); then
    local -a guest_global_checks=(
      'map to guest|Never'
      'restrict anonymous|2'
      'usershare allow guests|No'
    )
    for check in "${guest_global_checks[@]}"; do
      parameter="${check%%|*}"
      expected="${check#*|}"
      if ! actual="$(appsec_samba_effective_parameter "$config" global "$parameter")"; then
        appsec_fail "Could not read effective Samba global parameter '$parameter' from '$config'."
        failures=1
        continue
      fi
      if ! appsec_samba_parameter_matches "$parameter" "$actual" "$expected"; then
        appsec_fail "Samba global parameter '$parameter' is '$actual'; expected '$expected'."
        failures=1
      fi
    done

    effective="$(testparm -s "$config" 2>/dev/null)" || {
      appsec_fail "Could not enumerate Samba shares in '$config'."
      return 1
    }
    while IFS= read -r share_name; do
      [[ -n "$share_name" ]] || continue
      for parameter in 'guest ok' 'wide links'; do
        if ! actual="$(appsec_samba_effective_parameter "$config" "$share_name" "$parameter")"; then
          appsec_fail "Could not read effective '$parameter' for Samba share [$share_name]."
          failures=1
          continue
        fi
        if [[ "${actual,,}" != no && "${actual,,}" != false && "${actual,,}" != 0 ]]; then
          appsec_fail "Samba share [$share_name] has '$parameter = $actual'; expected no."
          failures=1
        fi
      done
    done < <(printf '%s\n' "$effective" | awk '
      /^[[:space:]]*\[[^]]+\][[:space:]]*$/ {
        n=$0
        gsub(/^[[:space:]]*\[/, "", n)
        gsub(/\][[:space:]]*$/, "", n)
        if (tolower(n) != "global") print n
      }
    ')
  fi

  (( failures == 0 ))
}

appsec_samba_harden () {
  appsec_require_root || return 1
  echo
  echo "============================================================"
  echo "SAMBA SECURITY HARDENING"
  echo "============================================================"
  local share_required=0 required_prompted=0 guest_disable=1 backup tmp service="" active=0
  if ! command -v smbd >/dev/null 2>&1 || [[ ! -f /etc/samba/smb.conf ]] || ! command -v testparm >/dev/null 2>&1; then
    appsec_warn "Samba is not installed/configured."
    appsec_yes_no "Is Samba required by this competition round?" N
    required_prompted=1
    if [[ "$REPLY" != Y ]]; then
      appsec_info "Samba install/configuration skipped because it is not required."
      return 0
    fi
    share_required=1
    appsec_yes_no "Install the Samba server package now?" N
    if [[ "$REPLY" != Y ]]; then
      appsec_warn "Samba is required but was not installed; no configuration was changed."
      return 1
    fi
    if ! DEBIAN_FRONTEND=noninteractive apt-get install -y samba; then
      appsec_fail "Samba installation failed."
      return 1
    fi
    if [[ ! -f /etc/samba/smb.conf ]] || ! command -v testparm >/dev/null 2>&1; then
      appsec_fail "Samba was installed but smb.conf/testparm is still unavailable."
      return 1
    fi
  fi

  appsec_info "Samba package: $(dpkg-query -W -f='${Version}' samba 2>/dev/null || echo installed)"
  appsec_samba_list_shares || true
  appsec_info "Review filesystem ownership/modes for every share path shown above; Samba share rules cannot override unsafe underlying Unix permissions."

  if (( ! required_prompted )); then
    appsec_yes_no "Is Samba required by this competition round?" N
    [[ "$REPLY" == Y ]] && share_required=1
  fi
  appsec_yes_no "Disable guest/public access on every configured share? (Choose No only when the README explicitly requires guest sharing.)" Y
  [[ "$REPLY" == Y ]] && guest_disable=1 || guest_disable=0

  if [[ "$guest_disable" == 0 ]]; then
    appsec_warn "Guest/public share settings will be preserved. The Samba hardening will still enforce SMB2+, signing, and NTLMv2-only authentication."
  fi
  appsec_samba_harden_config_permissions || return 1
  backup="$(appsec_backup_file /etc/samba/smb.conf)" || return 1
  tmp="$(mktemp /etc/samba/.smb.conf.appsec.XXXXXX)" || return 1
  if ! appsec_samba_rewrite_config /etc/samba/smb.conf "$tmp" "$guest_disable"; then
    rm -f "$tmp"
    appsec_fail "Could not create the hardened Samba configuration."
    return 1
  fi
  if ! chown --reference=/etc/samba/smb.conf "$tmp" || ! chmod --reference=/etc/samba/smb.conf "$tmp"; then
    rm -f "$tmp"
    appsec_fail "Could not preserve the approved smb.conf ownership/permissions on the candidate file."
    return 1
  fi
  appsec_samba_prompt_creation_modes "$tmp" || appsec_warn "Samba creation-permission review encountered a problem."
  if ! testparm -s "$tmp" >/dev/null 2>&1; then
    rm -f "$tmp"
    appsec_fail "Samba rejected the candidate configuration; the original file was left unchanged."
    return 1
  fi

  # Verify the candidate before installation. A failed candidate cannot replace
  # the known-good configuration, and its reported values identify the problem.
  if ! appsec_samba_verify_config "$tmp" "$guest_disable"; then
    rm -f "$tmp"
    appsec_fail "Candidate Samba configuration did not satisfy the requested policy; original smb.conf was left untouched."
    return 1
  fi

  # The candidate lives in /etc/samba, so rename is atomic and preserves the
  # ownership/mode explicitly approved (or retained) above.
  if ! mv -f -- "$tmp" /etc/samba/smb.conf; then
    rm -f "$tmp"
    appsec_fail "Could not install the verified Samba configuration; the original file was left untouched."
    return 1
  fi
  appsec_pass "Samba candidate passed syntax and effective-policy checks and was installed. Backup: ${backup:-none}"

  # Recheck the installed file itself: replacing it with a candidate must not
  # accidentally restore a looser mode than the approved competition baseline.
  local installed_meta installed_owner installed_group installed_mode
  installed_meta="$(stat -c '%U|%G|%a' /etc/samba/smb.conf 2>/dev/null)" || installed_meta=""
  IFS='|' read -r installed_owner installed_group installed_mode <<< "$installed_meta"
  if (( APPSEC_SAMBA_CONFIG_0600_APPROVED )); then
    if [[ "$installed_owner" != root || "$installed_group" != root || "$installed_mode" != 600 ]]; then
      appsec_fail "Installed smb.conf metadata is ${installed_owner:-?}:${installed_group:-?} ${installed_mode:-?}; expected root:root 600. Restoring the pre-install backup."
      if [[ -n "$backup" ]]; then
        cp -a -- "$backup" /etc/samba/smb.conf || appsec_fail "Could not restore Samba backup '$backup'."
      fi
      return 1
    fi
    appsec_pass "Installed smb.conf permissions verified: root:root 0600."
  else
    appsec_warn "Installed smb.conf remains ${installed_owner:-?}:${installed_group:-?} ${installed_mode:-?} because the 0600 correction was declined."
  fi

  if ! appsec_samba_verify_config /etc/samba/smb.conf "$guest_disable"; then
    appsec_fail "Installed Samba configuration failed re-verification; restoring the original smb.conf."
    if [[ -n "$backup" ]]; then
      cp -a "$backup" /etc/samba/smb.conf || appsec_fail "Could not restore Samba backup '$backup'."
    else
      appsec_fail "No Samba backup was available for rollback."
    fi
    return 1
  fi
  appsec_pass "Effective Samba global and per-share policies verified."
  appsec_samba_report_creation_modes /etc/samba/smb.conf || appsec_warn "Final Samba creation-permission audit was incomplete."

  if systemctl cat smbd.service >/dev/null 2>&1; then service=smbd
  elif systemctl cat samba.service >/dev/null 2>&1; then service=samba
  else service=""; fi
  if [[ -n "$service" ]] && systemctl is-active --quiet "$service"; then
    active=1
    if command -v smbcontrol >/dev/null 2>&1 && smbcontrol all reload-config >/dev/null 2>&1; then
      appsec_pass "Active Samba service accepted reload-config."
    else
      appsec_fail "Samba runtime reload did not confirm success; restoring the previous smb.conf."
      if [[ -n "$backup" ]]; then cp -a "$backup" /etc/samba/smb.conf || appsec_fail "Could not restore Samba backup '$backup'."; fi
      smbcontrol all reload-config >/dev/null 2>&1 || true
      return 1
    fi
  elif (( share_required )); then
    if [[ -n "$service" ]]; then
      appsec_yes_no "Samba is required but not running. Enable and start $service now?" Y
      if [[ "$REPLY" == Y ]]; then
        if systemctl enable "$service" && systemctl start "$service" && systemctl is-active --quiet "$service"; then
          appsec_pass "Required Samba service is active and enabled."
        else
          appsec_fail "Could not start/enable required Samba service; restoring the previous smb.conf."
          if [[ -n "$backup" ]]; then cp -a "$backup" /etc/samba/smb.conf || appsec_fail "Could not restore Samba backup '$backup'."; fi
          return 1
        fi
      else
        appsec_warn "Samba configuration was hardened but service state was left unchanged."
      fi
    else
      appsec_warn "Samba is required, but no recognized systemd service was found."
    fi
  else
    appsec_info "Samba service is not active and was not started because this round was not marked as requiring it."
  fi

  echo
  echo "============================================================"
  echo "SAMBA SHARE FILESYSTEM-PERMISSION REVIEW"
  echo "============================================================"
  appsec_samba_prompt_share_permissions || appsec_warn "One or more share filesystem-permission checks could not be completed."
  appsec_samba_list_shares || true
  appsec_info "Manual functional check still required: test authentication and read/write behavior from an authorized SMB client for each required share."
}

appsec_samba_change_share_permissions () {
  appsec_require_root || return 1
  local config="${1:-/etc/samba/smb.conf}" test_output share selection index
  local section_details share_path stat_line owner group mode symbolic requested metadata_backup
  local actual_mode requested_value actual_value
  local -a shares=() share_paths=()

  echo
  echo "============================================================"
  echo "MANUAL SAMBA SHARE DIRECTORY PERMISSIONS"
  echo "============================================================"
  if [[ ! -f "$config" ]] || ! command -v testparm >/dev/null 2>&1; then
    appsec_fail "Samba configuration or testparm is unavailable."
    return 1
  fi
  if ! test_output="$(testparm -s "$config" 2>/dev/null)"; then
    appsec_fail "testparm could not parse $config; no permission changes are possible."
    return 1
  fi

  mapfile -t shares < <(printf '%s\n' "$test_output" | awk '
    /^[[:space:]]*\[[^]]+\][[:space:]]*$/ {
      n=$0
      gsub(/^[[:space:]]*\[/, "", n)
      gsub(/\][[:space:]]*$/, "", n)
      if (tolower(n) != "global") print n
    }
  ')
  if (( ${#shares[@]} == 0 )); then
    appsec_info "No configured Samba shares were found."
    return 0
  fi

  for share in "${shares[@]}"; do
    section_details="$(testparm -s --section-name="$share" "$config" 2>/dev/null || true)"
    share_path="$(awk -F= 'tolower($1) ~ /^[[:space:]]*path[[:space:]]*$/ {sub(/^[[:space:]]+/, "", $2); sub(/[[:space:]]+$/, "", $2); print $2; exit}' <<< "$section_details")"
    share_paths+=("$share_path")
  done

  echo "Select a configured share whose directory permissions you want to change:"
  local i
  for (( i=0; i<${#shares[@]}; i++ )); do
    printf '  %2d) [%s] -> %s\n' "$((i + 1))" "${shares[$i]}" "${share_paths[$i]:-(no static path)}"
  done
  echo "   q) Return without making changes"

  while true; do
    if ! read -r -p $'\nSelect share number: ' selection; then selection=q; fi
    case "${selection,,}" in
      q|quit|back) appsec_info "Manual share-permission editor closed."; return 0 ;;
    esac
    if [[ ! "$selection" =~ ^[0-9]+$ ]]; then
      appsec_warn "Enter a share number from the list, or q to return."
      continue
    fi
    # Force base-10 interpretation so inputs such as 08 are not treated as octal.
    index=$((10#$selection - 1))
    if (( index < 0 || index >= ${#shares[@]} )); then
      appsec_warn "Share number is out of range."
      continue
    fi
    break
  done

  share="${shares[$index]}"
  share_path="${share_paths[$index]}"
  if [[ -z "$share_path" ]]; then
    appsec_warn "Share [$share] has no static filesystem path. Nothing was changed."
    return 0
  fi
  if [[ "$share_path" == *%* ]]; then
    appsec_warn "Share [$share] uses Samba variables in its path ($share_path), so its resolved directory depends on the connection. Nothing was changed."
    return 0
  fi
  if [[ "$share_path" != /* ]]; then
    appsec_warn "Share [$share] does not resolve to an absolute filesystem path ($share_path). Nothing was changed."
    return 0
  fi
  if [[ -L "$share_path" ]]; then
    appsec_warn "Share [$share] points to a symbolic link ($share_path). This tool will not chmod through a symbolic link. Review the target manually."
    return 0
  fi
  if [[ ! -d "$share_path" ]]; then
    appsec_warn "Share [$share] directory does not exist: $share_path. Nothing was changed."
    return 0
  fi

  stat_line="$(stat -c '%U|%G|%a|%A' -- "$share_path" 2>/dev/null)" || {
    appsec_fail "Could not inspect $share_path."
    return 1
  }
  IFS='|' read -r owner group mode symbolic <<< "$stat_line"
  echo
  printf 'Selected share: [%s]\n' "$share"
  printf 'Directory:      %s\n' "$share_path"
  printf 'Owner/group:    %s:%s\n' "$owner" "$group"
  printf 'Current mode:   %s (%s)\n' "$mode" "$symbolic"
  appsec_samba_print_acl "$share_path" "Share [$share] path"

  if ! read -r -p $'Enter the new octal mode (3-4 digits, e.g. 2770; blank cancels): ' requested; then requested=""; fi
  if [[ -z "$requested" ]]; then
    appsec_info "No permission change requested."
    return 0
  fi
  if [[ ! "$requested" =~ ^[0-7]{3,4}$ ]]; then
    appsec_warn "Invalid octal mode '$requested'; enter three or four octal digits. Nothing was changed."
    return 1
  fi

  appsec_info "Only the selected directory itself will be changed. Files and subdirectories inside it will not be chmod'ed. Ownership and group will not be changed."
  appsec_yes_no "Apply chmod $requested to $share_path only? Existing extended ACL masks may be affected." N
  if [[ "$REPLY" != Y ]]; then
    appsec_info "Permission change for [$share] cancelled."
    return 0
  fi

  metadata_backup="$(appsec_samba_backup_share_permissions "$share_path")" || {
    appsec_fail "Could not back up [$share] ownership/permissions/ACL; no permission change was made."
    return 1
  }
  appsec_info "Share-root permission backup saved to $metadata_backup"
  if command -v getfacl >/dev/null 2>&1; then
    appsec_info "To restore the saved ACL, ownership, and mode if needed: setfacl --restore='$metadata_backup'"
  else
    appsec_warn "getfacl is unavailable; the backup contains basic owner/group/mode metadata only."
  fi

  if ! chmod -- "$requested" "$share_path"; then
    appsec_fail "Could not change permissions on [$share] path $share_path."
    return 1
  fi
  stat_line="$(stat -c '%U|%G|%a|%A' -- "$share_path" 2>/dev/null)" || stat_line=""
  if [[ -z "$stat_line" ]]; then
    appsec_warn "chmod completed, but the resulting permissions could not be read back."
    return 1
  fi
  IFS='|' read -r owner group actual_mode symbolic <<< "$stat_line"
  requested_value=$((8#$requested))
  actual_value=$((8#$actual_mode))
  if (( requested_value != actual_value )); then
    appsec_fail "Permission verification mismatch: requested $requested, but stat reports $actual_mode. Inspect ACLs and filesystem behavior."
    return 1
  fi
  appsec_pass "[$share] directory mode changed to $actual_mode ($symbolic); owner/group remains $owner:$group."
  appsec_info "Only $share_path itself was changed; no recursive chmod was performed. Backup: $metadata_backup"
  return 0
}

appsec_secure_samba () {
  appsec_require_root || return 1
  while true; do
    echo
    echo "============================================================"
    echo "SAMBA MENU"
    echo "============================================================"
    echo "  1) List all configured shares and their access settings"
    echo "  2) Audit and harden Samba"
    echo "  3) Change permissions on a share directory"
    echo "  4) Return"
    local choice
    if ! read -r -p $'\nSamba choice: ' choice; then return; fi
    case "$choice" in
      1) appsec_samba_list_shares || appsec_warn "Share inventory could not be completed." ;;
      2) appsec_samba_harden || appsec_warn "Samba hardening encountered a failure." ;;
      3) appsec_samba_change_share_permissions || appsec_warn "Manual Samba share-permission change encountered a problem." ;;
      4) return ;;
      *) echo "Invalid option." ;;
    esac
  done
}

# ---------------------------------------------------------------------------
# E. DNS / resolver inventory and role-aware checks (no blind service shutdown)
# ---------------------------------------------------------------------------
appsec_secure_dns () {
  appsec_require_root || return 1
  echo
  echo "============================================================"
  echo "DNS / RESOLVER SECURITY AUDIT"
  echo "============================================================"
  local service package
  for service in systemd-resolved NetworkManager bind9 named dnsmasq; do
    if systemctl cat "$service.service" >/dev/null 2>&1; then
      if systemctl is-active --quiet "$service.service"; then
        appsec_pass "$service.service is active."
      else
        appsec_info "$service.service is installed/known but inactive."
      fi
    fi
  done
  for package in bind9 dnsmasq systemd-resolved network-manager; do
    appsec_is_installed_package "$package" && appsec_info "Package installed: $package ($(dpkg-query -W -f='${Version}' "$package" 2>/dev/null))"
  done

  echo
  echo "--- /etc/resolv.conf ---"
  ls -l /etc/resolv.conf 2>/dev/null || true
  readlink -f /etc/resolv.conf 2>/dev/null || true
  sed -n '1,80p' /etc/resolv.conf 2>/dev/null || true
  if command -v resolvectl >/dev/null 2>&1; then
    echo
    echo "--- resolvectl status ---"
    resolvectl status 2>/dev/null | sed -n '1,100p' || true
  fi
  if command -v nmcli >/dev/null 2>&1; then
    echo
    echo "--- NetworkManager DNS values ---"
    nmcli -t -f DEVICE,IP4.DNS,IP6.DNS device show 2>/dev/null | sed -n '1,100p' || true
  fi
  echo
  echo "--- DNS listeners (port 53) ---"
  if command -v ss >/dev/null 2>&1; then
    ss -lntup 2>/dev/null | awk 'NR==1 || /:53([[:space:]]|$)/' || true
  else
    appsec_warn "ss is not installed; DNS listener inventory unavailable."
  fi

  if command -v named-checkconf >/dev/null 2>&1; then
    if named-checkconf -z >/dev/null 2>&1; then
      appsec_pass "BIND configuration syntax/zone checks passed (named-checkconf -z)."
    else
      appsec_fail "BIND configuration check failed; inspect named-checkconf output manually."
      named-checkconf -z 2>&1 | sed -n '1,80p' || true
    fi
    echo "--- BIND effective security-related settings ---"
    named-checkconf -p 2>/dev/null | grep -Ei '(^|[[:space:]])(recursion|allow-recursion|allow-query-cache|allow-query|listen-on|listen-on-v6|version|dnssec-validation)[[:space:]]' | sed -n '1,100p' || true
  fi
  if [[ -f /etc/dnsmasq.conf ]]; then
    echo
    echo "--- dnsmasq active non-comment directives ---"
    grep -Ev '^[[:space:]]*([#;]|$)' /etc/dnsmasq.conf | sed -n '1,100p' || true
  fi

  appsec_warn "DNS role must be confirmed before changing recursion, listening interfaces, or resolver service state. This audit deliberately does not disable BIND/dnsmasq/systemd-resolved or overwrite DHCP/NetworkManager resolver settings."
  appsec_info "For a required DNS server, confirm authoritative zones, recursion clients, and intended listen addresses in the challenge README before applying a role-specific BIND/dnsmasq policy."
}

# ---------------------------------------------------------------------------
# F. NGINX / Apache
# ---------------------------------------------------------------------------
appsec_harden_apache () {
  local confdir=/etc/apache2/conf-available conf=/etc/apache2/conf-available/zz-noje-appsec.conf
  local enabled=/etc/apache2/conf-enabled/zz-noje-appsec.conf backup_conf="" backup_enabled="" tmp service=apache2
  [[ -d /etc/apache2 ]] || return 0
  mkdir -p "$confdir" /etc/apache2/conf-enabled || return 1
  backup_conf="$(appsec_backup_file "$conf")" || return 1
  backup_enabled="$(appsec_backup_file "$enabled")" || return 1
  tmp="$(mktemp "$confdir/.appsec.XXXXXX")" || return 1
  cat > "$tmp" <<'APACHECONF'
# Managed by NOJE Application Security.
ServerTokens Prod
ServerSignature Off
TraceEnable Off
<Directory /var/www/>
    Options -Indexes
</Directory>
APACHECONF
  chown root:root "$tmp" && chmod 0644 "$tmp" && mv -f "$tmp" "$conf" || { rm -f "$tmp"; return 1; }
  if ! ln -sfn ../conf-available/zz-noje-appsec.conf "$enabled"; then
    appsec_fail "Could not enable the Apache AppSec include; restoring previous files."
    [[ -n "$backup_conf" ]] && cp -a "$backup_conf" "$conf" || rm -f "$conf"
    [[ -n "$backup_enabled" ]] && cp -a "$backup_enabled" "$enabled" || rm -f "$enabled"
    return 1
  fi
  if ! apache2ctl configtest >/dev/null 2>&1; then
    appsec_fail "Apache candidate failed configtest; rolling back the AppSec config."
    [[ -n "$backup_conf" ]] && cp -a "$backup_conf" "$conf" || rm -f "$conf"
    [[ -n "$backup_enabled" ]] && cp -a "$backup_enabled" "$enabled" || rm -f "$enabled"
    return 1
  fi
  appsec_pass "Apache configuration validated: ServerTokens Prod, ServerSignature Off, TraceEnable Off, and no directory indexes under /var/www."
  if systemctl is-active --quiet apache2.service; then
    if systemctl reload apache2.service; then
      appsec_pass "Apache reloaded without changing its enabled/running state."
    else
      appsec_fail "Apache reload failed; restoring the previous AppSec config."
      [[ -n "$backup_conf" ]] && cp -a "$backup_conf" "$conf" || rm -f "$conf"
      [[ -n "$backup_enabled" ]] && cp -a "$backup_enabled" "$enabled" || rm -f "$enabled"
      apache2ctl configtest >/dev/null 2>&1 && systemctl reload apache2.service >/dev/null 2>&1 || true
      return 1
    fi
  else
    appsec_info "Apache was not active; it was not started."
  fi
  local index_overrides apache_roots
  index_overrides="$(grep -RniE 'Options[[:space:]].*\+Indexes|Options[[:space:]]+Indexes' /etc/apache2/sites-enabled /etc/apache2/conf-enabled 2>/dev/null | grep -v 'zz-noje-appsec.conf' || true)"
  if [[ -n "$index_overrides" ]]; then
    printf '%s\n' "$index_overrides" | sed -n '1,30p'
    appsec_warn "Review the displayed site-specific Options directives; more-specific Apache directory blocks may override the generic -Indexes setting."
  fi
  apache_roots="$(grep -RhiE '^[[:space:]]*DocumentRoot[[:space:]]+' /etc/apache2/sites-enabled 2>/dev/null | awk '{print $2}' | sort -u || true)"
  [[ -n "$apache_roots" ]] && { appsec_info "Configured Apache DocumentRoot values:"; printf '%s\n' "$apache_roots"; }
  find /var/www -maxdepth 3 -type f \( -iname 'index.html' -o -iname 'index.htm' -o -iname 'index.php' \) -print 2>/dev/null | sed -n '1,60p' || true
}

appsec_harden_nginx () {
  local conf=/etc/nginx/conf.d/zz-noje-appsec.conf backup="" tmp
  [[ -d /etc/nginx ]] || return 0
  mkdir -p /etc/nginx/conf.d || return 1
  if ! grep -Eq '^[[:space:]]*include[[:space:]]+(/etc/nginx/)?conf\.d/\*\.conf' /etc/nginx/nginx.conf 2>/dev/null; then
    appsec_warn "Nginx does not visibly include conf.d/*.conf from nginx.conf; leaving config unchanged."
    return 0
  fi
  backup="$(appsec_backup_file "$conf")" || return 1
  tmp="$(mktemp /etc/nginx/conf.d/.appsec.XXXXXX)" || return 1
  cat > "$tmp" <<'NGINXCONF'
# Managed by NOJE Application Security. Included from the http context.
server_tokens off;
autoindex off;
NGINXCONF
  chown root:root "$tmp" && chmod 0644 "$tmp" && mv -f "$tmp" "$conf" || { rm -f "$tmp"; return 1; }
  if ! nginx -t >/dev/null 2>&1; then
    appsec_fail "Nginx candidate failed nginx -t; rolling back the AppSec config."
    [[ -n "$backup" ]] && cp -a "$backup" "$conf" || rm -f "$conf"
    return 1
  fi
  appsec_pass "Nginx configuration validated: server_tokens off and autoindex off at http scope."
  if systemctl is-active --quiet nginx.service; then
    if systemctl reload nginx.service; then
      appsec_pass "Nginx reloaded without changing its enabled/running state."
    else
      appsec_fail "Nginx reload failed; restoring the previous AppSec config."
      [[ -n "$backup" ]] && cp -a "$backup" "$conf" || rm -f "$conf"
      nginx -t >/dev/null 2>&1 && systemctl reload nginx.service >/dev/null 2>&1 || true
      return 1
    fi
  else
    appsec_info "Nginx was not active; it was not started."
  fi
  local autoindex_overrides nginx_roots
  autoindex_overrides="$(nginx -T 2>/dev/null | grep -niE 'autoindex[[:space:]]+on' || true)"
  if [[ -n "$autoindex_overrides" ]]; then
    printf '%s\n' "$autoindex_overrides" | sed -n '1,30p'
    appsec_warn "A more-specific server/location block may override http-level autoindex off; review the lines shown above."
  fi
  nginx_roots="$(nginx -T 2>/dev/null | awk '$1=="root" {print $2}' | sed 's/;$//' | sort -u || true)"
  [[ -n "$nginx_roots" ]] && { appsec_info "Configured Nginx root values:"; printf '%s\n' "$nginx_roots"; }
  find /var/www -maxdepth 3 -type f \( -iname 'index.html' -o -iname 'index.htm' -o -iname 'index.php' \) -print 2>/dev/null | sed -n '1,60p' || true
}

appsec_secure_web () {
  appsec_require_root || return 1
  echo
  echo "============================================================"
  echo "NGINX / APACHE SECURITY"
  echo "============================================================"
  local found=0
  if appsec_is_installed_package apache2 || systemctl cat apache2.service >/dev/null 2>&1; then
    found=1
    appsec_info "Apache detected. Active: $(systemctl is-active apache2.service 2>/dev/null || echo unknown); enabled: $(systemctl is-enabled apache2.service 2>/dev/null || echo unknown)"
    appsec_harden_apache || appsec_fail "Apache hardening encountered a failure."
  fi
  if appsec_is_installed_package nginx || systemctl cat nginx.service >/dev/null 2>&1; then
    found=1
    appsec_info "Nginx detected. Active: $(systemctl is-active nginx.service 2>/dev/null || echo unknown); enabled: $(systemctl is-enabled nginx.service 2>/dev/null || echo unknown)"
    appsec_harden_nginx || appsec_fail "Nginx hardening encountered a failure."
  fi
  if (( ! found )); then
    appsec_info "Neither Apache nor Nginx is installed/registered. No packages were installed."
  fi
  appsec_info "Default pages/content were inventoried under /var/www; review each DocumentRoot and required site manually. No website content was deleted."
}
