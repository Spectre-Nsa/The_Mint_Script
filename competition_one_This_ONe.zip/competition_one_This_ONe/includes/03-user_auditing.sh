#!/usr/bin/env bash
# -----------------------------------------------------------------------------
# 03-user_auditing.sh — Linux Mint / Ubuntu-based account auditing
#
# Designed to be sourced by harden.sh.  It deliberately does not enable
# errexit in the parent interactive shell.  When run directly, strict mode is
# enabled for basic error checking, but no action runs automatically.
#
# Competition-operation principles:
#   * Explicit operator-directed actions are not blocked just because an account
#     is root, UID 0, system/service, nobody, active, or the only administrator.
#   * High-impact actions display the target and consequences, then use a simple
#     yes/no confirmation; account deletion asks for the username only.
#   * Shared temporary-password assignment is available as an explicit action;
#     root is always handled by a separate opt-in prompt.
#   * Keep technical input validation, root requirements, and post-change
#     verification. The underlying OS utility may still reject an operation.
# -----------------------------------------------------------------------------

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  set -o nounset
  set -o pipefail
fi

# Use the colors from config.sh when sourced by harden.sh; remain readable when
# the module is tested or sourced independently.
UA_CYAN="${CYAN:-}"
UA_GREEN="${GREEN:-}"
UA_YELLOW="${YELLOW:-}"
UA_RED="${RED:-}"
UA_RESET="${NC:-}"

ua_msg_pass() { printf '%b[PASS]%b %s\n' "$UA_GREEN" "$UA_RESET" "$*"; }
ua_msg_warn() { printf '%b[WARN]%b %s\n' "$UA_YELLOW" "$UA_RESET" "$*"; }
ua_msg_error() { printf '%b[ERROR]%b %s\n' "$UA_RED" "$UA_RESET" "$*" >&2; }
ua_msg_info() { printf '%b[INFO]%b %s\n' "$UA_CYAN" "$UA_RESET" "$*"; }

ua_require_root() {
  if [[ "${EUID:-$(id -u)}" -ne 0 ]]; then
    ua_msg_error "This action requires root. Run the main hardening script with sudo."
    return 1
  fi
}

ua_uid_min() {
  local value
  value="$(awk '$1 == "UID_MIN" { print $2; exit }' /etc/login.defs 2>/dev/null || true)"
  [[ "$value" =~ ^[0-9]+$ ]] || value=1000
  printf '%s\n' "$value"
}

ua_nologin_path() {
  if [[ -x /usr/sbin/nologin ]]; then
    printf '%s\n' /usr/sbin/nologin
  elif [[ -x /sbin/nologin ]]; then
    printf '%s\n' /sbin/nologin
  else
    return 1
  fi
}

ua_valid_username() {
  # Debian's normal account-name constraints; reject leading dashes and
  # shell metacharacters before passing a name to account-management tools.
  [[ "$1" =~ ^[A-Za-z_][A-Za-z0-9_.-]*[$]?$ ]]
}

ua_is_local_user() {
  local user="$1"
  awk -F: -v name="$user" '$1 == name { found=1 } END { exit(found ? 0 : 1) }' /etc/passwd
}

ua_is_local_group() {
  local group="$1"
  awk -F: -v name="$group" '$1 == name { found=1 } END { exit(found ? 0 : 1) }' /etc/group
}

ua_user_groups() {
  id -nG -- "$1" 2>/dev/null || true
}

ua_group_list_has() {
  local groups="$1" group="$2"
  [[ " $groups " == *" $group "* ]]
}

ua_user_in_group() {
  ua_group_list_has "$(ua_user_groups "$1")" "$2"
}

ua_user_sudo_access_class() {
  # One sudo -l query yields FULL, REVIEW, LIMITED, NONE, or UNCHECKED. This avoids
  # repeating sudo policy lookups during the detailed account inventory.
  local user="$1" listing
  command -v sudo >/dev/null 2>&1 || { printf '%s\n' UNCHECKED; return 0; }
  listing="$(LC_ALL=C sudo -n -l -U "$user" 2>/dev/null || true)"
  [[ -n "$listing" ]] || { printf '%s\n' UNCHECKED; return 0; }
  awk '
    /may run the following commands/ { in_commands=1; next }
    /is not allowed to run sudo|may not run sudo|not permitted to run sudo/ { denied=1 }
    in_commands && /^[[:space:]]*\(/ {
      any=1
      if ($0 ~ /^[[:space:]]*\([^)]*\)[[:space:]]*([[:alnum:]_]+:[[:space:]]*)*ALL([[:space:]]*(,|$))/)
        full=1
      # A limited command list can still expose a root shell or a known
      # shell-escape/admin utility. Treat that as REVIEW, not harmless LIMITED.
      if ($0 ~ /\/(ba)?sh([[:space:],]|$)|\/(zsh|dash|ksh|python[0-9.]*|perl|ruby|node|php|lua|vim[^[:space:]]*|vi|less|more|find|awk|gawk|systemctl|service|apt(-get)?|dpkg|snap|docker|podman|lxc|lxd|incus|containerd|mount|umount|chmod|chown|chpasswd|passwd|usermod|useradd|userdel|groupadd|gpasswd|visudo|sudo|env|tee|dd|install|cp|mv|tar|rsync|sudoedit|pkexec)([[:space:],]|$)/)
        risky=1
    }
    END {
      if (full) print "FULL"
      else if (risky) print "REVIEW"
      else if (any) print "LIMITED"
      else if (denied || in_commands) print "NONE"
      else print "UNCHECKED"
    }
  ' <<< "$listing"
}

ua_user_has_effective_sudo_rule() {
  local access
  access="$(ua_user_sudo_access_class "$1")"
  [[ "$access" == FULL || "$access" == LIMITED || "$access" == REVIEW ]]
}

ua_user_has_unrestricted_sudo_rule() {
  [[ "$(ua_user_sudo_access_class "$1")" == FULL ]]
}

ua_user_is_admin() {
  # Group membership, unrestricted sudo, or shell-capable grants are admin-equivalent.
  # A narrow helper grant (for example, Mint cache refresh) is not.
  local access
  if ua_user_in_group "$1" sudo || ua_user_in_group "$1" wheel || ua_user_in_group "$1" admin; then
    return 0
  fi
  access="$(ua_user_sudo_access_class "$1")"
  [[ "$access" == FULL || "$access" == REVIEW ]]
}

ua_sudoers_active_files() {
  [[ -f /etc/sudoers ]] && printf '%s\n' /etc/sudoers
  local file base
  if [[ -d /etc/sudoers.d ]]; then
    for file in /etc/sudoers.d/*; do
      [[ -f "$file" ]] || continue
      base="${file##*/}"
      # sudo's includedir ignores hidden names, names containing a dot, and
      # backup names ending in '~'. Only scan files that can be active there.
      [[ "$base" == .* || "$base" == *.* || "$base" == *~ ]] && continue
      printf '%s\n' "$file"
    done
  fi
}

ua_privilege_scan_dirs() {
  # Scan executable locations and optional application bin directories. Resolve
  # /bin,/sbin,/lib aliases first so merged-/usr systems are not scanned twice.
  # Avoid arbitrary caches, home documents, and package data trees.
  local dir resolved
  local -A seen=()
  for dir in /usr/bin /usr/sbin /usr/lib /usr/libexec /usr/local/bin /usr/local/sbin \
             /bin /sbin /lib /lib64 /snap /opt/bin /opt/sbin /opt/*/bin /opt/*/sbin; do
    [[ -d "$dir" ]] || continue
    resolved="$(readlink -f -- "$dir" 2>/dev/null || printf '%s' "$dir")"
    [[ -n "$resolved" ]] || continue
    if [[ -z "${seen[$resolved]+present}" ]]; then
      seen[$resolved]=1
      printf '%s\n' "$resolved"
    fi
  done
}

# Resolve Debian package ownership across merged-/usr aliases. dpkg may record
# /sbin/foo even when find reports /usr/sbin/foo (and similarly for /bin,/lib).
ua_package_owner_for_path() {
  local input="$1" resolved candidate output
  local -a candidates=()
  [[ -e "$input" ]] || { printf '%s\n' ABSENT; return 0; }
  candidates+=("$input")
  resolved="$(readlink -f -- "$input" 2>/dev/null || true)"
  [[ -n "$resolved" && "$resolved" != "$input" ]] && candidates+=("$resolved")

  local initial_count=${#candidates[@]} i
  for ((i=0; i<initial_count; i++)); do
    candidate="${candidates[$i]}"
    case "$candidate" in
      /usr/sbin/*) candidates+=("/sbin/${candidate#/usr/sbin/}") ;;
      /sbin/*) candidates+=("/usr/sbin/${candidate#/sbin/}") ;;
      /usr/bin/*) candidates+=("/bin/${candidate#/usr/bin/}") ;;
      /bin/*) candidates+=("/usr/bin/${candidate#/bin/}") ;;
      /usr/lib/*) candidates+=("/lib/${candidate#/usr/lib/}") ;;
      /lib/*) candidates+=("/usr/lib/${candidate#/lib/}") ;;
      /usr/lib64/*) candidates+=("/lib64/${candidate#/usr/lib64/}") ;;
      /lib64/*) candidates+=("/usr/lib64/${candidate#/lib64/}") ;;
    esac
  done

  for candidate in "${candidates[@]}"; do
    output="$(dpkg-query -S -- "$candidate" 2>/dev/null | head -n1 || true)"
    if [[ -n "$output" ]]; then
      printf '%s\n' "${output%%: *}"
      return 0
    fi
  done
  printf '%s\n' UNOWNED
}

# Return human-readable trust issues for a privileged executable and every
# parent directory up to /. Empty output means root-owned/non-writable path.
ua_privileged_path_trust_issues() {
  local path="$1" resolved="$2" owner group mode dir canonical_dir details=""
  local -A checked_dirs=()
  read -r owner group mode < <(stat -Lc '%u %g %a' "$resolved" 2>/dev/null || printf '? ? ?\n')
  if [[ "$owner" != 0 ]]; then details+="file owner UID=$owner; "; fi
  if [[ ! "$mode" =~ ^[0-7]{3,4}$ ]]; then
    details+="file mode could not be read; "
  elif (( (8#$mode) & 0022 )); then
    details+="file mode=$mode is group/other-writable; "
  fi
  if [[ -L "$path" ]]; then
    owner="$(stat -c '%u' "$path" 2>/dev/null || printf '?')"
    [[ "$owner" == 0 ]] || details+="symlink owner UID=$owner; "
  fi

  # Check parent chains for both the sudoers path and its resolved target. This
  # matters when a privileged command is a symlink placed in a writable folder.
  for dir in "$(dirname -- "$path")" "$(dirname -- "$resolved")"; do
    while [[ -n "$dir" && "$dir" != / ]]; do
      canonical_dir="$(readlink -f -- "$dir" 2>/dev/null || printf '%s' "$dir")"
      if [[ -n "${checked_dirs[$canonical_dir]+present}" ]]; then break; fi
      checked_dirs[$canonical_dir]=1
      read -r owner group mode < <(stat -Lc '%u %g %a' "$dir" 2>/dev/null || printf '? ? ?\n')
      if [[ "$owner" != 0 ]]; then details+="parent $dir owner UID=$owner; "; fi
      if [[ ! "$mode" =~ ^[0-7]{3,4}$ ]]; then
        details+="parent $dir mode could not be read; "
      elif (( (8#$mode) & 0022 )); then
        details+="parent $dir mode=$mode is group/other-writable; "
      fi
      dir="$(dirname -- "$dir")"
    done
  done
  printf '%s\n' "${details%; }"
}

ua_is_known_package_capability() {
  local path="$1" caps="$2" package="$3"
  case "$path|$caps" in
    "/usr/lib/x86_64-linux-gnu/gstreamer1.0/gstreamer-1.0/gst-ptp-helper|cap_net_bind_service,cap_net_admin=ep")
      [[ "$package" == libgstreamer1.0-0 || "$package" == libgstreamer1.0-0:* ]] && return 0
      ;;
    "/usr/bin/dumpcap|cap_net_admin,cap_net_raw=eip")
      [[ "$package" == wireshark-common || "$package" == wireshark-common:* ]] && return 0
      ;;
  esac
  return 1
}

ua_report_nopasswd_command_integrity() {
  local file line_no rule after spec path resolved package trust owner link_target result=0
  local -a specs=()
  local -i inspected=0
  echo
  echo "[4] PASSWORDLESS SUDO COMMAND INTEGRITY"
  for file in "$@"; do
    [[ -f "$file" ]] || continue
    while IFS=: read -r line_no rule; do
      [[ "$rule" == *NOPASSWD:* ]] || continue
      after="${rule#*NOPASSWD:}"
      IFS=',' read -r -a specs <<< "$after"
      for spec in "${specs[@]}"; do
        spec="$(sed -E 's/^[[:space:]]+//; s/[[:space:]]+$//' <<< "$spec")"
        # Sudo tags can be repeated between comma-separated command specs.
        while [[ "$spec" =~ ^(PASSWD|NOPASSWD|NOEXEC|EXEC|SETENV|NOSETENV|FOLLOW|NOFOLLOW|INTERCEPT|NOINTERCEPT|LOG_INPUT|NOLOG_INPUT|LOG_OUTPUT|NOLOG_OUTPUT):[[:space:]]* ]]; do
          spec="${spec#*:}"
          spec="$(sed -E 's/^[[:space:]]+//; s/[[:space:]]+$//' <<< "$spec")"
        done
        [[ -n "$spec" ]] || continue
        if [[ "$spec" == ALL || "$spec" == ALL\ * ]]; then
          printf '[INFO] %s:%s grants NOPASSWD: ALL; unrestricted-command scope is classified in section 2.\n' "$file" "$line_no"
          continue
        fi
        if [[ "$spec" == !* ]]; then
          printf '[INFO] %s:%s contains a negated NOPASSWD command specification; review the complete rule: %s\n' "$file" "$line_no" "$spec"
          continue
        fi
        if [[ "$spec" =~ ^(/[^[:space:]]+) ]]; then
          path="${BASH_REMATCH[1]}"
        else
          printf '[REVIEW] %s:%s has a NOPASSWD command/alias that this path scanner cannot resolve: %s\n' "$file" "$line_no" "$spec"
          result=1
          continue
        fi

        ((inspected+=1))
        if [[ ! -e "$path" ]]; then
          if [[ -L "$path" ]]; then
            printf '[HIGH] %s:%s NOPASSWD target is a broken symlink: %s\n' "$file" "$line_no" "$path"
          else
            printf '[HIGH] %s:%s NOPASSWD target does not exist: %s\n' "$file" "$line_no" "$path"
          fi
          result=1
          continue
        fi
        resolved="$(readlink -f -- "$path" 2>/dev/null || true)"
        [[ -n "$resolved" ]] || resolved="$path"
        package="$(ua_package_owner_for_path "$path")"
        trust="$(ua_privileged_path_trust_issues "$path" "$resolved")"
        link_target=""
        [[ -L "$path" ]] && link_target=" (symlink -> $(readlink -- "$path" 2>/dev/null || printf '?'))"

        if [[ -n "$trust" ]]; then
          printf '[CRITICAL] %s:%s NOPASSWD target has unsafe ownership/permissions: %s%s\n  %s\n' \
            "$file" "$line_no" "$path" "$link_target" "$trust"
          result=1
        elif [[ "$package" == UNOWNED ]]; then
          printf '[HIGH] %s:%s NOPASSWD target is not owned by an installed package: %s%s (resolved=%s)\n' \
            "$file" "$line_no" "$path" "$link_target" "$resolved"
          result=1
        elif [[ "$package" == mintupdate && ( "$resolved" == /usr/bin/mint-refresh-cache || \
              "$resolved" == /usr/lib/linuxmint/mintUpdate/synaptic-workaround.py || \
              "$resolved" == /usr/lib/linuxmint/mintUpdate/dpkg_lock_check.sh ) ]]; then
          printf '[INFO] PACKAGE-INTENDED Mint Update helper: %s (%s), root-owned path is not group/other-writable.\n' "$path" "$package"
        else
          printf '[REVIEW] %s:%s NOPASSWD target is package-owned (%s): %s%s; inspect command behavior and permitted arguments.\n' \
            "$file" "$line_no" "$package" "$path" "$link_target"
          result=1
        fi
      done
    done < <(grep -nE '^[[:space:]]*[^#].*NOPASSWD:' "$file" 2>/dev/null || true)
  done
  if (( inspected == 0 && result == 0 )); then
    ua_msg_pass "No discrete NOPASSWD executable targets required integrity review (broad ALL rules are reported in section 2)."
  fi
  return "$result"
}

ua_is_common_setid_path() {
  case "$1" in
    /usr/bin/at|/usr/bin/chage|/usr/bin/chfn|/usr/bin/chsh|/usr/bin/crontab|/usr/bin/expiry|/usr/bin/fusermount|/usr/bin/fusermount3|/usr/bin/gpasswd|/usr/bin/mount|/usr/bin/newgrp|/usr/bin/passwd|/usr/bin/ping|/usr/bin/pkexec|/usr/bin/su|/usr/bin/sudo|/usr/bin/umount|/usr/bin/wall|/usr/bin/write|/usr/sbin/pppd|/usr/sbin/unix_chkpwd|/usr/lib/dbus-1.0/dbus-daemon-launch-helper|/usr/libexec/dbus-1/dbus-daemon-launch-helper|/usr/lib/polkit-1/polkit-agent-helper-1|/usr/lib/policykit-1/polkit-agent-helper-1|/usr/libexec/polkit-agent-helper-1|/usr/lib/openssh/ssh-keysign|/usr/libexec/openssh/ssh-keysign|/usr/lib/snapd/snap-confine*|/usr/lib/xorg/Xorg.wrap|/usr/lib*/utempter/utempter)
      return 0
      ;;
    *)
      return 1
      ;;
  esac
}

ua_is_interactive_shell() {
  local shell="$1"
  [[ -n "$shell" && -x "$shell" ]] || return 1
  grep -Fqx -- "$shell" /etc/shells 2>/dev/null
}

ua_is_plausible_human_home() {
  local home="$1"
  [[ -n "$home" && "$home" != "/" && "$home" != "/root" && "$home" != "/home" \
     && "$home" != "/nonexistent" && "$home" != "/tmp" && "$home" != "/var" \
     && "$home" != "/run" && "$home" != "/usr" && "$home" != "/opt" \
     && "$home" != /tmp/* && "$home" != /var/* && "$home" != /run/* \
     && "$home" != /usr/* && "$home" != /opt/* && -d "$home" ]]
}

# Classification is deliberately conservative:
#   * UID 0 and UID 65534 are special identities, never ordinary users.
#   * UID >= UID_MIN is a normal human candidate only with an executable,
#     listed login shell AND an existing, non-placeholder home directory.
#   * High-UID accounts with unusual/missing homes and low-UID accounts with
#     /home paths are review-only and need account-specific approval before
#     password or aging changes.
#   * Other low-UID login-shell accounts are surfaced for shell review only.
ua_classify_account() {
  local user="$1" uid="$2" home="$3" shell="$4" uid_min="$5"

  if [[ "$uid" == 0 ]]; then
    printf '%s\n' "ROOT/UID0"
  elif [[ "$uid" == 65534 ]]; then
    printf '%s\n' "SYSTEM/SPECIAL-UID-65534"
  elif [[ "$uid" =~ ^[0-9]+$ && "$uid" -ge "$uid_min" ]]; then
    if ua_is_interactive_shell "$shell"; then
      if ua_is_plausible_human_home "$home"; then
        printf '%s\n' "HUMAN-CANDIDATE"
      else
        printf '%s\n' "UID-MIN-LOGIN-REVIEW"
      fi
    else
      printf '%s\n' "UID-MIN-NONINTERACTIVE-REVIEW"
    fi
  elif [[ "$uid" =~ ^[0-9]+$ && "$uid" -lt "$uid_min" && "$home" == /home/* ]]; then
    printf '%s\n' "LOW-UID-HUMAN-LIKE-REVIEW"
  elif ua_user_in_group "$user" sudo || ua_user_in_group "$user" wheel || ua_user_in_group "$user" admin; then
    printf '%s\n' "LOW-UID-ADMIN-REVIEW"
  elif ua_is_interactive_shell "$shell"; then
    printf '%s\n' "LOW-UID-LOGIN-SHELL-REVIEW"
  else
    printf '%s\n' "SYSTEM/SERVICE"
  fi
}

ua_require_local_human_candidate() {
  local user="$1" record uid home shell uid_min class confirm
  ua_valid_username "$user" || {
    ua_msg_error "Invalid account name: $user"
    return 1
  }
  ua_is_local_user "$user" || {
    ua_msg_error "'$user' is not a local account in /etc/passwd; remote/NSS accounts are inventory-only."
    return 1
  }
  record="$(getent passwd "$user" 2>/dev/null || true)"
  [[ -n "$record" ]] || {
    ua_msg_error "Could not retrieve account record for '$user'."
    return 1
  }
  IFS=: read -r _ _ uid _ _ home shell <<< "$record"
  uid_min="$(ua_uid_min)"
  class="$(ua_classify_account "$user" "$uid" "$home" "$shell" "$uid_min")"
  case "$class" in
    HUMAN-CANDIDATE)
      return 0
      ;;
    LOW-UID-HUMAN-LIKE-REVIEW|UID-MIN-LOGIN-REVIEW)
      if [[ "$class" == LOW-UID-HUMAN-LIKE-REVIEW ]]; then
        ua_msg_warn "'$user' has a low UID. A /home path alone does not prove it is a human account."
      else
        ua_msg_warn "'$user' has UID >= UID_MIN and an interactive shell, but its home directory is missing or nonstandard."
      fi
      read -r -p "Do you positively identify '$user' as a human account? [y/N] " confirm </dev/tty || confirm=""
      confirm="${confirm:-N}"
      [[ "$confirm" =~ ^[Yy]$ ]] || {
        ua_msg_info "No password change was made for '$user'."
        return 1
      }
      return 0
      ;;
    *)
      ua_msg_warn "'$user' is classified as $class (UID=$uid, HOME=$home, SHELL=$shell)."
      read -r -p "Proceed with the requested password action for '$user' anyway? [y/N] " confirm </dev/tty || confirm=""
      [[ "$confirm" =~ ^[Yy]$ ]] || {
        ua_msg_info "Password action skipped for '$user'."
        return 1
      }
      return 0
      ;;
  esac
}

ua_print_account_record() {
  local user="$1" uid="$2" gid="$3" home="$4" shell="$5" uid_min="$6"
  local class groups admin_label=""
  class="$(ua_classify_account "$user" "$uid" "$home" "$shell" "$uid_min")"
  groups="$(ua_user_groups "$user")"
  # The inventory marker is group-based for speed. The dedicated
  # administrator inventory separately checks effective sudoers rules.
  if ua_user_in_group "$user" sudo || ua_user_in_group "$user" wheel || ua_user_in_group "$user" admin; then admin_label=" ADMIN-GROUP"; fi
  printf '%-31s UID=%-6s GID=%-6s GROUPS=%-32s HOME=%-24s SHELL=%s%s\n' \
    "$class" "$uid" "$gid" "${groups:-unknown}" "$home" "$shell" "$admin_label"
}

# -----------------------------------------------------------------------------
# Main User Auditing submenu
# -----------------------------------------------------------------------------
invoke_user_auditing() {
  local choice submenu_failures=0
  while true; do
    echo
    echo "============================================================"
    echo "USER AUDITING"
    echo "============================================================"
    echo "1) Run normal account auditing"
    echo "2) Manage users and group memberships"
    echo "3) Disable LightDM guest session"
    echo "4) Detailed privilege security report (read-only)"
    echo "5) Password aging policy"
    echo "6) Return to the main menu"
    echo

    if ! IFS= read -r -p "Choose an option [1-6]: " choice </dev/tty; then
      return 0
    fi

    case "${choice,,}" in
      1)
        if ! ua_run_normal_user_auditing; then
          ua_msg_warn "Normal account auditing finished with one or more issues. Review the messages above."
          submenu_failures=1
        fi
        ;;
      2)
        if ! ua_manage_users_groups; then
          ua_msg_warn "User/group management ended with an issue."
          submenu_failures=1
        fi
        ;;
      3)
        if ! ua_disable_lightdm_guest_session; then
          ua_msg_warn "LightDM guest-session setting needs attention."
          submenu_failures=1
        fi
        ;;
      4)
        if ! ua_detailed_privilege_security_report; then
          ua_msg_warn "The privilege report completed with one or more checks that could not be verified."
        fi
        ;;
      5)
        ua_set_password_aging_policy || ua_msg_warn "Password-aging policy action reported one or more failures."
        ;;
      6|q|quit|b|back)
        (( submenu_failures == 0 ))
        return $?
        ;;
      *)
        ua_msg_warn "Invalid selection. Enter 1, 2, 3, 4, 5, or 6."
        ;;
    esac
  done
}

# -----------------------------------------------------------------------------
# Normal account audit: inventory -> account review -> admin review ->
# password-status review -> UID 0 review -> service-shell review -> final
# verification. Password aging is a separate User Auditing menu action.
# -----------------------------------------------------------------------------
ua_run_normal_user_auditing() {
  local failures=0
  ua_require_root || return 1

  echo
  echo "============================================================"
  echo "NORMAL USER AUDIT"
  echo "============================================================"
  ua_msg_info "The audit will show account classifications before offering changes."
  ua_msg_info "Human accounts are not automatically removed or given a shared password."

  ua_overview_real_users || ((failures+=1))
  ua_audit_interactive_remove_unauthorized_users || ((failures+=1))
  ua_overview_administrators || ((failures+=1))
  ua_audit_interactive_remove_unauthorized_admins || ((failures+=1))
  ua_privilege_anomaly_summary
  ua_audit_password_status || ((failures+=1))
  ua_review_non_root_uid0 || ((failures+=1))
  ua_review_system_account_shells || ((failures+=1))
  ua_verify_account_state || ((failures+=1))

  echo
  if (( failures == 0 )); then
    ua_msg_pass "Normal user audit completed. Review the PASS/SKIP messages for actions intentionally left unchanged."
    return 0
  fi
  ua_msg_warn "Normal user audit completed with $failures section(s) requiring attention."
  return 1
}

# -----------------------------------------------------------------------------
# Account discovery.  Shows all NSS accounts, clearly separating standard
# human candidates, low-UID human-like/review candidates, and service accounts.
# -----------------------------------------------------------------------------
ua_overview_real_users() {
  local uid_min user _ uid gid gecos home shell count_human=0 count_review=0 count_uid_review=0 count_system=0 count_root=0
  uid_min="$(ua_uid_min)"

  echo
  echo "================ ACCOUNT INVENTORY ================="
  printf 'UID_MIN from /etc/login.defs: %s\n' "$uid_min"
  echo "Classification is heuristic: normal human candidates need UID_MIN+, an executable listed login shell, and an existing home directory. Review-only accounts need manual confirmation."
  echo

  while IFS=: read -r user _ uid gid gecos home shell; do
    [[ "$uid" =~ ^[0-9]+$ ]] || continue
    ua_print_account_record "$user" "$uid" "$gid" "$home" "$shell" "$uid_min"
    case "$(ua_classify_account "$user" "$uid" "$home" "$shell" "$uid_min")" in
      ROOT/UID0) ((count_root+=1)) ;;
      HUMAN-CANDIDATE) ((count_human+=1)) ;;
      LOW-UID-*) ((count_review+=1)) ;;
      UID-MIN-LOGIN-REVIEW|UID-MIN-NONINTERACTIVE-REVIEW) ((count_uid_review+=1)) ;;
      *) ((count_system+=1)) ;;
    esac
  done < <(getent passwd)

  echo
  printf 'Summary: root/UID0=%d | human candidates=%d | low-UID review=%d | UID_MIN review=%d | system/service=%d\n' \
    "$count_root" "$count_human" "$count_review" "$count_uid_review" "$count_system"
  echo "====================================================="
  echo
}

# -----------------------------------------------------------------------------
# Human account authorization review. Default is KEEP. The full deletion
# workflow asks only for the selected username before proceeding.
# -----------------------------------------------------------------------------
ua_audit_interactive_remove_unauthorized_users() {
  local uid_min user _ uid gid gecos home shell class answer
  ua_require_root || return 1
  uid_min="$(ua_uid_min)"

  echo
  echo "================ HUMAN ACCOUNT REVIEW ==============="
  echo "Only HUMAN-CANDIDATE and LOW-UID-HUMAN-LIKE-REVIEW accounts are offered."
  echo "Default: keep the account. Remote/NSS accounts are inventory-only."

  while IFS=: read -r user _ uid gid gecos home shell; do
    [[ "$uid" =~ ^[0-9]+$ ]] || continue
    [[ "$user" != root && "$uid" != 0 && "$uid" != 65534 ]] || continue
    class="$(ua_classify_account "$user" "$uid" "$home" "$shell" "$uid_min")"
    case "$class" in
      HUMAN-CANDIDATE|LOW-UID-HUMAN-LIKE-REVIEW|UID-MIN-LOGIN-REVIEW) ;;
      *) continue ;;
    esac

    printf '\nCandidate: %s | UID=%s | HOME=%s | SHELL=%s | CLASS=%s\n' \
      "$user" "$uid" "$home" "$shell" "$class"
    case "$class" in
      LOW-UID-HUMAN-LIKE-REVIEW)
        ua_msg_warn "This account has a low UID but a /home directory; verify it is actually an ordinary user."
        ;;
      UID-MIN-LOGIN-REVIEW)
        ua_msg_warn "This account has UID >= UID_MIN but a missing/nonstandard home; verify it is actually an ordinary user."
        ;;
    esac
    # The account list is supplied through process substitution. Read the
    # operator's answer from the terminal so it cannot consume the next passwd row.
    read -r -p "Is '$user' authorized? [Y/n] " answer </dev/tty || answer=""
    answer="${answer:-Y}"

    if [[ "$answer" =~ ^[Nn]$ ]]; then
      ua_msg_warn "Opening the full-override deletion workflow for '$user'."
      ua_delete_local_user "$user" || ua_msg_warn "Deletion of '$user' did not complete."

    else
      ua_msg_pass "Kept '$user' (authorized/default keep)."
    fi
  done < <(getent passwd)

  echo "====================================================="
  return 0
}

# -----------------------------------------------------------------------------
# Privilege anomaly summary and detailed read-only report.
# The normal audit calls only the compact summary. Use submenu option 4 for the
# detailed review; this keeps routine account auditing readable and avoids
# prompting on every service account.
# -----------------------------------------------------------------------------
ua_print_sudoers_matches() {
  local label="$1" pattern="$2" file matches line found=0 details=""
  shift 2
  for file in "$@"; do
    [[ -f "$file" ]] || continue
    matches="$(grep -nE "$pattern" "$file" 2>/dev/null | grep -vE '^[0-9]+:[[:space:]]*#' || true)"
    [[ -n "$matches" ]] || continue
    while IFS= read -r line; do
      details+="  $file:$line"$'\n'
      found=1
    done <<< "$matches"
  done
  if (( found )); then
    printf '%s\n%s' "$label" "$details"
    return 0
  fi
  return 1
}

ua_print_nonroot_nopasswd_all() {
  local label="$1" file matches line found=0 details=""
  shift
  for file in "$@"; do
    [[ -f "$file" ]] || continue
    matches="$(awk '
      /^[[:space:]]*#/ { next }
      /^[[:space:]]*Defaults([[:space:]]|$)/ { next }
      {
        line=$0
        sub(/^[[:space:]]*/, "", line)
        first=line
        sub(/[[:space:]].*$/, "", first)
        if (first != "root" && line ~ /NOPASSWD:[[:space:]]*ALL([[:space:]]*(,|$))/)
          printf "%d:%s\n", NR, $0
      }
    ' "$file" 2>/dev/null)"
    [[ -n "$matches" ]] || continue
    while IFS= read -r line; do
      details+="  $file:$line"$'\n'
      found=1
    done <<< "$matches"
  done
  if (( found )); then
    printf '%s\n%s' "$label" "$details"
    return 0
  fi
  return 1
}

ua_print_universal_limited_sudoers_rules() {
  local label="$1" file matches line found=0 details=""
  shift
  for file in "$@"; do
    [[ -f "$file" ]] || continue
    matches="$(awk '
      /^[[:space:]]*#/ { next }
      /^[[:space:]]*ALL[[:space:]]+ALL[[:space:]]*=/ {
        original=$0
        commands=$0
        sub(/^[^=]*=[[:space:]]*/, "", commands)
        sub(/^[[:space:]]*\([^)]*\)[[:space:]]*/, "", commands)
        n=split(commands, parts, ",")
        limited=0
        for (i=1; i<=n; i++) {
          part=parts[i]
          gsub(/^[[:space:]]+|[[:space:]]+$/, "", part)
          while (part ~ /^(NOPASSWD|PASSWD|NOEXEC|EXEC|SETENV|NOSETENV):/) sub(/^[^:]*:[[:space:]]*/, "", part)
          gsub(/^[[:space:]]+|[[:space:]]+$/, "", part)
          if (part != "" && part !~ /^ALL([[:space:]]|$)/) limited=1
        }
        if (limited) printf "%d:%s\n", NR, original
      }
    ' "$file" 2>/dev/null)"
    [[ -n "$matches" ]] || continue
    while IFS= read -r line; do
      details+="  $file:$line"$'\n'
      found=1
    done <<< "$matches"
  done
  if (( found )); then
    printf '%s\n%s' "$label" "$details"
    return 0
  fi
  return 1
}

ua_privilege_anomaly_summary() {
  local flags=0 owner group mode uid_min user _ uid gid gecos home shell class access groups
  local account_flag group_name
  local -a sudo_files=() scan_dirs=()
  local -a service_admin_groups=(sudo wheel admin)
  local -a service_root_groups=(disk docker lxd incus incus-admin containerd podman shadow adm systemd-journal wireshark lpadmin input)
  local -a human_sensitive_groups=(disk docker lxd incus incus-admin containerd podman shadow adm systemd-journal wireshark lpadmin input libvirt kvm)
  mapfile -t sudo_files < <(ua_sudoers_active_files)
  mapfile -t scan_dirs < <(ua_privilege_scan_dirs)

  # High-risk policy patterns are quick source-line checks. The detailed report
  # shows exact file/line evidence and handles additional categories.
  if ((${#sudo_files[@]} == 0)); then
    ((flags+=1))
  else
    if grep -Eiq '^[[:space:]]*ALL[[:space:]]+ALL[[:space:]]*=[[:space:]]*([(][^)]*[)][[:space:]]*)?(NOPASSWD:[[:space:]]*)?ALL([[:space:]]*(,|$))' "${sudo_files[@]}" 2>/dev/null; then
      ((flags+=1))
    fi
    if grep -Eiq '^[[:space:]]*Defaults([^#]*)(!authenticate|!secure_path|!env_reset|exempt_group[[:space:]]*=|timestamp_timeout[[:space:]]*=[[:space:]]*-1|env_keep[^#]*(LD_PRELOAD|LD_LIBRARY_PATH|LD_AUDIT|GCONV_PATH|PYTHONPATH|PYTHONHOME|PERL5LIB|RUBYOPT|BASH_ENV|ENV|PATH))' "${sudo_files[@]}" 2>/dev/null; then
      ((flags+=1))
    fi
    if grep -Eiq '^[[:space:]]*Defaults([^#]*)[[:space:],]setenv([[:space:],#]|$)' "${sudo_files[@]}" 2>/dev/null; then
      ((flags+=1))
    fi
    if grep -Eiq '^[[:space:]]*[^#].*/(ba)?sh([[:space:],]|$)|^[[:space:]]*[^#].*/(zsh|dash|ksh|python[0-9.]*|perl|ruby|node|php|lua|vim[^[:space:]]*|vi|less|more|find|awk|gawk|systemctl|service|apt(-get)?|dpkg|snap|docker|podman|lxc|lxd|incus|containerd|mount|umount|chmod|chown|chpasswd|passwd|usermod|useradd|userdel|groupadd|gpasswd|visudo|sudo|env|tee|dd|install|cp|mv|tar|rsync|sudoedit|pkexec)([[:space:],]|$)' "${sudo_files[@]}" 2>/dev/null; then
      ((flags+=1))
    fi
    if grep -Eiq '^[[:space:]]*[^#].*SETENV' "${sudo_files[@]}" 2>/dev/null ||        grep -Eiq '^[[:space:]]*[^#].*\*' "${sudo_files[@]}" 2>/dev/null; then
      ((flags+=1))
    fi
    if [[ -r /etc/sudo.conf ]] && awk '!/^[[:space:]]*#/ && $1 == "Plugin" { found=1 } END { exit(found ? 0 : 1) }' /etc/sudo.conf; then
      ((flags+=1))
    fi
    if awk '
      /^[[:space:]]*#/ { next }
      /^[[:space:]]*Defaults([[:space:]]|$)/ { next }
      {
        line=$0; sub(/^[[:space:]]*/, "", line)
        first=line; sub(/[[:space:]].*$/, "", first)
        if (first != "root" && line ~ /NOPASSWD:[[:space:]]*ALL([[:space:]]*(,|$))/)
          found=1
      }
      END { exit(found ? 0 : 1) }
    ' "${sudo_files[@]}" 2>/dev/null; then
      ((flags+=1))
    fi
    if awk '
      /^[[:space:]]*#/ { next }
      /^[[:space:]]*Defaults([[:space:]]|$)/ { next }
      /NOPASSWD:/ {
        line=$0
        sub(/^[[:space:]]*/, "", line)
        first=line; sub(/[[:space:]].*$/, "", first)
        spec=line; sub(/^.*NOPASSWD:[[:space:]]*/, "", spec)
        n=split(spec, parts, ",")
        for (i=1; i<=n; i++) {
          part=parts[i]
          gsub(/^[[:space:]]+|[[:space:]]+$/, "", part)
          if (first == "root" && part ~ /^ALL([[:space:]]|$)/) continue
          gsub(/\/usr\/bin\/mint-refresh-cache/, "", part)
          gsub(/\/usr\/lib\/linuxmint\/mintUpdate\/synaptic-workaround[.]py/, "", part)
          gsub(/\/usr\/lib\/linuxmint\/mintUpdate\/dpkg_lock_check[.]sh/, "", part)
          gsub(/[[:space:],]/, "", part)
          if (part != "") found=1
        }
      }
      END { exit(found ? 0 : 1) }
    ' "${sudo_files[@]}" 2>/dev/null; then
      ((flags+=1))
    fi
  fi

  if [[ -e /etc/sudoers ]]; then
    owner="$(stat -c '%u' /etc/sudoers 2>/dev/null || printf '?')"
    group="$(stat -c '%g' /etc/sudoers 2>/dev/null || printf '?')"
    mode="$(stat -c '%a' /etc/sudoers 2>/dev/null || printf '?')"
    [[ "$owner" == 0 && "$group" == 0 && "$mode" == 440 ]] || ((flags+=1))
  else
    ((flags+=1))
  fi
  if command -v visudo >/dev/null 2>&1; then
    visudo -c >/dev/null 2>&1 || ((flags+=1))
  else
    ((flags+=1))
  fi
  if [[ -d /etc/sudoers.d ]]; then
    local dir_owner dir_mode include_owner include_group include_mode include_file
    read -r dir_owner dir_mode < <(stat -c '%u %a' /etc/sudoers.d 2>/dev/null || printf '? ?\n')
    if [[ "$dir_owner" != 0 || ! "$dir_mode" =~ ^[0-7]{3,4}$ ]] || (( (8#$dir_mode) & 0022 )); then
      ((flags+=1))
    fi
    for include_file in "${sudo_files[@]}"; do
      [[ "$include_file" == /etc/sudoers ]] && continue
      read -r include_owner include_group include_mode < <(stat -c '%u %g %a' "$include_file" 2>/dev/null || printf '? ? ?\n')
      if [[ -L "$include_file" || "$include_owner" != 0 || "$include_group" != 0 || ! "$include_mode" =~ ^[0-7]{3,4}$ ]] || \
         (( (8#$include_mode) & 0022 )); then
        ((flags+=1))
        break
      fi
    done
  fi
  if [[ -r /etc/nsswitch.conf ]]; then
    local quick_nss_sudoers
    quick_nss_sudoers="$(awk '$1 == "sudoers:" { $1=""; sub(/^[[:space:]]+/, ""); print; exit }' /etc/nsswitch.conf)"
    [[ -n "$quick_nss_sudoers" && "$quick_nss_sudoers" != files ]] && ((flags+=1))
  fi

  # Duplicate local numeric UIDs can cause unrelated names to share file
  # ownership and access. UID 0 is also reported in the detailed account scan.
  if awk -F: '{ if ($3 ~ /^[0-9]+$/) count[$3]++ } END { for (u in count) if (count[u] > 1) found=1; exit(found ? 0 : 1) }' /etc/passwd; then
    ((flags+=1))
  fi

  # One pass covers duplicate UID 0, effective sudo and unusual memberships.
  # The main audit only prints a compact tag; option 4 prints account details.
  uid_min="$(ua_uid_min)"
  while IFS=: read -r user _ uid gid gecos home shell; do
    [[ "$uid" =~ ^[0-9]+$ ]] || continue
    if [[ "$uid" == 0 ]]; then
      [[ "$user" == root ]] || ((flags+=1))
      continue
    fi
    class="$(ua_classify_account "$user" "$uid" "$home" "$shell" "$uid_min")"
    access="$(ua_user_sudo_access_class "$user")"
    groups="$(ua_user_groups "$user")"
    account_flag=0
    [[ "$access" == UNCHECKED || "$access" == REVIEW ]] && account_flag=1
    case "$class" in
      HUMAN-CANDIDATE|LOW-UID-HUMAN-LIKE-REVIEW|UID-MIN-LOGIN-REVIEW)
        if [[ "$access" == FULL ]] && ! ua_group_list_has "$groups" sudo && ! ua_group_list_has "$groups" wheel && ! ua_group_list_has "$groups" admin; then
          account_flag=1
        fi
        for group_name in "${human_sensitive_groups[@]}"; do
          if ua_group_list_has "$groups" "$group_name"; then account_flag=1; break; fi
        done
        ;;
      *)
        if [[ "$access" == FULL ]]; then account_flag=1; fi
        for group_name in "${service_admin_groups[@]}" "${service_root_groups[@]}" libvirt kvm; do
          if ua_group_list_has "$groups" "$group_name"; then account_flag=1; break; fi
        done
        ;;
    esac
    (( account_flag )) && ((flags+=1))
  done < /etc/passwd

  if grep -RqsE 'polkit[.]Result[.]YES|return[[:space:]]+YES' /etc/polkit-1/rules.d 2>/dev/null || \
     grep -RiqE 'Result(Any|Inactive|Active)[[:space:]]*=[[:space:]]*yes' /etc/polkit-1/localauthority 2>/dev/null; then
    ((flags+=1))
  fi

  # Find the most obvious dangerous set-ID/capability anomalies quickly. The
  # detailed report inventories every set-ID file and prints exact paths.
  if ((${#scan_dirs[@]})); then
    local quick_setid_file quick_setid_owner quick_setid_mode
    while IFS= read -r -d '' quick_setid_file; do
      read -r quick_setid_owner quick_setid_mode < <(stat -c '%u %a' "$quick_setid_file" 2>/dev/null || printf '? ?\n')
      if [[ "$quick_setid_owner" != 0 || ! "$quick_setid_mode" =~ ^[0-7]{3,4}$ ]] || \
         (( (8#$quick_setid_mode) & 0022 )) || ! ua_is_common_setid_path "$quick_setid_file"; then
        ((flags+=1))
        break
      fi
    done < <(find "${scan_dirs[@]}" -type f -perm /6000 -print0 2>/dev/null)
  fi
  if command -v getcap >/dev/null 2>&1 && ((${#scan_dirs[@]})) && \
     getcap -r "${scan_dirs[@]}" 2>/dev/null | \
       grep -Eqi 'cap_(sys_admin|dac_override|sys_ptrace|setuid|setgid|sys_module|sys_rawio|dac_read_search|net_admin|audit_control|syslog|sys_time|sys_boot|bpf|perfmon|checkpoint_restore|mac_admin|mac_override|sys_resource)'; then
    ((flags+=1))
  fi
  if ! command -v sudo >/dev/null 2>&1; then
    ((flags+=1))
  fi

  if (( flags > 0 )); then
    ua_msg_warn "PRIVILEGE REVIEW NEEDED: one or more high-risk indicators were detected. Open USER AUDITING option 4 for the detailed read-only report."
  else
    ua_msg_info "Quick privilege checks found no obvious high-risk indicators. Option 4 provides the full sudoers, account, PolicyKit, SUID/SGID, and capability review."
  fi
  return 0
}

ua_detailed_privilege_security_report() {
  local uid_min user _ uid gid gecos home shell class groups user_groups group file owner group_id mode
  local visudo_output nss_sudoers found=0 sudo_rule_categories=0 limited_count=0 review_count=0 unchecked_count=0 root_uid_anomalies=0 polkit_count=0 duplicate_uid_entry duplicate_uid duplicate_names
  local -a sudo_files=() scan_dirs=() human_unrestricted=() service_unrestricted=()
  local -a duplicate_uid_entries=() service_admin_members=() service_rootish_members=() sudo_review_accounts=()
  local -a service_virtualization_members=() human_high_impact_members=() human_virtualization_members=()
  local -a service_sensitive_members=() human_sensitive_members=() human_admin_group_members=()
  local -a service_shadow_members=() human_shadow_members=()
  local -a group_write_privileged=() nonroot_privileged=() all_caps=() unowned_setid_files=()
  local -a setid_files=() unusual_setid_files=()
  local -a service_admin_groups=(sudo wheel admin)
  local -a service_rootish_groups=(disk docker lxd incus incus-admin containerd podman)
  local -a human_high_impact_groups=(disk docker lxd incus incus-admin containerd podman)
  local -a credential_visibility_groups=(shadow)
  local -a sensitive_visibility_groups=(adm systemd-journal wireshark lpadmin input)
  ua_require_root || return 1
  uid_min="$(ua_uid_min)"
  mapfile -t sudo_files < <(ua_sudoers_active_files)
  mapfile -t scan_dirs < <(ua_privilege_scan_dirs)

  echo
  echo "============================================================"
  echo "DETAILED PRIVILEGED-ACCESS SECURITY REPORT (READ-ONLY)"
  echo "============================================================"
  echo "This report detects risky configurations; it does not edit sudoers, groups, PolicyKit, or executable permissions."

  # 1. Syntax and file trust.
  echo
  echo "[1] SUDOERS SYNTAX, OWNERSHIP, AND PERMISSIONS"
  if command -v visudo >/dev/null 2>&1; then
    if visudo_output="$(visudo -c 2>&1)"; then
      ua_msg_pass "visudo -c accepted the sudoers configuration."
    else
      ua_msg_error "visudo -c reported a sudoers problem:"
      printf '%s\n' "$visudo_output" | sed 's/^/  /'
      found=1
    fi
  else
    ua_msg_warn "visudo is unavailable; sudoers syntax could not be validated."
    found=1
  fi

  if [[ -d /etc/sudoers.d ]]; then
    owner="$(stat -c '%u' /etc/sudoers.d 2>/dev/null || printf '?')"
    mode="$(stat -c '%a' /etc/sudoers.d 2>/dev/null || printf '?')"
    if [[ "$owner" != 0 || ! "$mode" =~ ^[0-7]{3,4}$ ]] || (( (8#$mode) & 0022 )); then
      ua_msg_warn "/etc/sudoers.d should be root-owned and not group/other-writable (owner UID=$owner, mode=$mode)."
      found=1
    else
      ua_msg_pass "/etc/sudoers.d is root-owned and not group/other-writable (mode $mode)."
    fi
  fi

  if ((${#sudo_files[@]} == 0)); then
    ua_msg_warn "No readable /etc/sudoers source file was found."
    found=1
  fi
  for file in "${sudo_files[@]}"; do
    [[ -f "$file" ]] || continue
    if [[ -L "$file" ]]; then
      ua_msg_warn "$file is a symlink; inspect its target and ownership manually."
      found=1
    fi
    group_id="$(stat -c '%u:%g:%a' "$file" 2>/dev/null || printf '?:?:?')"
    IFS=: read -r owner group mode <<< "$group_id"
    if [[ "$owner" != 0 || "$group" != 0 ]]; then
      ua_msg_warn "$file is not owned by root:root (UID:GID:mode=$group_id)."
      found=1
    elif [[ "$file" == /etc/sudoers && "$mode" != 440 ]]; then
      ua_msg_warn "$file has mode $mode; expected 440 (0440)."
      found=1
    elif [[ ! "$mode" =~ ^[0-7]{3,4}$ ]]; then
      ua_msg_warn "$file permissions could not be interpreted (mode=$mode)."
      found=1
    elif [[ "$file" != /etc/sudoers ]] && (( (8#$mode) & 0022 )); then
      ua_msg_warn "$file is group/other-writable (mode $mode)."
      found=1
    else
      ua_msg_pass "$file ownership/permissions look safe (root:root, mode $mode)."
    fi
  done

  if [[ -r /etc/sudoers ]]; then
    local include_directives
    include_directives="$(awk '/^[[:space:]]*(@include(dir)?|#include(dir)?)[[:space:]]+/ { printf "%d:%s\n", NR, $0 }' /etc/sudoers)"
    if [[ -n "$include_directives" ]]; then
      echo "[INFO] Sudoers include directives in /etc/sudoers:"
      printf '%s\n' "$include_directives" | sed 's/^/  /'
      echo "  The line-level scanner expands /etc/sudoers.d; inspect any additional custom include paths manually."
    fi
  fi
  if [[ -r /etc/sudo.conf ]]; then
    local sudo_plugins
    sudo_plugins="$(awk '!/^[[:space:]]*#/ && $1 == "Plugin" { printf "%d:%s\n", NR, $0 }' /etc/sudo.conf)"
    if [[ -n "$sudo_plugins" ]]; then
      echo "[REVIEW] Explicit sudo plugin configuration in /etc/sudo.conf:"
      printf '%s\n' "$sudo_plugins" | sed 's/^/  /'
      echo "  Confirm each policy/I/O/audit plugin is expected; custom policy plugins may change authorization behavior."
      found=1
    fi
  fi

  # 2. Sudoers policy anomalies. Show exact active source lines, but suppress
  # empty category chatter; one PASS covers a clean local policy scan.
  echo
  echo "[2] HIGH-RISK SUDOERS RULES AND DEFAULTS"
  if ua_print_sudoers_matches "[CRITICAL] Universal unrestricted sudo grants (all users, all commands):" \
    '^[[:space:]]*ALL[[:space:]]+ALL[[:space:]]*=[[:space:]]*([(][^)]*[)][[:space:]]*)?(NOPASSWD:[[:space:]]*)?ALL([[:space:]]*(,|$))' "${sudo_files[@]}"; then
    ((sudo_rule_categories+=1)); found=1
  fi

  if ua_print_nonroot_nopasswd_all "[HIGH] Passwordless unrestricted grants to non-root users/groups:" "${sudo_files[@]}"; then
    ((sudo_rule_categories+=1)); found=1
  fi

  if ua_print_sudoers_matches "[INFO] Active NOPASSWD source lines (review RunAs scope, command path, and arguments):" \
    '^[[:space:]]*[^#].*NOPASSWD:' "${sudo_files[@]}"; then
    ((sudo_rule_categories+=1))
    echo "  Scoped vendor helpers may be intentional; verify each command's ownership, write permissions, and arguments."
  fi

  if ua_print_sudoers_matches "[HIGH] Root-shell-capable or high-impact command grants (password-protected or passwordless):" \
    '^[[:space:]]*[^#].*/(ba)?sh([[:space:],]|$)|^[[:space:]]*[^#].*/(zsh|dash|ksh|python[0-9.]*|perl|ruby|node|php|lua|vim[^[:space:]]*|vi|less|more|find|awk|gawk|systemctl|service|apt(-get)?|dpkg|snap|docker|podman|lxc|lxd|incus|containerd|mount|umount|chmod|chown|chpasswd|passwd|usermod|useradd|userdel|groupadd|gpasswd|visudo|sudo|env|tee|dd|install|cp|mv|tar|rsync|sudoedit|pkexec)([[:space:],]|$)' "${sudo_files[@]}"; then
    ((sudo_rule_categories+=1)); found=1
    echo "  A password prompt does not remove the power granted by a command. Inspect allowed arguments, RunAs scope, and the exact executable."
  fi

  if ua_print_sudoers_matches "[REVIEW] Sudo rules using wildcard command/argument patterns:" \
    '^[[:space:]]*[^#].*[*?]' "${sudo_files[@]}"; then
    ((sudo_rule_categories+=1)); found=1
    echo "  Wildcard meaning depends on sudoers command/argument syntax; inspect each entry manually."
  fi

  if ua_print_sudoers_matches "[HIGH] Defaults that disable sudo authentication:" \
    '^[[:space:]]*Defaults([^#]*)!authenticate' "${sudo_files[@]}"; then
    ((sudo_rule_categories+=1)); found=1
  fi

  if ua_print_sudoers_matches "[HIGH] Dangerous environment preservation (loader/interpreter/path variables):" \
    '^[[:space:]]*Defaults([^#]*)env_keep[^#]*(LD_PRELOAD|LD_LIBRARY_PATH|LD_AUDIT|GCONV_PATH|PYTHONPATH|PYTHONHOME|PERL5LIB|RUBYOPT|BASH_ENV|(^|[[:space:]"+])ENV([[:space:]"+]|$)|(^|[[:space:]"+])PATH([[:space:]"+]|$))' "${sudo_files[@]}"; then
    ((sudo_rule_categories+=1)); found=1
  fi

  if ua_print_sudoers_matches "[HIGH] Disabled secure_path or env_reset:" \
    '^[[:space:]]*Defaults([^#]*)!(secure_path|env_reset)' "${sudo_files[@]}"; then
    ((sudo_rule_categories+=1)); found=1
  fi

  if ua_print_sudoers_matches "[HIGH] Sudo password-exempt group configured:" \
    '^[[:space:]]*Defaults([^#]*)exempt_group[[:space:]]*=' "${sudo_files[@]}"; then
    ((sudo_rule_categories+=1)); found=1
  fi

  if ua_print_sudoers_matches "[REVIEW] Sudo authentication timestamp never expires:" \
    '^[[:space:]]*Defaults([^#]*)timestamp_timeout[[:space:]]*=[[:space:]]*-1([[:space:],#]|$)' "${sudo_files[@]}"; then
    ((sudo_rule_categories+=1)); found=1
  fi

  if ua_print_sudoers_matches "[REVIEW] Sudo pseudo-terminal isolation explicitly disabled:" \
    '^[[:space:]]*Defaults([^#]*)!use_pty' "${sudo_files[@]}"; then
    ((sudo_rule_categories+=1)); found=1
  fi

  if ua_print_sudoers_matches "[REVIEW] Preserved HOME environment variable:" \
    '^[[:space:]]*Defaults([^#]*)env_keep[^#]*HOME' "${sudo_files[@]}"; then
    ((sudo_rule_categories+=1)); found=1
  fi

  if ua_print_sudoers_matches "[REVIEW] Sudo command/audit logging explicitly disabled:" \
    '^[[:space:]]*Defaults([^#]*)!(logfile|syslog|log_input|log_output)' "${sudo_files[@]}"; then
    ((sudo_rule_categories+=1)); found=1
  fi

  if ua_print_universal_limited_sudoers_rules "[REVIEW] Universal subject scope with command-limited grants (not full admin by themselves):" "${sudo_files[@]}"; then
    ((sudo_rule_categories+=1))
    echo "  This category excludes unrestricted ALL command specifications. Review command ownership, arguments, and package provenance."
  fi

  if ua_print_sudoers_matches "[REVIEW] SETENV-enabled sudo rules:" \
    '^[[:space:]]*[^#].*SETENV' "${sudo_files[@]}"; then
    ((sudo_rule_categories+=1)); found=1
  fi

  if ua_print_sudoers_matches "[HIGH] Sudo Defaults globally enabling environment preservation (-E):" \
    '^[[:space:]]*Defaults([^#]*)[[:space:],]setenv([[:space:],#]|$)' "${sudo_files[@]}"; then
    ((sudo_rule_categories+=1)); found=1
  fi

  if (( sudo_rule_categories == 0 )); then
    ua_msg_pass "No high-risk or unusual sudoers source patterns were detected in the active local files."
  fi

  # 3. Effective account permissions. This is the key distinction between
  # unrestricted admin and a narrow helper grant such as Mint Update commands.
  echo
  echo "[3] EFFECTIVE LOCAL ACCOUNT PRIVILEGES"
  if ! command -v sudo >/dev/null 2>&1; then
    ua_msg_warn "sudo is unavailable; per-account effective-rule evaluation was skipped."
    found=1
  else
    while IFS=: read -r user _ uid gid gecos home shell; do
      [[ "$uid" =~ ^[0-9]+$ ]] || continue
      if [[ "$uid" == 0 && "$user" != root ]]; then
        ((root_uid_anomalies+=1))
      fi
      [[ "$user" == root || "$uid" == 0 ]] && continue

      access="$(ua_user_sudo_access_class "$user")"
      [[ "$access" == UNCHECKED ]] && ((unchecked_count+=1))
      user_groups="$(ua_user_groups "$user")"
      class="$(ua_classify_account "$user" "$uid" "$home" "$shell" "$uid_min")"
      case "$class" in
        HUMAN-CANDIDATE|LOW-UID-HUMAN-LIKE-REVIEW|UID-MIN-LOGIN-REVIEW)
          groups=""
          for group in "${service_admin_groups[@]}"; do
            if ua_group_list_has "$user_groups" "$group"; then groups+=" $group"; fi
          done
          if [[ -n "$groups" ]]; then
            human_admin_group_members+=("$user (UID $uid; groups:${groups}; sudo-check=$access)")
          elif [[ "$access" == FULL ]]; then
            human_unrestricted+=("$user (UID $uid; $class; unrestricted outside sudo/wheel/admin groups)")
          fi
          [[ "$access" == LIMITED ]] && ((limited_count+=1))
          if [[ "$access" == REVIEW ]]; then
            ((review_count+=1))
            sudo_review_accounts+=("$user (UID $uid; $class; shell-capable/high-impact command grant)")
          fi
          groups=""
          for group in "${human_high_impact_groups[@]}"; do
            if ua_group_list_has "$user_groups" "$group"; then groups+=" $group"; fi
          done
          [[ -n "$groups" ]] && human_high_impact_members+=("$user (UID $uid; groups:${groups})")
          groups=""
          for group in "${credential_visibility_groups[@]}"; do
            if ua_group_list_has "$user_groups" "$group"; then groups+=" $group"; fi
          done
          [[ -n "$groups" ]] && human_shadow_members+=("$user (UID $uid; groups:${groups})")
          if ua_group_list_has "$user_groups" libvirt || ua_group_list_has "$user_groups" kvm; then
            groups=""
            ua_group_list_has "$user_groups" libvirt && groups+=" libvirt"
            ua_group_list_has "$user_groups" kvm && groups+=" kvm"
            human_virtualization_members+=("$user (UID $uid; groups:${groups})")
          fi
          groups=""
          for group in "${sensitive_visibility_groups[@]}"; do
            if ua_group_list_has "$user_groups" "$group"; then groups+=" $group"; fi
          done
          [[ -n "$groups" ]] && human_sensitive_members+=("$user (UID $uid; groups:${groups})")
          ;;
        *)
          [[ "$access" == FULL ]] && service_unrestricted+=("$user (UID $uid; $class)")
          [[ "$access" == LIMITED ]] && ((limited_count+=1))
          if [[ "$access" == REVIEW ]]; then
            ((review_count+=1))
            sudo_review_accounts+=("$user (UID $uid; $class; shell-capable/high-impact command grant)")
          fi
          groups=""
          for group in "${service_admin_groups[@]}"; do
            if ua_group_list_has "$user_groups" "$group"; then groups+=" $group"; fi
          done
          [[ -n "$groups" ]] && service_admin_members+=("$user (UID $uid; groups:${groups})")
          groups=""
          for group in "${service_rootish_groups[@]}"; do
            if ua_group_list_has "$user_groups" "$group"; then groups+=" $group"; fi
          done
          [[ -n "$groups" ]] && service_rootish_members+=("$user (UID $uid; groups:${groups})")
          groups=""
          for group in "${credential_visibility_groups[@]}"; do
            if ua_group_list_has "$user_groups" "$group"; then groups+=" $group"; fi
          done
          [[ -n "$groups" ]] && service_shadow_members+=("$user (UID $uid; groups:${groups})")
          if ua_group_list_has "$user_groups" libvirt || ua_group_list_has "$user_groups" kvm; then
            groups=""
            ua_group_list_has "$user_groups" libvirt && groups+=" libvirt"
            ua_group_list_has "$user_groups" kvm && groups+=" kvm"
            service_virtualization_members+=("$user (UID $uid; groups:${groups})")
          fi
          groups=""
          for group in "${sensitive_visibility_groups[@]}"; do
            if ua_group_list_has "$user_groups" "$group"; then groups+=" $group"; fi
          done
          [[ -n "$groups" ]] && service_sensitive_members+=("$user (UID $uid; groups:${groups})")
          ;;
      esac
    done < /etc/passwd

    mapfile -t duplicate_uid_entries < <(
      awk -F: '
        $3 ~ /^[0-9]+$/ {
          if (count[$3]++) names[$3] = names[$3] ", " $1
          else names[$3] = $1
        }
        END { for (uid in count) if (count[uid] > 1) print uid "\t" names[uid] }
      ' /etc/passwd | sort -n -k1,1
    )
    if ((${#duplicate_uid_entries[@]})); then
      ua_msg_error "DUPLICATE NUMERIC UIDs IN LOCAL /etc/passwd (accounts share the same kernel/filesystem identity):"
      for duplicate_uid_entry in "${duplicate_uid_entries[@]}"; do
        IFS=$'\t' read -r duplicate_uid duplicate_names <<< "$duplicate_uid_entry"
        printf '  UID %s: %s\n' "$duplicate_uid" "$duplicate_names"
      done
      found=1
    fi

    if ((${#human_unrestricted[@]})); then
      ua_msg_warn "HUMAN/REVIEW ACCOUNTS WITH UNRESTRICTED SUDO:"
      printf '  %s\n' "${human_unrestricted[@]}"
      found=1
    fi
    if ((${#service_unrestricted[@]})); then
      ua_msg_error "SYSTEM/SERVICE ACCOUNTS WITH UNRESTRICTED SUDO:"
      printf '  %s\n' "${service_unrestricted[@]}"
      found=1
    fi
    if (( unchecked_count > 0 )); then
      ua_msg_warn "Could not classify sudo access for $unchecked_count local account(s); inspect sudo -l -U <username> manually. These were not counted as no-access."
      found=1
    fi
    if (( review_count > 0 )); then
      ua_msg_warn "$review_count local account(s) have sudo command grants that may provide a root shell or powerful administrative control:"
      printf '  %s\n' "${sudo_review_accounts[@]}"
      echo "  These are review classifications, not automatic proof that every allowed argument is exploitable. Inspect each account with sudo -l -U USERNAME."
      found=1
    fi
    if (( limited_count > 0 )); then
      ua_msg_info "$limited_count local account(s) have command-limited sudo permissions; these are not full administrator access. The source rules are shown above when their scope is universal."
    fi
    if ((${#human_admin_group_members[@]})); then
      ua_msg_info "HUMAN/REVIEW ACCOUNTS IN SUDO/WHEEL/ADMIN GROUPS (verify authorization and sudo result):"
      printf '  %s\n' "${human_admin_group_members[@]}"
    fi
    if ((${#service_admin_members[@]})); then
      ua_msg_error "SYSTEM/SERVICE ACCOUNTS IN SUDO/WHEEL/ADMIN GROUPS:"
      printf '  %s\n' "${service_admin_members[@]}"
      found=1
    fi
    if ((${#service_rootish_members[@]})); then
      ua_msg_warn "SYSTEM/SERVICE ACCOUNTS IN ROOT-EQUIVALENT GROUPS (disk/docker/lxd/incus/incus-admin/containerd/podman):"
      printf '  %s\n' "${service_rootish_members[@]}"
      found=1
    fi
    if ((${#service_virtualization_members[@]})); then
      ua_msg_warn "SYSTEM/SERVICE ACCOUNTS WITH VIRTUALIZATION CONTROL (libvirt/kvm):"
      printf '  %s\n' "${service_virtualization_members[@]}"
      found=1
    fi
    if ((${#human_high_impact_members[@]})); then
      ua_msg_warn "HUMAN ACCOUNTS IN ROOT-EQUIVALENT GROUPS (disk/docker/lxd/incus/incus-admin/containerd/podman):"
      printf '  %s\n' "${human_high_impact_members[@]}"
      found=1
    fi
    if ((${#human_virtualization_members[@]})); then
      ua_msg_info "HUMAN ACCOUNTS WITH VIRTUALIZATION CONTROL (libvirt/kvm):"
      printf '  %s\n' "${human_virtualization_members[@]}"
    fi
    if ((${#service_sensitive_members[@]})); then
      ua_msg_warn "SYSTEM/SERVICE ACCOUNTS WITH SENSITIVE LOG, CAPTURE, PRINTER, OR INPUT-DEVICE ACCESS (adm/systemd-journal/wireshark/lpadmin/input):"
      printf '  %s\n' "${service_sensitive_members[@]}"
      found=1
    fi
    if ((${#human_sensitive_members[@]})); then
      ua_msg_info "HUMAN ACCOUNTS WITH SENSITIVE LOG/CAPTURE/PRINTER/INPUT-DEVICE GROUPS:"
      printf '  %s\n' "${human_sensitive_members[@]}"
    fi
    if ((${#service_shadow_members[@]})); then
      ua_msg_error "SYSTEM/SERVICE ACCOUNTS WITH SHADOW-GROUP PASSWORD-HASH ACCESS:"
      printf '  %s\n' "${service_shadow_members[@]}"
      found=1
    fi
    if ((${#human_shadow_members[@]})); then
      ua_msg_warn "HUMAN ACCOUNTS WITH SHADOW-GROUP PASSWORD-HASH ACCESS:"
      printf '  %s\n' "${human_shadow_members[@]}"
      found=1
    fi
    if ((${#human_unrestricted[@]} == 0 && ${#service_unrestricted[@]} == 0 &&
         ${#service_admin_members[@]} == 0 && ${#service_rootish_members[@]} == 0 &&
         ${#service_virtualization_members[@]} == 0 && ${#human_high_impact_members[@]} == 0 &&
         ${#service_sensitive_members[@]} == 0 && ${#human_sensitive_members[@]} == 0 &&
         ${#service_shadow_members[@]} == 0 && ${#human_shadow_members[@]} == 0 &&
         ${#duplicate_uid_entries[@]} == 0 && root_uid_anomalies == 0 && unchecked_count == 0 && review_count == 0)); then
      ua_msg_pass "No unexpected high-impact account privileges or group memberships were identified."
    fi
  fi

  # 4. Inspect every discrete NOPASSWD command target, including package,
  # ownership, file mode, symlink target, and parent-directory trust.
  ua_report_nopasswd_command_integrity "${sudo_files[@]}" || found=1

  # 5. Additional root-equivalent or sensitive local authorization sources.
  echo
  echo "[5] POLICYKIT AND OTHER LOCAL PRIVILEGE PATHS"
  if [[ -d /etc/polkit-1/rules.d ]]; then
    for file in /etc/polkit-1/rules.d/*.rules; do
      [[ -f "$file" ]] || continue
      local matches
      matches="$(grep -nE 'polkit[.]Result[.]YES|return[[:space:]]+YES' "$file" 2>/dev/null || true)"
      if [[ -n "$matches" ]]; then
        printf '[REVIEW] Local PolicyKit allow rule(s) in %s:\n' "$file"
        printf '%s\n' "$matches" | sed 's/^/  /'
        echo "  Review the surrounding subject/action conditions; YES may be safe only when tightly scoped."
        ((polkit_count+=1))
      fi
    done
  fi
  if [[ -d /etc/polkit-1/localauthority ]]; then
    local pkla_matches
    pkla_matches="$(find /etc/polkit-1/localauthority -type f -name '*.pkla' -exec grep -nHE 'Result(Any|Inactive|Active)[[:space:]]*=[[:space:]]*yes' {} + 2>/dev/null || true)"
    if [[ -n "$pkla_matches" ]]; then
      echo "[REVIEW] Legacy PolicyKit rules granting YES results:"
      printf '%s\n' "$pkla_matches" | sed 's/^/  /'
      ((polkit_count+=1))
    fi
  fi
  if (( polkit_count == 0 )); then
    ua_msg_info "Static scan found no obvious unconditional PolicyKit YES-grant patterns in /etc/polkit-1; JavaScript conditions and dynamic rules are not evaluated."
  else
    ua_msg_warn "PolicyKit allow rules need human review; this scanner does not interpret JavaScript conditions."
    found=1
  fi

  # 6. SUID/SGID and file capabilities. The known-path set is intentionally
  # small and conservative; unfamiliar entries are REVIEW items, not automatic
  # deletion candidates. Distribution/package changes can legitimately add them.
  echo
  echo "[6] SUID/SGID EXECUTABLES AND FILE CAPABILITIES"
  echo "  Scan scope: system executable directories, /snap, and app bin/sbin directories under /opt. User home/cache data and arbitrary /var trees are not traversed."
  if ((${#scan_dirs[@]})); then
    mapfile -t setid_files < <(find "${scan_dirs[@]}" -type f -perm /6000 -print 2>/dev/null | sort -u)
  fi
  for file in "${setid_files[@]}"; do
    local file_owner file_mode package_owner
    if [[ ! -e "$file" ]]; then
      ua_msg_warn "STALE SUID/SGID path disappeared during scanning: $file"
      found=1
      continue
    fi
    read -r file_owner file_mode < <(stat -Lc '%u %a' "$file" 2>/dev/null || printf '? ?\n')
    package_owner="$(ua_package_owner_for_path "$file")"
    if [[ "$file_owner" != 0 ]]; then
      nonroot_privileged+=("$file (owner UID=$file_owner; mode=$file_mode; package=$package_owner)")
    fi
    if [[ "$file_mode" =~ ^[0-7]{3,4}$ ]] && (( (8#$file_mode) & 0022 )); then
      group_write_privileged+=("$file (mode=$file_mode; package=$package_owner)")
    fi
    if [[ "$package_owner" == UNOWNED ]]; then
      unowned_setid_files+=("$file (mode=$file_mode)")
    fi
    if ! ua_is_common_setid_path "$file"; then
      if [[ "$package_owner" == UNOWNED ]]; then
        unusual_setid_files+=("$file (mode=$file_mode; package=UNOWNED)")
      else
        unusual_setid_files+=("$file (mode=$file_mode; package=$package_owner; PACKAGE-OWNED-REVIEW)")
      fi
    fi
  done

  if ((${#unusual_setid_files[@]})); then
    ua_msg_warn "SUID/SGID paths outside the compact Mint/Ubuntu core allowlist (verify package and purpose):"
    printf '  %s\n' "${unusual_setid_files[@]}"
    echo "  A package-owned file can still be unsafe; an unowned file deserves especially close review."
    found=1
  else
    ua_msg_pass "No unfamiliar SUID/SGID paths were found in the scanned executable directories (against the script's compact core allowlist)."
  fi
  if ((${#group_write_privileged[@]})); then
    ua_msg_error "SUID/SGID files writable by group or others:"
    printf '  %s\n' "${group_write_privileged[@]}"
    found=1
  fi
  if ((${#nonroot_privileged[@]})); then
    ua_msg_error "SUID/SGID files not owned by root:"
    printf '  %s\n' "${nonroot_privileged[@]}"
    found=1
  fi
  if ((${#unowned_setid_files[@]})); then
    ua_msg_warn "SUID/SGID files with no installed-package owner (after merged-/usr alias checks):"
    printf '  %s\n' "${unowned_setid_files[@]}"
    found=1
  fi

  if command -v getcap >/dev/null 2>&1 && ((${#scan_dirs[@]})); then
    mapfile -t all_caps < <(getcap -r "${scan_dirs[@]}" 2>/dev/null | sort -u)
    if ((${#all_caps[@]})); then
      local cap_line cap_path cap_value cap_resolved cap_package cap_trust cap_owner cap_mode
      for cap_line in "${all_caps[@]}"; do
        cap_path="${cap_line%% *}"
        cap_value="${cap_line#* }"
        if [[ ! -e "$cap_path" ]]; then
          ua_msg_warn "STALE capability result: path disappeared during scanning: $cap_path"
          found=1
          continue
        fi
        cap_resolved="$(readlink -f -- "$cap_path" 2>/dev/null || true)"
        [[ -n "$cap_resolved" ]] || cap_resolved="$cap_path"
        cap_package="$(ua_package_owner_for_path "$cap_path")"
        cap_trust="$(ua_privileged_path_trust_issues "$cap_path" "$cap_resolved")"
        read -r cap_owner _ cap_mode < <(stat -Lc '%u %g %a' "$cap_resolved" 2>/dev/null || printf '? ? ?\n')

        if [[ -n "$cap_trust" ]]; then
          ua_msg_error "UNSAFE CAPABILITY TARGET: $cap_path ($cap_value; package=$cap_package): $cap_trust"
          found=1
        elif [[ "$cap_package" == UNOWNED ]]; then
          ua_msg_error "UNOWNED CAPABILITY EXECUTABLE: $cap_path ($cap_value; resolved=$cap_resolved)"
          found=1
        elif ua_is_known_package_capability "$cap_resolved" "$cap_value" "$cap_package"; then
          ua_msg_info "PACKAGE-INTENDED capability: $cap_path ($cap_value; package=$cap_package; owner UID=$cap_owner; mode=$cap_mode). Retain unless package/function requirements change."
        else
          ua_msg_warn "PACKAGE-REVIEW capability: $cap_path ($cap_value; package=$cap_package; owner UID=$cap_owner; mode=$cap_mode). Package-owned does not automatically mean appropriate."
          found=1
        fi
      done
    else
      ua_msg_pass "No file capabilities were found in the scanned executable directories."
    fi
  else
    ua_msg_info "getcap is unavailable; file-capability inventory was skipped."
  fi

  # 7. External policy source awareness and closing summary.
  echo
  echo "[7] EXTERNAL POLICY SOURCES AND SUMMARY"
  if [[ -r /etc/nsswitch.conf ]]; then
    nss_sudoers="$(awk '$1 == "sudoers:" { $1=""; sub(/^[[:space:]]+/, ""); print; exit }' /etc/nsswitch.conf)"
    if [[ -n "$nss_sudoers" && "$nss_sudoers" != files ]]; then
      ua_msg_warn "NSS sudoers sources are configured as: $nss_sudoers. This report's per-account loop checks local /etc/passwd users; verify external policy providers separately."
      found=1
    elif [[ -n "$nss_sudoers" ]]; then
      ua_msg_info "NSS sudoers source: $nss_sudoers"
    else
      ua_msg_info "No explicit sudoers: NSS source is configured; sudo's local file defaults are assumed."
    fi
  fi
  echo "Report is read-only. No group memberships, sudoers rules, PolicyKit rules, or SUID/SGID permissions were changed."
  if (( found > 0 )); then
    ua_msg_warn "Privilege review found one or more items requiring operator attention."
  else
    ua_msg_pass "No high-risk privilege anomalies were identified by these checks. This is not a complete proof of system security."
  fi
  echo "============================================================"
  return 0
}

# -----------------------------------------------------------------------------
# Compact human administrator inventory. System/service accounts are handled
# by the detailed privilege report to avoid prompting for every service user.
# -----------------------------------------------------------------------------
ua_overview_administrators() {
  local user _ uid gid gecos home shell groups access class uid_min found=0
  uid_min="$(ua_uid_min)"
  echo
  echo "================ HUMAN ADMIN OVERVIEW ==============="
  echo "Compact list: root and human/review accounts in sudo, wheel, or admin groups."
  echo "Direct/custom sudoers grants and service-account privileges are listed in the detailed report."
  while IFS=: read -r user _ uid gid gecos home shell; do
    [[ "$uid" =~ ^[0-9]+$ ]] || continue
    if [[ "$user" == root ]]; then
      printf 'ROOT   %-24s UID=%-6s\n' "$user" "$uid"
      found=1
      continue
    elif [[ "$uid" == 0 ]]; then
      printf 'UID0-ALERT %-21s UID=%-6s (non-root account)\n' "$user" "$uid"
      found=1
      continue
    fi
    class="$(ua_classify_account "$user" "$uid" "$home" "$shell" "$uid_min")"
    case "$class" in
      HUMAN-CANDIDATE|LOW-UID-HUMAN-LIKE-REVIEW|UID-MIN-LOGIN-REVIEW) ;;
      *) continue ;;
    esac
    groups="$(ua_user_groups "$user")"
    access=""
    if ua_user_in_group "$user" sudo || ua_user_in_group "$user" wheel || ua_user_in_group "$user" admin; then
      access="ADMIN GROUP"
    fi
    [[ -n "$access" ]] || continue
    printf 'ADMIN  %-24s UID=%-6s ACCESS=%-22s GROUPS=%s\n' "$user" "$uid" "$access" "${groups:-unknown}"
    found=1
  done < <(getent passwd)
  (( found == 1 )) || echo "No root or human administrator candidates were identified."
  echo "====================================================="
}

# -----------------------------------------------------------------------------
# Review explicit administrator-group membership. Changes use a simple yes/no prompt.
# -----------------------------------------------------------------------------
ua_audit_interactive_remove_unauthorized_admins() {
  local user _ uid gid gecos home shell groups answer group changed class uid_min reviewed=0
  ua_require_root || return 1
  uid_min="$(ua_uid_min)"
  echo
  echo "=============== HUMAN ADMIN AUTHORIZATION ==========="
  echo "Only human/review candidates are prompted here; system accounts are handled in the detailed report."
  while IFS=: read -r user _ uid gid gecos home shell; do
    [[ "$user" == root || "$uid" == 0 ]] && continue
    class="$(ua_classify_account "$user" "$uid" "$home" "$shell" "$uid_min")"
    case "$class" in
      HUMAN-CANDIDATE|LOW-UID-HUMAN-LIKE-REVIEW|UID-MIN-LOGIN-REVIEW) ;;
      *) continue ;;
    esac
    if ! ua_user_in_group "$user" sudo && ! ua_user_in_group "$user" wheel && ! ua_user_in_group "$user" admin; then continue; fi
    if ! ua_is_local_user "$user"; then
      ua_msg_warn "'$user' has administrator privileges through NSS but is not local; inventory only."
      continue
    fi

    groups=""
    for group in sudo wheel admin; do
      if ua_user_in_group "$user" "$group"; then groups+=" $group"; fi
    done
    ((reviewed+=1))
    printf '\nAdministrator candidate: %s (UID=%s, privileges:%s)\n' "$user" "$uid" "${groups:- none detected}"
    # Do not read from the getent process-substitution stream.
    read -r -p "Remove '$user' from the listed administrator groups (${groups# })? [y/N] " answer </dev/tty || answer=""
    if [[ ! "$answer" =~ ^[Yy]$ ]]; then
      ua_msg_info "Preserved '$user'; no administrator permissions were changed."
      continue
    fi

    changed=0
    for group in sudo wheel admin; do
      if ua_user_in_group "$user" "$group"; then
        if ! ua_is_local_group "$group"; then
          ua_msg_warn "Group '$group' is not a local /etc/group entry; no local membership change attempted."
          continue
        fi
        if gpasswd -d "$user" "$group"; then
          changed=1
        else
          ua_msg_error "Could not remove '$user' from '$group'."
        fi
      fi
    done

    if ! ua_user_is_admin "$user"; then
      ua_msg_pass "Verified: '$user' no longer belongs to sudo, wheel, or admin groups and has no unrestricted sudo access."
    elif (( changed )); then
      ua_msg_warn "Group removal succeeded, but another administrator path remains for '$user'. Review the detailed privilege report."
      return 1
    else
      ua_msg_error "No administrator membership was changed for '$user'."
      return 1
    fi
  done < <(getent passwd)
  (( reviewed == 0 )) && ua_msg_info "No human administrator candidates require authorization review."
  echo "====================================================="
  return 0
}

# -----------------------------------------------------------------------------
# Password status review.  passwd -S reports P (password set), L (locked), or
# NP (no password).  The script never reads/displays password hashes and
# cannot infer password strength from a hash.  Empty/NP human accounts can be
# sent to passwd interactively; the new password is never stored in a variable.
# -----------------------------------------------------------------------------
ua_audit_password_status() {
  local uid_min user _ uid gid gecos home shell class status state shadow_state answer
  ua_require_root || return 1
  uid_min="$(ua_uid_min)"

  echo
  echo "================ PASSWORD STATUS REVIEW ============="
  ua_msg_info "This detects empty/no-password and locked states; it cannot prove a set password is strong."

  while IFS=: read -r user _ uid gid gecos home shell; do
    [[ "$uid" =~ ^[0-9]+$ ]] || continue
    class="$(ua_classify_account "$user" "$uid" "$home" "$shell" "$uid_min")"
    case "$class" in
      ROOT/UID0|HUMAN-CANDIDATE|LOW-UID-HUMAN-LIKE-REVIEW|UID-MIN-LOGIN-REVIEW) ;;
      *) continue ;;
    esac
    ua_is_local_user "$user" || continue

    if [[ "$class" == LOW-UID-HUMAN-LIKE-REVIEW || "$class" == UID-MIN-LOGIN-REVIEW ]]; then
      ua_msg_warn "'$user' is a review-only account, not automatically treated as a human account."
      read -r -p "Review password status for '$user' as a human account? [y/N] " answer </dev/tty || answer=""
      answer="${answer:-N}"
      [[ "$answer" =~ ^[Yy]$ ]] || {
        ua_msg_info "Skipped password-status review for '$user'."
        continue
      }
    fi

    status="$(LC_ALL=C passwd -S "$user" 2>/dev/null || true)"
    state="$(awk '{print $2}' <<< "$status")"
    shadow_state="$(awk -F: -v name="$user" '$1 == name { if ($2 == "") print "EMPTY"; else print "SET"; exit }' /etc/shadow 2>/dev/null || true)"

    case "$state:$shadow_state" in
      NP:*|*:EMPTY)
        ua_msg_warn "NO PASSWORD HASH / NO PASSWORD: $user (UID=$uid)"
        read -r -p "Set a password for '$user' now using the secure passwd prompt? [y/N] " answer </dev/tty || answer=""
        answer="${answer:-N}"
        if [[ "$answer" =~ ^[Yy]$ ]]; then
          if passwd "$user"; then
            status="$(LC_ALL=C passwd -S "$user" 2>/dev/null || true)"
            state="$(awk '{print $2}' <<< "$status")"
            shadow_state="$(awk -F: -v name="$user" '$1 == name { if ($2 == "") print "EMPTY"; else print "SET"; exit }' /etc/shadow 2>/dev/null || true)"
            if [[ "$state" == P && "$shadow_state" == SET ]]; then
              ua_msg_pass "Password is now set for '$user'."
            else
              ua_msg_warn "Password command completed, but '$user' still does not show a normal set-password state. Recheck manually."
            fi
          else
            ua_msg_error "Password update failed for '$user'."
            return 1
          fi
        else
          ua_msg_info "No password change made for '$user'."
        fi
        ;;
      L:*)
        ua_msg_info "LOCKED: $user — a locked password is not treated as an empty password. Review whether the lock is intentional."
        ;;
      P:SET)
        ua_msg_pass "Password hash is present for '$user'; actual password strength cannot be determined from this status."
        ;;
      *)
        ua_msg_warn "Could not determine password status for '$user' (passwd -S state='${state:-unknown}')."
        ;;
    esac
  done < <(getent passwd)
  echo "====================================================="
  return 0
}

# -----------------------------------------------------------------------------
# Manually change a selected eligible local user's password.  Uses passwd's
# hidden prompt; no TEMP_PASSWORD or shared password is created or logged.
# -----------------------------------------------------------------------------
ua_change_selected_user_password() {
  local user record uid gid gecos home shell uid_min class confirm status state
  ua_require_root || return 1
  read -r -p "Local account username to change: " user </dev/tty || return 1
  ua_valid_username "$user" || { ua_msg_error "Invalid account name."; return 1; }
  ua_is_local_user "$user" || { ua_msg_error "'$user' is not a local /etc/passwd account; passwd cannot change a remote identity."; return 1; }

  record="$(awk -F: -v name="$user" '$1 == name {print; exit}' /etc/passwd 2>/dev/null)"
  IFS=: read -r _ _ uid gid gecos home shell <<< "$record"
  uid_min="$(ua_uid_min)"
  class="$(ua_classify_account "$user" "$uid" "$home" "$shell" "$uid_min")"
  if [[ "$user" == root || "$uid" == 0 ]]; then
    ua_msg_warn "'$user' is root-equivalent (UID $uid). Changing this password affects privileged access."
  elif [[ "$class" != HUMAN-CANDIDATE ]]; then
    ua_msg_warn "'$user' is classified as '$class' (UID=$uid, HOME=$home, SHELL=$shell). This action will still proceed when confirmed."
  fi

  printf "Change the password for local account '%s'? [y/N] " "$user"
  read -r confirm </dev/tty || confirm=""
  [[ "$confirm" =~ ^[Yy]$ ]] || { ua_msg_info "Password change cancelled."; return 0; }

  echo "Changing password for '$user'. passwd will prompt twice; the new password is not stored by this script."
  if passwd "$user"; then
    status="$(LC_ALL=C passwd -S "$user" 2>/dev/null || true)"
    state="$(awk '{print $2}' <<< "$status")"
    if [[ "$state" == P ]]; then
      ua_msg_pass "'$user' now reports a set password (passwd -S: P)."
      return 0
    fi
    ua_msg_warn "passwd returned success but the resulting status is '${state:-unknown}'."
    return 1
  fi
  ua_msg_error "Password change failed for '$user'."
  return 1
}

# Set the shared password for one account while preserving a pre-existing
# password-lock state. A password reset should not silently enable a disabled
# service/system account unless the operator changes that policy separately.
ua_apply_shared_temp_password() {
  local user="$1" password="$2" before_status before_state after_status after_state
  before_status="$(LC_ALL=C passwd -S "$user" 2>/dev/null || true)"
  before_state="$(awk '{print $2}' <<< "$before_status")"

  if ! printf '%s:%s\n' "$user" "$password" | chpasswd; then
    ua_msg_error "chpasswd failed for '$user'."
    return 1
  fi

  if [[ "$before_state" == L ]]; then
    # chpasswd/PAM implementations differ in how they handle a locked hash.
    # Re-apply the lock if the password reset removed it.
    after_status="$(LC_ALL=C passwd -S "$user" 2>/dev/null || true)"
    after_state="$(awk '{print $2}' <<< "$after_status")"
    if [[ "$after_state" != L ]]; then
      if command -v usermod >/dev/null 2>&1; then
        usermod -L "$user" || { ua_msg_error "Password changed for '$user', but its previous lock could not be restored."; return 1; }
      elif command -v passwd >/dev/null 2>&1; then
        passwd -l "$user" >/dev/null 2>&1 || { ua_msg_error "Password changed for '$user', but its previous lock could not be restored."; return 1; }
      else
        ua_msg_error "Password changed for '$user', but no available utility could restore its previous lock."
        return 1
      fi
    fi
  fi

  after_status="$(LC_ALL=C passwd -S "$user" 2>/dev/null || true)"
  after_state="$(awk '{print $2}' <<< "$after_status")"
  case "$after_state" in
    P)
      ua_msg_pass "Updated '$user'; passwd -S confirms a password is set."
      ;;
    L)
      if [[ "$before_state" == L ]]; then
        ua_msg_pass "Updated '$user'; its pre-existing password lock was preserved."
      else
        ua_msg_warn "The password status for '$user' is locked after the reset. Verify whether that lock is expected."
        return 1
      fi
      ;;
    *)
      ua_msg_warn "chpasswd accepted '$user', but passwd -S reports '${after_state:-unknown}'. Verify manually."
      return 1
      ;;
  esac
}

# Apply the competition's shared temporary password to every local account
# except the literal root account. Root is always a separate opt-in action.
# Accounts such as service users and UID-0 aliases are intentionally included.
ua_set_shared_temp_passwords() {
  local temp_password='1CyberPatriot!'
  local user _ uid gid gecos home shell root_answer confirm uid_min class record bulk_prompt
  local success=0 failed=0 total=0
  local -a targets=()

  ua_require_root || return 1
  command -v chpasswd >/dev/null 2>&1 || { ua_msg_error "chpasswd is unavailable."; return 1; }

  echo
  echo "=============== SHARED COMPETITION PASSWORD ==============="
  ua_msg_warn "This assigns the SAME temporary password to every local account except the literal root account."
  ua_msg_warn "That includes system/service accounts, nobody, and non-root accounts with UID 0."
  ua_msg_warn "Existing locked accounts will remain locked; accounts that currently have no password may become password-authenticatable if their shell/PAM policy permits it."
  ua_msg_warn "The password is embedded in this script and printed below. This is for the isolated competition image, not a production environment."
  printf 'Temporary password: %s\n' "$temp_password"

  while IFS=: read -r user _ uid gid gecos home shell; do
    [[ -n "$user" && "$user" != root ]] || continue
    targets+=("$user")
  done < /etc/passwd

  total="${#targets[@]}"
  if (( total == 0 )); then
    ua_msg_warn "No non-root local accounts were found."
    return 0
  fi

  echo
  printf 'Accounts to be changed (%d):\n' "$total"
  uid_min="$(ua_uid_min)"
  for user in "${targets[@]}"; do
    record="$(awk -F: -v name="$user" '$1 == name {print; exit}' /etc/passwd)"
    IFS=: read -r _ _ uid gid gecos home shell <<< "$record"
    class="$(ua_classify_account "$user" "$uid" "$home" "$shell" "$uid_min")"
    printf '  %-24s UID=%-6s CLASS=%-28s SHELL=%s\n' "$user" "$uid" "$class" "$shell"
  done
  printf -v bulk_prompt "Set the shared temporary password for all %d listed accounts? [y/N] " "$total"
  read -r -p "$bulk_prompt" confirm </dev/tty || confirm=""
  [[ "$confirm" =~ ^[Yy]$ ]] || { ua_msg_info "Bulk password change cancelled."; return 1; }

  for user in "${targets[@]}"; do
    # The clear-text value is sent over stdin, never as a command-line argument
    # or a temporary plaintext file. The helper preserves pre-existing locks.
    if ua_apply_shared_temp_password "$user" "$temp_password"; then
      ((success+=1))
    else
      ua_msg_error "Could not fully update/verify '$user'; continuing with the remaining accounts."
      ((failed+=1))
    fi
  done

  echo
  printf 'Non-root results: %d updated/verified, %d failed or uncertain, %d targeted.\n' "$success" "$failed" "$total"

  read -r -p "Also change the literal root account to the same temporary password? [y/N] " root_answer </dev/tty || root_answer=""
  if [[ "$root_answer" =~ ^[Yy]$ ]]; then
    ua_msg_warn "You are about to replace root's password with the same shared temporary password."
    if ua_apply_shared_temp_password root "$temp_password"; then
      ((success+=1))
    else
      ua_msg_error "Could not fully update/verify root's password."
      ((failed+=1))
    fi
  else
    ua_msg_info "Root password left unchanged."
  fi

  printf 'Final result: %d successful/verified; %d failed or uncertain.\n' "$success" "$failed"
  (( failed == 0 ))
}

# Backward-compatible name retained for callers in older versions.
ua_force_temp_passwords() {
  ua_set_shared_temp_passwords
}

# -----------------------------------------------------------------------------
# Review non-root UID 0 accounts and hand any requested deletion to the full
# override workflow, which presents normal/force and home-preservation choices.
# -----------------------------------------------------------------------------
ua_review_non_root_uid0() {
  local user _ uid gid gecos home shell answer found=0
  ua_require_root || return 1
  echo
  echo "================ NON-ROOT UID 0 REVIEW =============="
  while IFS=: read -r user _ uid gid gecos home shell; do
    [[ "$uid" == 0 && "$user" != root ]] || continue
    found=1
    if ! ua_is_local_user "$user"; then
      ua_msg_warn "NSS reports non-local UID 0 account '$user'; this script cannot modify its identity source."
      continue
    fi
    printf '\n[ALERT] Account %s has UID 0 (HOME=%s, SHELL=%s).\n' "$user" "$home" "$shell"
    ua_msg_warn "Any UID 0 account has root-equivalent privileges. Verify whether it is legitimate."
    if [[ -n "${SUDO_USER:-}" && "$user" == "$SUDO_USER" ]]; then
      ua_msg_warn "'$user' launched this script; deleting it may disrupt the active session, but the full-override workflow remains available."
    fi
    read -r -p "Open full deletion options for UID-0 account '$user'? [y/N] " answer </dev/tty || answer=""
    if [[ "$answer" =~ ^[Yy]$ ]]; then
      ua_delete_local_user "$user" || ua_msg_warn "Deletion of '$user' did not complete."
    else
      ua_msg_info "Kept '$user'; no account changes were made."
    fi
  done < <(getent passwd)
  if (( ! found )); then
    ua_msg_pass "No non-root UID 0 accounts were found."
  fi
  echo "====================================================="
  return 0
}

# -----------------------------------------------------------------------------
# Apply aging only to local human candidates (not service accounts).  Default
# is NO.  Root is offered separately because changing root's aging can affect
# emergency recovery.  Result is verified from /etc/shadow fields 4, 5, and 6.
# -----------------------------------------------------------------------------
ua_verify_shadow_aging() {
  local user="$1"
  awk -F: -v name="$user" '
    $1 == name {
      if ($4 == 10 && $5 == 60 && $6 == 7) found=1
    }
    END { exit(found ? 0 : 1) }
  ' /etc/shadow 2>/dev/null
}

ua_set_password_aging_policy() {
  local uid_min user _ uid gid gecos home shell class answer root_answer confirm failures=0 count=0
  local -a targets=() review_targets=()
  ua_require_root || return 1
  uid_min="$(ua_uid_min)"

  echo
  echo "================ PASSWORD AGING POLICY =============="
  echo "Proposed policy for eligible local human accounts: minimum 10 days, maximum 60 days, warning 7 days."
  while IFS=: read -r user _ uid gid gecos home shell; do
    [[ "$uid" =~ ^[0-9]+$ ]] || continue
    class="$(ua_classify_account "$user" "$uid" "$home" "$shell" "$uid_min")"
    ua_is_local_user "$user" || continue
    if [[ "$class" == HUMAN-CANDIDATE ]]; then
      targets+=("$user")
    elif [[ "$class" == LOW-UID-HUMAN-LIKE-REVIEW || "$class" == UID-MIN-LOGIN-REVIEW ]]; then
      review_targets+=("$user")
    fi
  done < <(getent passwd)

  if (( ${#targets[@]} == 0 && ${#review_targets[@]} == 0 )); then
    ua_msg_warn "No eligible local human accounts were found for password aging."
    return 0
  fi

  printf 'Standard human-account targets: %s\n' "${targets[*]:-none}"
  if (( ${#review_targets[@]} > 0 )); then
    printf 'Nonstandard/low-UID review candidates (not included by default): %s\n' "${review_targets[*]}"
    for user in "${review_targets[@]}"; do
      read -r -p "Include review candidate '$user' in the password-aging changes? [y/N] " confirm </dev/tty || confirm=""
      if [[ "$confirm" =~ ^[Yy]$ ]]; then
        targets+=("$user")
        ua_msg_info "Included '$user' in the aging targets."
      else
        ua_msg_info "Excluded '$user' from aging changes."
      fi
    done
  fi
  if (( ${#targets[@]} == 0 )); then
    ua_msg_info "No human-account targets were selected; no aging changes were made."
    return 0
  fi
  printf 'Final targets: %s\n' "${targets[*]}"
  read -r -p "Apply this policy to all listed human-account targets? [y/N] " answer </dev/tty || answer=""
  answer="${answer:-N}"
  if [[ ! "$answer" =~ ^[Yy]$ ]]; then
    ua_msg_info "Password-aging changes skipped; no accounts were modified."
    return 0
  fi

  for user in "${targets[@]}"; do
    if chage -m 10 -M 60 -W 7 "$user"; then
      if ua_verify_shadow_aging "$user"; then
        ua_msg_pass "Verified aging for '$user': minimum=10, maximum=60, warning=7 days."
      else
        ua_msg_error "Aging command ran, but /etc/shadow does not show the requested values for '$user'."
        ((failures+=1))
      fi
    else
      ua_msg_error "Could not apply password aging to '$user'."
      ((failures+=1))
    fi
    ((count+=1))
  done

  read -r -p "Also apply the same aging policy to root? [y/N] " root_answer </dev/tty || root_answer=""
  root_answer="${root_answer:-N}"
  if [[ "$root_answer" =~ ^[Yy]$ ]]; then
    if chage -m 10 -M 60 -W 7 root && ua_verify_shadow_aging root; then
      ua_msg_pass "Verified password aging for root."
    else
      ua_msg_error "Could not apply/verify password aging for root."
      ((failures+=1))
    fi
  else
    ua_msg_info "Root password aging left unchanged."
  fi

  printf 'Processed %d human account(s).\n' "$count"
  (( failures == 0 ))
}

# -----------------------------------------------------------------------------
# Review service/system accounts with interactive shells. Low-UID, special, or
# administrator-like identities receive stronger warnings and confirmation.
# -----------------------------------------------------------------------------
ua_review_system_account_shells() {
  local uid_min nologin user _ uid gid gecos home shell groups answer confirm special_user special_shell
  local changed=0 reviewed=0
  ua_require_root || return 1
  uid_min="$(ua_uid_min)"
  nologin="$(ua_nologin_path)" || {
    ua_msg_error "Could not find an executable nologin shell."
    return 1
  }

  echo
  echo "=========== LOW-UID ACCOUNTS WITH LOGIN SHELLS ======="
  while IFS=: read -r user _ uid gid gecos home shell; do
    [[ "$uid" =~ ^[0-9]+$ && "$uid" -gt 0 && "$uid" -lt "$uid_min" ]] || continue
    ua_is_interactive_shell "$shell" || continue
    if [[ "$uid" == 65534 ]]; then
      ua_msg_warn "Special UID 65534 account '$user' has an interactive shell ($shell); it is reported but never changed automatically."
      continue
    fi
    ((reviewed+=1))

    groups="$(ua_user_groups "$user")"
    printf '\nCandidate: %s | UID=%s | HOME=%s | SHELL=%s | GROUPS=%s\n' \
      "$user" "$uid" "$home" "$shell" "${groups:-unknown}"

    if [[ "$home" == /home/* ]]; then
      ua_msg_warn "This low-UID account has a /home directory and may be human-like. It remains actionable below after explicit confirmation."
    fi

    if ua_user_is_admin "$user"; then
      ua_msg_warn "This low-UID account belongs to sudo/wheel; inspect it manually before changing its shell."
      read -r -p "Change administrator-like account '$user' to '$nologin'? [y/N] " answer </dev/tty || answer=""
      if [[ ! "$answer" =~ ^[Yy]$ ]]; then
        ua_msg_info "Shell unchanged for '$user'."
        continue
      fi
    else
      read -r -p "Change system account '$user' to '$nologin'? [y/N] " answer </dev/tty || answer=""
      answer="${answer:-N}"
      if [[ ! "$answer" =~ ^[Yy]$ ]]; then
        ua_msg_info "Shell unchanged for '$user'."
        continue
      fi
    fi

    if ! ua_is_local_user "$user"; then
      ua_msg_warn "'$user' is not local; skipping local shell modification."
      continue
    fi

    if usermod -s "$nologin" "$user"; then
      local verified_shell
      verified_shell="$(getent passwd "$user" | awk -F: 'NR == 1 {print $7}')"
      if [[ "$verified_shell" == "$nologin" ]]; then
        ua_msg_pass "Verified '$user' now uses $nologin."
        ((changed+=1))
      else
        ua_msg_error "usermod ran, but '$user' still reports shell '$verified_shell'."
        return 1
      fi
    else
      ua_msg_error "Could not change shell for '$user'."
      return 1
    fi
  done < <(getent passwd)

  # UID 65534 (normally nobody) is reported separately and uses the same
  # simple yes/no confirmation as other account-shell changes.
  while IFS=: read -r special_user _ uid _ _ home special_shell; do
    [[ "$uid" == 65534 ]] || continue
    if ua_is_interactive_shell "$special_shell"; then
      ua_msg_warn "Special UID 65534 account '$special_user' has interactive shell '$special_shell'. It is never changed automatically."
      if ua_is_local_user "$special_user"; then
        read -r -p "Change this special account to '$nologin'? [y/N] " answer </dev/tty || answer=""
        answer="${answer:-N}"
        if [[ "$answer" =~ ^[Yy]$ ]]; then
          if usermod -s "$nologin" "$special_user" && [[ "$(getent passwd "$special_user" | awk -F: 'NR == 1 {print $7}')" == "$nologin" ]]; then
            ua_msg_pass "Verified special UID 65534 account '$special_user' now uses $nologin."
            ((changed+=1))
          else
            ua_msg_error "Could not change or verify the shell for special account '$special_user'."
            return 1
          fi
        else
          ua_msg_info "Special UID 65534 account '$special_user' was left unchanged."
        fi
      else
        ua_msg_warn "Special UID 65534 account '$special_user' is not local; no change attempted."
      fi
    fi
  done < <(getent passwd)

  if (( reviewed == 0 )); then
    ua_msg_pass "No ordinary low-UID accounts with an interactive shell were found."
  else
    printf 'Reviewed %d low-UID login-shell account(s); changed %d account shell(s) including any explicitly approved special account.\n' "$reviewed" "$changed"
  fi
  echo "====================================================="
  return 0
}

# -----------------------------------------------------------------------------
# User/group management submenu.  These are explicit operator-directed
# actions, not automatic challenge-specific provisioning.
# -----------------------------------------------------------------------------
ua_manage_users_groups() {
  local choice
  ua_require_root || return 1
  while true; do
    echo
    echo "============================================================"
    echo "MANAGE USERS AND GROUPS"
    echo "============================================================"
    echo "1) Create a local user account"
    echo "2) Delete any local account (including system, UID 0, or root)"
    echo "3) Add an existing user to a group"
    echo "4) Remove an existing user from a supplementary group"
    echo "5) Grant sudo administrator membership"
    echo "6) Remove sudo administrator membership"
    echo "7) Change any selected local account's password"
    echo "8) Set shared temporary password for all local accounts (root asked separately)"
    echo "9) Return"
    echo
    read -r -p "Choose an option [1-9]: " choice </dev/tty || return 0
    case "$choice" in
      1) ua_create_local_user || ua_msg_warn "User creation did not complete." ;;
      2) ua_delete_local_user || ua_msg_warn "User deletion did not complete." ;;
      3) ua_add_user_to_group || ua_msg_warn "Group addition did not complete." ;;
      4) ua_remove_user_from_group || ua_msg_warn "Group removal did not complete." ;;
      5) ua_set_sudo_membership add || ua_msg_warn "Sudo membership change did not complete." ;;
      6) ua_set_sudo_membership remove || ua_msg_warn "Sudo membership change did not complete." ;;
      7) ua_change_selected_user_password || ua_msg_warn "Password change did not complete." ;;
      8) ua_set_shared_temp_passwords || ua_msg_warn "One or more temporary-password changes failed or could not be verified." ;;
      9|q|quit|b|back) return 0 ;;
      *) ua_msg_warn "Invalid selection." ;;
    esac
  done
}

ua_create_local_user() {
  local user
  ua_require_root || return 1
  read -r -p "New local username: " user </dev/tty || return 1
  ua_valid_username "$user" || { ua_msg_error "Invalid username."; return 1; }
  if getent passwd "$user" >/dev/null 2>&1; then
    ua_msg_error "Account '$user' already exists."
    return 1
  fi
  if ! command -v adduser >/dev/null 2>&1; then
    ua_msg_error "The Debian/Ubuntu adduser utility is unavailable."
    return 1
  fi

  ua_msg_info "Creating '$user'. adduser will prompt for the password interactively; the password is not stored by this script."
  if adduser --gecos "" "$user"; then
    if getent passwd "$user" >/dev/null 2>&1 && ua_is_local_user "$user"; then
      local password_state
      password_state="$(passwd -S "$user" 2>/dev/null | awk '{print $2}')"
      getent passwd "$user" | awk -F: '{printf "Verified: user=%s UID=%s GID=%s HOME=%s SHELL=%s\n",$1,$3,$4,$6,$7}'
      if [[ "$password_state" == P ]]; then
        ua_msg_pass "Created local account '$user'; passwd -S confirms a password is set."
      else
        ua_msg_warn "Created local account '$user', but passwd -S reports '${password_state:-unknown}'. Set/check its password before allowing login."
      fi
      return 0
    fi
    ua_msg_error "adduser returned success but the new local account could not be verified."
    return 1
  fi
  ua_msg_error "adduser failed for '$user'."
  return 1
}

# -----------------------------------------------------------------------------
# Delete an account with competition-mode override. UID/class/session/admin
# status only trigger warnings. Normal and userdel --force modes are exposed;
# home/mail removal is an explicit separate choice. The OS utility remains the
# final authority and may still reject an operation for platform-level reasons.
# -----------------------------------------------------------------------------
ua_delete_local_user() {
  # This function is also called from account-inventory loops that read
  # getent passwd through process substitution. Every operator prompt in this
  # function MUST read from /dev/tty, never from the loop's inherited stdin.
  local user="${1:-}" record uid gid gecos home shell uid_min class groups current_user
  local choice confirm pids other_admin_count=0 other_admins="" delete_home=0 force_delete=0
  local other_user _ other_uid other_gid other_gecos other_home other_shell other_groups
  local local_record=0

  ua_require_root || return 1
  command -v userdel >/dev/null 2>&1 || {
    ua_msg_error "userdel is unavailable; the operating system account utility is missing."
    return 1
  }

  echo
  echo "================ DELETE ACCOUNT (FULL OVERRIDE) ================"
  ua_msg_warn "This workflow does not block accounts based on name, UID, account class, active session, or administrator status."
  if [[ -z "$user" ]]; then
    read -r -p "Account name to delete: " user </dev/tty || return 1
  else
    printf 'Account supplied by the calling audit: %s\n' "$user"
  fi
  ua_valid_username "$user" || { ua_msg_error "Invalid account name. Only characters supported by this module's account-name validator are accepted."; return 1; }

  record="$(awk -F: -v name="$user" '$1 == name {print; exit}' /etc/passwd 2>/dev/null)"
  if [[ -n "$record" ]]; then
    local_record=1
  else
    # Show NSS information when available, but do not pretend that local
    # userdel can remove an LDAP/SSSD identity. The native command is allowed
    # to make the final determination and will report its own error.
    record="$(getent passwd "$user" 2>/dev/null || true)"
  fi

  if [[ -n "$record" ]]; then
    IFS=: read -r _ _ uid gid gecos home shell <<< "$record"
    uid="${uid:-unknown}"; gid="${gid:-unknown}"; home="${home:-unknown}"; shell="${shell:-unknown}"
  else
    uid="unknown"; gid="unknown"; home="unknown"; shell="unknown"
  fi

  uid_min="$(ua_uid_min)"
  if [[ "$uid" =~ ^[0-9]+$ ]]; then
    class="$(ua_classify_account "$user" "$uid" "$home" "$shell" "$uid_min")"
    groups="$(ua_user_groups "$user")"
  else
    class="UNKNOWN / NOT FOUND IN NSS"
    groups="unknown"
  fi

  printf '\nAccount selected: %s\n' "$user"
  printf '  Local /etc/passwd entry: %s\n  UID/GID: %s/%s\n  Class:   %s\n  Home:    %s\n  Shell:   %s\n  Groups:  %s\n'     "$([[ $local_record == 1 ]] && echo YES || echo NO)" "$uid" "$gid" "$class" "$home" "$shell" "${groups:-none/unknown}"

  if [[ "$user" == root ]]; then
    ua_msg_error "EXTREME RISK: this is the literal root account. Removing it can leave the installation without its expected root identity and break administration, package scripts, recovery, and services."
  elif [[ "$uid" == 0 ]]; then
    ua_msg_error "EXTREME RISK: '$user' has UID 0 and is root-equivalent. Deleting it changes a privileged identity."
  elif [[ "$uid" == 65534 || "$user" == nobody ]]; then
    ua_msg_warn "This is the special nobody/UID-65534 identity. Removing it can break services and file ownership assumptions."
  elif [[ "$class" != HUMAN-CANDIDATE ]]; then
    ua_msg_warn "This is classified as '$class', not a normal human account. Deleting it may break packages or services that depend on it."
  fi

  if (( ! local_record )); then
    ua_msg_warn "No local /etc/passwd entry was found. userdel may reject an NSS/LDAP/SSSD account; local userdel cannot remove an account from a remote identity provider. The command will still be attempted if you confirm."
  fi

  current_user="${SUDO_USER:-}"
  if [[ -z "$current_user" ]] && command -v logname >/dev/null 2>&1; then
    current_user="$(logname 2>/dev/null || true)"
  fi
  if [[ -n "$current_user" && "$user" == "$current_user" ]]; then
    ua_msg_warn "'$user' is the account that launched this script. Deleting it may disrupt the active login/session."
  fi

  if [[ "$uid" =~ ^[0-9]+$ ]] && command -v pgrep >/dev/null 2>&1; then
    pids="$(pgrep -u "$uid" -d ' ' 2>/dev/null || true)"
    [[ -z "$pids" ]] || ua_msg_warn "Processes currently owned by UID $uid: $pids. Normal userdel may reject deletion while these are running; the force choice asks userdel to skip its safety checks."
  fi

  if [[ "$uid" =~ ^[0-9]+$ ]] && { ua_user_in_group "$user" sudo || ua_user_in_group "$user" wheel || ua_user_in_group "$user" admin; }; then
    while IFS=: read -r other_user _ other_uid other_gid other_gecos other_home other_shell; do
      [[ "$other_user" == "$user" ]] && continue
      other_groups="$(ua_user_groups "$other_user")"
      if ua_group_list_has "$other_groups" sudo || ua_group_list_has "$other_groups" wheel || ua_group_list_has "$other_groups" admin; then
        ((other_admin_count+=1))
        other_admins+=" $other_user"
      fi
    done < /etc/passwd
    if (( other_admin_count == 0 )); then
      ua_msg_warn "No other local sudo/wheel/admin group member was found. Deleting '$user' may remove the only obvious group-based administrator."
    else
      ua_msg_warn "Other local group-based administrator(s) detected:${other_admins}"
    fi
  fi

  echo
  echo "Deletion mode:"
  echo "1) Normal delete; preserve home (userdel)"
  echo "2) Normal delete; remove home/mail spool (userdel --remove)"
  echo "3) FORCE delete; preserve home (userdel --force)"
  echo "4) FORCE delete; remove home/mail spool (userdel --force --remove)"
  echo "5) Cancel"
  read -r -p "Choose [1-5]: " choice </dev/tty || return 1
  case "$choice" in
    1) delete_home=0; force_delete=0 ;;
    2) delete_home=1; force_delete=0 ;;
    3) delete_home=0; force_delete=1 ;;
    4) delete_home=1; force_delete=1 ;;
    5|q|quit|b|back) ua_msg_info "Deletion cancelled."; return 0 ;;
    *) ua_msg_warn "Invalid selection; no account changes were made."; return 1 ;;
  esac

  echo
  ua_msg_error "FINAL DELETION WARNING: '$user' (UID $uid) will be removed from the local account database if userdel permits it."
  if (( delete_home )); then
    ua_msg_error "The account's configured home path ('$home') and mail spool are also targeted for removal. This can delete important system data if the account has an unusual home path."
  else
    ua_msg_info "The configured home path will be preserved. Files may remain owned by the deleted numeric UID."
  fi
  if (( force_delete )); then
    ua_msg_error "FORCE MODE: userdel --force skips safety checks and can leave account/group files or the installation inconsistent."
  fi
  printf "Type the account name '%s' to proceed with deletion: " "$user"
  read -r confirm </dev/tty || confirm=""
  [[ "$confirm" == "$user" ]] || { ua_msg_info "Account name did not match; deletion cancelled."; return 1; }

  local -a userdel_args=()
  (( force_delete )) && userdel_args+=(--force)
  (( delete_home )) && userdel_args+=(--remove)
  userdel_args+=(-- "$user")

  if userdel "${userdel_args[@]}"; then
    if ua_is_local_user "$user"; then
      ua_msg_warn "userdel returned success, but '$user' still appears in /etc/passwd. Check account files manually."
      return 1
    fi
    ua_msg_pass "userdel completed and '$user' is no longer present in /etc/passwd."
  else
    ua_msg_error "The operating system's userdel command failed for '$user'. No script-level account-class or UID restriction stopped the request."
    ua_msg_warn "Check the userdel error above, then inspect /etc/passwd, /etc/shadow, /etc/group, /etc/gshadow, /etc/subuid, and /etc/subgid before retrying."
    return 1
  fi

  if (( delete_home )); then
    if [[ -e "$home" ]]; then
      ua_msg_warn "The account is gone, but configured home path '$home' still exists. Inspect it manually."
    else
      ua_msg_pass "Configured home path was removed or was not present."
    fi
  elif [[ "$home" != unknown && -d "$home" ]]; then
    ua_msg_info "Preserved home directory: $home"
  fi
  if [[ "$uid" =~ ^[0-9]+$ ]]; then
    ua_msg_info "Files owned by UID $uid outside the configured home are not searched or deleted by userdel."
  fi
  return 0
}

ua_add_user_to_group() {
  local user group before after
  ua_require_root || return 1
  read -r -p "Local username: " user </dev/tty || return 1
  ua_valid_username "$user" && ua_is_local_user "$user" || { ua_msg_error "Local account not found or username invalid."; return 1; }
  read -r -p "Existing group name: " group </dev/tty || return 1
  ua_valid_username "$group" && ua_is_local_group "$group" || { ua_msg_error "Local group not found or invalid."; return 1; }
  before="$(ua_user_groups "$user")"
  if ua_user_in_group "$user" "$group"; then
    ua_msg_info "'$user' is already a member of '$group'; no change needed."
    return 0
  fi
  if usermod -aG "$group" "$user"; then
    after="$(ua_user_groups "$user")"
    if ua_user_in_group "$user" "$group"; then
      ua_msg_pass "Added '$user' to '$group'."
      printf 'Before: %s\nAfter:  %s\n' "$before" "$after"
      return 0
    fi
    ua_msg_error "usermod returned success but membership could not be verified."
    return 1
  fi
  ua_msg_error "Could not add '$user' to '$group'."
  return 1
}

ua_remove_user_from_group() {
  local user group primary_gid group_gid before after
  ua_require_root || return 1
  read -r -p "Local username: " user </dev/tty || return 1
  ua_valid_username "$user" && ua_is_local_user "$user" || { ua_msg_error "Local account not found or username invalid."; return 1; }
  read -r -p "Supplementary group to remove: " group </dev/tty || return 1
  ua_valid_username "$group" && ua_is_local_group "$group" || { ua_msg_error "Local group not found or invalid."; return 1; }
  primary_gid="$(getent passwd "$user" | awk -F: 'NR == 1 {print $4}')"
  group_gid="$(getent group "$group" | awk -F: 'NR == 1 {print $3}')"
  if [[ "$primary_gid" == "$group_gid" ]]; then
    ua_msg_error "'$group' is '$user's primary group. Refusing to remove the primary group through this action."
    return 1
  fi
  if ! ua_user_in_group "$user" "$group"; then
    ua_msg_info "'$user' is not a member of '$group'; no change needed."
    return 0
  fi
  before="$(ua_user_groups "$user")"
  if gpasswd -d "$user" "$group"; then
    after="$(ua_user_groups "$user")"
    if ! ua_user_in_group "$user" "$group"; then
      ua_msg_pass "Removed '$user' from '$group'."
      printf 'Before: %s\nAfter:  %s\n' "$before" "$after"
      return 0
    fi
    ua_msg_error "Group membership still appears after gpasswd completed."
    return 1
  fi
  ua_msg_error "Could not remove '$user' from '$group'."
  return 1
}

ua_set_sudo_membership() {
  local action="$1" user before after confirm
  ua_require_root || return 1
  read -r -p "Local username: " user </dev/tty || return 1
  ua_valid_username "$user" && ua_is_local_user "$user" || { ua_msg_error "Local account not found or username invalid."; return 1; }

  if ! ua_is_local_group sudo; then
    ua_msg_error "The local sudo group does not exist in /etc/group. Refusing to create it implicitly."
    return 1
  fi

  before="$(ua_user_groups "$user")"
  if [[ "$action" == add ]]; then
    read -r -p "Grant '$user' administrator privileges through sudo? [y/N] " confirm </dev/tty || confirm=""
    confirm="${confirm:-N}"
    [[ "$confirm" =~ ^[Yy]$ ]] || { ua_msg_info "Sudo grant cancelled."; return 0; }
    if ua_user_in_group "$user" sudo; then
      if ua_user_has_unrestricted_sudo_rule "$user"; then
        ua_msg_pass "'$user' is already in sudo and has unrestricted administrator authorization."
      else
        ua_msg_warn "'$user' is in the sudo group, but effective sudo authorization was not independently confirmed. Check sudoers with visudo -c."
      fi
      return 0
    fi
    if usermod -aG sudo "$user" && ua_user_in_group "$user" sudo; then
      after="$(ua_user_groups "$user")"
      ua_msg_pass "Verified '$user' is now a member of the sudo group."
      printf 'Before: %s\nAfter:  %s\n' "$before" "$after"
      if ua_user_has_unrestricted_sudo_rule "$user"; then
        ua_msg_pass "sudo -l confirms unrestricted administrator authorization for '$user'."
      else
        ua_msg_warn "Group membership is present, but sudo -l did not independently confirm effective authorization. Check /etc/sudoers with visudo -c."
      fi
      ua_msg_info "A new login session is normally required for the user's processes to receive updated group membership."
      return 0
    fi
    ua_msg_error "Could not grant or verify sudo membership for '$user'."
    return 1
  fi

  if [[ "$action" == remove ]]; then
    read -r -p "Remove '$user' from the sudo administrator group? [y/N] " confirm </dev/tty || confirm=""
    confirm="${confirm:-N}"
    [[ "$confirm" =~ ^[Yy]$ ]] || { ua_msg_info "Sudo removal cancelled."; return 0; }
    if ! ua_user_in_group "$user" sudo; then
      ua_msg_info "'$user' is not in sudo."
      return 0
    fi
    if gpasswd -d "$user" sudo && ! ua_user_in_group "$user" sudo; then
      after="$(ua_user_groups "$user")"
      ua_msg_pass "Verified '$user' is no longer a member of sudo."
      printf 'Before: %s\nAfter:  %s\n' "$before" "$after"
      if ua_user_in_group "$user" wheel || ua_user_in_group "$user" admin || ua_user_has_unrestricted_sudo_rule "$user"; then
        ua_msg_warn "'$user' may still have full administrator privileges through wheel/admin or another sudoers rule. Review the detailed privilege report."
      elif [[ "$(ua_user_sudo_access_class "$user")" == REVIEW ]]; then
        ua_msg_warn "'$user' retains a shell-capable or high-impact command grant after sudo-group removal. Review sudo -l -U '$user' and the detailed privilege report."
      elif ua_user_has_effective_sudo_rule "$user"; then
        ua_msg_info "Full administrator access was not detected, but limited command-specific sudo permissions remain for '$user'."
      else
        ua_msg_pass "No remaining wheel membership or effective sudoers authorization was detected."
      fi
      return 0
    fi
    ua_msg_error "Could not remove or verify removal of '$user' from sudo."
    return 1
  fi
  ua_msg_error "Internal error: unknown sudo membership operation '$action'."
  return 1
}

# -----------------------------------------------------------------------------
# LightDM guest-session remediation.  Parser accepts LightDM's source prefix,
# e.g. "H  allow-guest=false", as seen on the user's Mint VM.
# -----------------------------------------------------------------------------
ua_parse_lightdm_guest_value() {
  awk '
    {
      line=tolower($0)
      if (line ~ /allow-guest[[:space:]]*=/) {
        sub(/^.*allow-guest[[:space:]]*=[[:space:]]*/, "", line)
        sub(/[[:space:]]+#.*/, "", line)
        gsub(/^[[:space:]]+|[[:space:]]+$/, "", line)
        count++
        if (line != "false") has_nonfalse=1
      }
    }
    END {
      if (count == 0) print "unknown"
      else if (has_nonfalse) print "true-or-conflicting"
      else print "false"
    }
  '
}

ua_disable_lightdm_guest_session() {
  local config_dir="/etc/lightdm" config_file="/etc/lightdm/lightdm.conf"
  local backup="" effective_config="" effective_value="" timestamp
  ua_require_root || return 1

  if [[ ! -d "$config_dir" ]]; then
    ua_msg_error "$config_dir does not exist. LightDM may not be installed; no changes were made."
    return 1
  fi
  if [[ -L "$config_file" ]]; then
    local symlink_target
    symlink_target="$(readlink -- "$config_file" 2>/dev/null || printf unknown)"
    ua_msg_warn "$config_file is a symlink to '$symlink_target'. The replacement operation will replace the symlink itself with a regular configuration file; it will not edit the symlink target in place."
    local symlink_confirm
    read -r -p "Replace the LightDM configuration symlink with a regular file? [y/N] " symlink_confirm </dev/tty || symlink_confirm=""
    [[ "$symlink_confirm" =~ ^[Yy]$ ]] || { ua_msg_info "LightDM symlink left unchanged."; return 1; }
  fi

  timestamp="$(date +%Y%m%d_%H%M%S)"
  if [[ -e "$config_file" ]]; then
    backup="${config_file}.${timestamp}.bak"
    if [[ -e "$backup" ]]; then backup="${config_file}.${timestamp}.$$.bak"; fi
    if ! cp -a -- "$config_file" "$backup"; then
      ua_msg_error "Could not back up $config_file; no changes were made."
      return 1
    fi
    ua_msg_info "Backup created: $backup"
  fi

  if ! ua_write_lightdm_guest_disabled_config "$config_file"; then
    ua_msg_error "Could not write the LightDM configuration."
    if [[ -n "$backup" ]]; then
      cp -a -- "$backup" "$config_file" || ua_msg_error "CRITICAL: automatic rollback failed."
    else
      rm -f -- "$config_file"
    fi
    return 1
  fi
  ua_msg_pass "Wrote allow-guest=false to $config_file."

  if command -v lightdm >/dev/null 2>&1; then
    if effective_config="$(lightdm --show-config 2>&1)"; then
      effective_value="$(printf '%s\n' "$effective_config" | ua_parse_lightdm_guest_value)"
      if [[ "$effective_value" == false ]]; then
        ua_msg_pass "LightDM effective configuration confirms allow-guest=false."
        printf '%s\n' "$effective_config" | grep -i 'allow-guest' | sed 's/^/  /'
      else
        ua_msg_error "LightDM effective value is '${effective_value}', not false."
        ua_msg_warn "The file was written, but another setting may override it. Inspect: sudo lightdm --show-config"
        return 1
      fi
    else
      ua_msg_error "Could not run lightdm --show-config; effective behavior was not verified."
      return 1
    fi
  else
    ua_msg_error "The lightdm command is unavailable; the written setting could not be verified."
    return 1
  fi

  ua_msg_info "No display-manager restart was triggered. The setting applies on the next LightDM restart or reboot."
  return 0
}

ua_write_lightdm_guest_disabled_config() {
  local config_file="$1" config_dir temp
  config_dir="$(dirname -- "$config_file")"
  temp="$(mktemp "${config_dir}/.lightdm.conf.XXXXXX")" || return 1

  if [[ -f "$config_file" ]]; then
    if ! awk '
      function finish_section() {
        if (in_seat && !seat_has_value) print "allow-guest=false"
      }
      /^[[:space:]]*\[[^]]+\][[:space:]]*$/ {
        finish_section()
        section=$0
        sub(/^[[:space:]]*/, "", section)
        sub(/[[:space:]]*$/, "", section)
        in_seat=(section ~ /^\[Seat:/ || section == "[SeatDefaults]")
        if (in_seat) seat_has_value=0
        if (section == "[Seat:*]") found_wildcard=1
        print
        next
      }
      in_seat && tolower($0) ~ /^[[:space:]]*allow-guest[[:space:]]*=/ {
        if (!seat_has_value) print "allow-guest=false"
        seat_has_value=1
        next
      }
      { print }
      END {
        finish_section()
        if (!found_wildcard) print "\n[Seat:*]\nallow-guest=false"
      }
    ' "$config_file" > "$temp"; then
      rm -f -- "$temp"
      return 1
    fi
  else
    printf '[Seat:*]\nallow-guest=false\n' > "$temp" || { rm -f -- "$temp"; return 1; }
  fi

  if ! chown root:root "$temp" || ! chmod 0644 "$temp" || ! mv -f -- "$temp" "$config_file"; then
    rm -f -- "$temp"
    return 1
  fi
}

# -----------------------------------------------------------------------------
# Final account-state verification.  Reports observations; does not silently
# make additional changes.
# -----------------------------------------------------------------------------
ua_verify_account_state() {
  local uid_min user _ uid gid gecos home shell nonroot_uid0=0 empty_pw=0 low_uid_review=0
  uid_min="$(ua_uid_min)"
  echo
  echo "================ FINAL ACCOUNT VERIFICATION ========="

  if ! getent passwd root >/dev/null 2>&1; then
    ua_msg_error "The root account is not returned by NSS."
    return 1
  fi
  ua_msg_pass "root account is present."

  while IFS=: read -r user _ uid gid gecos home shell; do
    [[ "$uid" =~ ^[0-9]+$ ]] || continue
    if [[ "$uid" == 0 && "$user" != root ]]; then
      printf '[FAIL] Non-root UID 0 account remains: %s\n' "$user"
      ((nonroot_uid0+=1))
    fi
    local account_class
    account_class="$(ua_classify_account "$user" "$uid" "$home" "$shell" "$uid_min")"
    if ua_is_local_user "$user"; then
      case "$account_class" in
        HUMAN-CANDIDATE|ROOT/UID0)
          local status state shadow_state
          status="$(LC_ALL=C passwd -S "$user" 2>/dev/null || true)"
          state="$(awk '{print $2}' <<< "$status")"
          shadow_state="$(awk -F: -v name="$user" '$1 == name { if ($2 == "") print "EMPTY"; else print "SET"; exit }' /etc/shadow 2>/dev/null || true)"
          if [[ "$state" == NP || "$shadow_state" == EMPTY ]]; then
            printf '[WARN] Local human/root account has no password hash: %s\n' "$user"
            ((empty_pw+=1))
          fi
          ;;
        LOW-UID-HUMAN-LIKE-REVIEW|UID-MIN-LOGIN-REVIEW)
          ((low_uid_review+=1))
          ;;
      esac
    fi
  done < <(getent passwd)

  if (( nonroot_uid0 == 0 )); then ua_msg_pass "No non-root UID 0 accounts remain."; fi
  if (( empty_pw == 0 )); then ua_msg_pass "No local human accounts with empty/no-password state were detected."; else ua_msg_warn "$empty_pw local human account(s) still need password review."; fi
  if (( low_uid_review > 0 )); then
    ua_msg_warn "$low_uid_review account(s) remain in manual-review classifications (low-UID /home or nonstandard high-UID home); they were not modified as ordinary users automatically."
  fi
  echo "====================================================="

  (( nonroot_uid0 == 0 && empty_pw == 0 ))
}
