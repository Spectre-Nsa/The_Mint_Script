#!/usr/bin/env bash
# Local Policies — Linux Mint 21 / Ubuntu Jammy
# Safe to source from harden.sh; changes are limited to sudo policy and sysctl.
if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then set -euo pipefail; fi

LP_PASS=0 LP_FAIL=0
lp_pass(){ printf '[PASS] %s\n' "$*"; LP_PASS=$((LP_PASS+1)); }
lp_fail(){ printf '[FAIL] %s\n' "$*"; LP_FAIL=$((LP_FAIL+1)); }
lp_info(){ printf '[INFO] %s\n' "$*"; }
lp_backup(){
  local f="$1" stamp dest
  [[ -e "$f" ]] || return 0
  stamp=$(date +%Y%m%d_%H%M%S)_$$
  dest="${f}.${stamp}.bak"
  if cp -a -- "$f" "$dest"; then lp_info "Backup created: $dest"; else lp_fail "Could not back up $f"; return 1; fi
}

# Desired persistent and runtime sysctl values.
# IMPORTANT: writing net.ipv4.ip_forward changes the kernel's
# net.ipv4.conf.all.accept_redirects value automatically. Keep ip_forward
# before the explicit accept_redirects assignment in the list below.
lp_sysctl_pairs(){ cat <<'PAIRS'
net.ipv6.conf.all.accept_ra=0
net.ipv6.conf.all.accept_redirects=0
net.ipv6.conf.all.accept_source_route=0
net.ipv6.conf.all.forwarding=0
net.ipv6.conf.default.accept_ra=0
net.ipv6.conf.default.accept_redirects=0
net.ipv6.conf.default.accept_source_route=0
net.ipv4.ip_forward=0
net.ipv4.conf.all.accept_redirects=0
net.ipv4.conf.all.accept_source_route=0
net.ipv4.conf.all.log_martians=1
net.ipv4.conf.all.rp_filter=1
net.ipv4.conf.all.secure_redirects=0
net.ipv4.conf.all.send_redirects=0
net.ipv4.conf.default.accept_redirects=0
net.ipv4.conf.default.accept_source_route=0
net.ipv4.conf.default.log_martians=1
net.ipv4.conf.default.rp_filter=1
net.ipv4.conf.default.secure_redirects=0
net.ipv4.conf.default.send_redirects=0
net.ipv4.icmp_echo_ignore_broadcasts=1
net.ipv4.icmp_ignore_bogus_error_responses=1
net.ipv4.tcp_syncookies=1
fs.protected_hardlinks=1
fs.protected_symlinks=1
fs.suid_dumpable=0
kernel.randomize_va_space=2
kernel.sysrq=0
PAIRS
}

# Find and neutralize only conflicting assignments for keys managed by this
# module. Original files are backed up; unrelated sysctl settings are kept.
lp_sysctl_clean_conflicts(){
  local desired_tmp count_tmp f real tmp changed total=0 errors=0 nullglob_was_set=0
  local -A seen=()
  shopt -q nullglob && nullglob_was_set=1 || true
  desired_tmp=$(mktemp) || { lp_fail 'Could not create sysctl comparison file.'; return 1; }
  count_tmp=$(mktemp) || { rm -f "$desired_tmp"; lp_fail 'Could not create sysctl counter file.'; return 1; }
  lp_sysctl_pairs > "$desired_tmp"

  shopt -s nullglob
  for f in /etc/sysctl.conf /etc/sysctl.d/*.conf; do
    [[ -f "$f" ]] || continue
    real=$(readlink -f -- "$f" 2>/dev/null || printf '%s' "$f")
    [[ -f "$real" ]] || continue
    [[ "$real" == /etc/sysctl.d/99-hardening.conf ]] && continue
    [[ -n "${seen[$real]+x}" ]] && continue
    seen[$real]=1

    tmp=$(mktemp "${real}.lp.XXXXXX") || { lp_fail "Could not create temporary file for $real."; errors=$((errors+1)); continue; }
    if ! awk -F= -v countfile="$count_tmp" '
      NR==FNR {
        k=$1; v=$2
        gsub(/^[[:space:]]+|[[:space:]]+$/, "", k)
        gsub(/^[[:space:]]+|[[:space:]]+$/, "", v)
        wanted[k]=v
        next
      }
      {
        original=$0
        if ($0 !~ /^[[:space:]]*#/ && index($0, "=") > 0) {
          split($0, part, "=")
          key=part[1]
          gsub(/[[:space:]]/, "", key)
          value=part[2]
          sub(/[[:space:]]*#.*/, "", value)
          gsub(/^[[:space:]]+|[[:space:]]+$/, "", value)
          if ((key in wanted) && value != wanted[key]) {
            # Normalize the active assignment in place. Do not leave the old
            # conflicting value behind as a commented-out line.
            print key " = " wanted[key]
            changed++
            next
          }
        }
        print original
      }
      END { print changed+0 > countfile }
    ' "$desired_tmp" "$real" > "$tmp"; then
      lp_fail "Could not read or process sysctl configuration $real."
      errors=$((errors+1))
      rm -f "$tmp"
      continue
    fi
    changed=$(cat "$count_tmp" 2>/dev/null || printf '0')
    if [[ "$changed" =~ ^[0-9]+$ ]] && (( changed > 0 )); then
      if lp_backup "$real" && install -o root -g root -m 0644 "$tmp" "$real"; then
        lp_info "Normalized $changed conflicting managed sysctl assignment(s) in $real to the required values; unrelated settings were preserved."
        total=$((total+changed))
      else
        lp_fail "Could not safely update conflicting assignments in $real."
        errors=$((errors+1))
      fi
    fi
    rm -f "$tmp"
  done
  if (( nullglob_was_set == 0 )); then shopt -u nullglob; fi
  rm -f "$desired_tmp" "$count_tmp"
  if (( total == 0 )); then lp_info 'No conflicting managed sysctl assignments needed to be changed in /etc/sysctl.conf or /etc/sysctl.d/.'; fi
  (( errors == 0 ))
}

lp_sysctl_persist_and_reload(){
  local config=/etc/sysctl.d/99-hardening.conf tmp key value actual failures=0
  mkdir -p /etc/sysctl.d || { lp_fail 'Could not create /etc/sysctl.d.'; return 1; }
  lp_backup "$config" || return 1
  tmp=$(mktemp) || return 1
  lp_sysctl_pairs > "$tmp"
  if ! install -o root -g root -m 0644 "$tmp" "$config"; then rm -f "$tmp"; lp_fail "Could not install $config"; return 1; fi
  rm -f "$tmp"
  lp_info "Persistent sysctl policy written to $config."

  if ! lp_sysctl_clean_conflicts; then lp_fail 'Could not clean all detected sysctl conflicts.'; fi

  if sysctl --system >/tmp/lp-sysctl-reload.log 2>&1; then lp_pass 'sysctl --system completed.'; else lp_fail 'sysctl --system reported errors; see /tmp/lp-sysctl-reload.log'; cat /tmp/lp-sysctl-reload.log; fi

  # Re-assert the managed values after the persistent reload. This catches
  # settings changed by later-loaded sources or service-side sysctl writes.
  local apply_failures=0
  while IFS='=' read -r key value; do
    if ! sysctl -w "$key=$value" >/dev/null 2>&1; then
      lp_fail "Could not apply runtime sysctl value $key=$value."
      apply_failures=$((apply_failures+1))
    fi
  done < <(lp_sysctl_pairs)
  if (( apply_failures == 0 )); then lp_pass 'Re-applied all managed sysctl values to the running kernel.'; fi

  while IFS='=' read -r key value; do
    actual=$(sysctl -n "$key" 2>/dev/null || printf 'UNAVAILABLE')
    if [[ "$actual" == "$value" ]]; then lp_pass "$key=$actual"; else lp_fail "$key expected $value, effective value is $actual (review remaining overrides or kernel support)."; failures=$((failures+1)); fi
  done < <(lp_sysctl_pairs)
  (( failures == 0 ))
}

# Discover the sudoers files that sudo actually includes. This follows both
# modern (@include/@includedir) and legacy (#include/#includedir) directives.
# Files ignored by sudo's includedir rules (names containing '.' or ending '~')
# are not treated as active configuration.
lp_sudo_discover_files(){
  local main_file="${1:-/etc/sudoers}"
  python3 - "$main_file" <<'PY'
import glob
import os
import re
import shlex
import sys

start = os.path.abspath(sys.argv[1])
queue = [start]
seen = set()
ordered = []

while queue:
    path = os.path.abspath(queue.pop(0))
    if path in seen:
        continue
    seen.add(path)
    if not os.path.lexists(path):
        continue
    if os.path.islink(path):
        print(f"Refusing to follow sudoers symlink: {path}", file=sys.stderr)
        raise SystemExit(2)
    if not os.path.isfile(path):
        continue
    ordered.append(path)
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as stream:
            lines = stream.readlines()
    except OSError as exc:
        print(f"Could not read sudoers include {path}: {exc}", file=sys.stderr)
        raise SystemExit(2)

    for raw in lines:
        text = raw.lstrip()
        match = re.match(r"^(?:@include|#include|@includedir|#includedir)\s+(.+?)\s*$", text)
        if not match:
            continue
        try:
            words = shlex.split(match.group(1), comments=True)
        except ValueError as exc:
            print(f"Could not parse include directive in {path}: {raw.rstrip()}: {exc}", file=sys.stderr)
            raise SystemExit(2)
        if not words:
            continue
        target = words[0]
        if not os.path.isabs(target):
            target = os.path.join(os.path.dirname(path), target)
        if text.startswith(("@includedir", "#includedir")):
            if not os.path.isdir(target):
                continue
            try:
                names = sorted(os.listdir(target))
            except OSError as exc:
                print(f"Could not list sudoers include directory {target}: {exc}", file=sys.stderr)
                raise SystemExit(2)
            for name in names:
                if "." in name or name.endswith("~"):
                    continue
                child = os.path.join(target, name)
                if os.path.isfile(child) or os.path.islink(child):
                    queue.append(child)
        else:
            matches = sorted(glob.glob(target))
            queue.extend(matches if matches else [target])

for path in ordered:
    sys.stdout.buffer.write(os.fsencode(path) + b"\0")
PY
}

# Back up every active sudoers file before changing any of them. The snapshot
# keeps the complete /etc/sudoers.d directory as well, including ignored README
# and local backup files, while the manifest supports exact rollback of every
# active file (including explicit includes outside /etc/sudoers.d).
lp_sudo_backup_configs(){
  local backup_dir="$1" f saved
  shift
  mkdir -p -m 0700 "$backup_dir" "$backup_dir/files" "$backup_dir/sudoers.d" || return 1
  [[ -f /etc/sudoers && ! -L /etc/sudoers ]] || { lp_fail '/etc/sudoers is missing or is a symbolic link.'; return 1; }
  cp -a -- /etc/sudoers "$backup_dir/sudoers" || { lp_fail 'Could not back up /etc/sudoers.'; return 1; }
  if [[ -d /etc/sudoers.d ]]; then
    cp -a -- /etc/sudoers.d/. "$backup_dir/sudoers.d/" || { lp_fail 'Could not completely back up /etc/sudoers.d.'; return 1; }
  fi
  : > "$backup_dir/manifest.nul" || return 1
  for f in "$@"; do
    [[ -f "$f" && ! -L "$f" ]] || { lp_fail "Refusing to edit non-regular or symbolic-link sudoers file: $f"; return 1; }
    saved="$backup_dir/files$f"
    mkdir -p "$(dirname "$saved")" || return 1
    cp -a -- "$f" "$saved" || { lp_fail "Could not back up included sudoers file: $f"; return 1; }
    printf '%s\0%s\0' "$f" "$saved" >> "$backup_dir/manifest.nul" || return 1
  done
  lp_info "Complete sudo policy backup created: $backup_dir"
}

lp_sudo_restore_configs(){
  local backup_dir="$1" target saved errors=0
  [[ -r "$backup_dir/manifest.nul" ]] || { lp_fail "Sudo backup manifest is missing: $backup_dir/manifest.nul"; return 1; }
  while IFS= read -r -d '' target && IFS= read -r -d '' saved; do
    if [[ -e "$saved" || -L "$saved" ]]; then
      cp -a -- "$saved" "$target" || { lp_fail "Could not restore sudoers file: $target"; errors=$((errors+1)); }
    else
      lp_fail "Backup for sudoers file is missing: $saved"
      errors=$((errors+1))
    fi
  done < "$backup_dir/manifest.nul"
  if (( errors == 0 )); then lp_info "Restored sudoers configuration from $backup_dir"; return 0; fi
  return 1
}

# Normalize active sudo policy instead of leaving dangerous directives in
# comments. In particular, !authenticate becomes authenticate in its original
# Defaults scope, and command-specific NOPASSWD tags become PASSWD tags.
# The three verified, package-owned Linux Mint Update helper rules are retained
# as a deliberate vendor exception; they are not the source of the global
# !authenticate competition finding discussed in this project.
lp_sudo_harden_main(){
  local main_file="${1:-/etc/sudoers}"
  shift || true
  python3 - "$main_file" "$@" <<'PY'
import os
import re
import stat
import subprocess
import sys
import tempfile

main_file = os.path.abspath(sys.argv[1])
files = [os.path.abspath(p) for p in sys.argv[2:]]
if main_file not in files:
    files.insert(0, main_file)

try:
    package_owner = subprocess.run(
        ["dpkg-query", "-S", "/etc/sudoers.d/mintupdate"],
        text=True, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, check=False
    ).stdout.strip()
    trusted_mintupdate = package_owner.startswith("mintupdate:")
except OSError:
    trusted_mintupdate = False

mintupdate_rules = {
    "/usr/bin/mint-refresh-cache",
    "/usr/lib/linuxmint/mintUpdate/synaptic-workaround.py",
    "/usr/lib/linuxmint/mintUpdate/dpkg_lock_check.sh",
}

counts = {
    "authenticate": 0,
    "passwd_tags": 0,
    "removed_broad_rules": 0,
    "removed_stale_comments": 0,
    "cleaned_env_keep": 0,
    "normalized_defaults": 0,
    "changed_files": 0,
}


def split_comment(line):
    quote = None
    escaped = False
    for i, char in enumerate(line):
        if escaped:
            escaped = False
            continue
        if char == "\\":
            escaped = True
            continue
        if quote:
            if char == quote:
                quote = None
            continue
        if char in ("'", '"'):
            quote = char
        elif char == "#":
            return line[:i], line[i:]
    return line, ""


def split_commas(value):
    parts = []
    start = 0
    quote = None
    escaped = False
    for i, char in enumerate(value):
        if escaped:
            escaped = False
            continue
        if char == "\\":
            escaped = True
            continue
        if quote:
            if char == quote:
                quote = None
            continue
        if char in ("'", '"'):
            quote = char
        elif char == ",":
            parts.append(value[start:i])
            start = i + 1
    parts.append(value[start:])
    return parts


def clean_env_keep(part):
    match = re.match(r'^(\s*env_keep\s*(?:\+?=|-=)\s*)(["\'])(.*)\2\s*$', part, re.I)
    if not match:
        return part, False, False
    prefix, quote, content = match.groups()
    # env_keep -= is already restrictive; preserve its removal semantics.
    if re.search(r"\benv_keep\s*-\s*=", prefix, re.I):
        return part, False, False
    blocked = {"HOME", "LD_PRELOAD", "LD_LIBRARY_PATH"}
    values = [token for token in content.split() if token.upper() not in blocked]
    removed = len(values) != len(content.split())
    if not values:
        return "", removed, True
    return prefix + quote + " ".join(values) + quote, removed, False


def normalize_defaults(line):
    body, comment = split_comment(line.rstrip("\r\n"))
    newline = "\n" if line.endswith("\n") else ""
    match = re.match(r"^(\s*Defaults(?:[^\s]*)?\s+)(.*)$", body, re.I)
    if not match:
        return line, False, False
    prefix, options = match.groups()
    cleaned = []
    changed = False
    for part in split_commas(options):
        value = part.strip()
        if not value:
            continue
        if re.search(r"(?<![A-Za-z0-9_])!authenticate(?![A-Za-z0-9_])", value, re.I):
            value, n = re.subn(r"(?<![A-Za-z0-9_])!authenticate(?![A-Za-z0-9_])", "authenticate", value, flags=re.I)
            counts["authenticate"] += n
            changed = True
        if re.fullmatch(r"!tty_tickets", value, re.I):
            value = "tty_tickets"
            changed = True
        elif re.fullmatch(r"!(secure_path|logfile|requiretty)", value, re.I):
            # These are disabled overrides, not useful positive policy values.
            # Removing the negative token restores the package/default behavior.
            changed = True
            continue
        value, env_changed, drop_part = clean_env_keep(value)
        if env_changed:
            counts["cleaned_env_keep"] += 1
            changed = True
        if drop_part or not value.strip():
            continue
        cleaned.append(value)
    if not cleaned:
        return "", changed, True
    if changed:
        counts["normalized_defaults"] += 1
        # Remove the old literal token from inline explanatory comments too.
        comment = re.sub(r"!authenticate", "authenticate", comment, flags=re.I)
        return prefix + ", ".join(cleaned) + comment + newline, True, False
    return line, False, False


def is_stale_policy_comment(line):
    stripped = line.lstrip()
    if not stripped.startswith("#") or stripped.startswith(("#include", "#includedir")):
        return False
    lower = stripped.lower()
    return "disabled by local policy" in lower or "!authenticate" in lower


def is_mintupdate_exception(path, active_line):
    if not trusted_mintupdate or path != "/etc/sudoers.d/mintupdate":
        return False
    body, _ = split_comment(active_line)
    match = re.match(r"^\s*ALL\s+ALL\s*=\s*NOPASSWD:\s*(\S+)\s*$", body, re.I)
    return bool(match and match.group(1) in mintupdate_rules)


def normalize_file(path):
    if os.path.islink(path) or not os.path.isfile(path):
        raise RuntimeError(f"refusing to modify non-regular or symbolic-link file: {path}")
    st = os.stat(path, follow_symlinks=False)
    with open(path, "r", encoding="utf-8", errors="replace", newline="") as stream:
        original_lines = stream.readlines()

    output = []
    local_changed = False
    for raw in original_lines:
        if is_stale_policy_comment(raw):
            counts["removed_stale_comments"] += 1
            local_changed = True
            continue

        stripped = raw.lstrip()
        if stripped.startswith("#") and not stripped.startswith(("#include", "#includedir")):
            output.append(raw)
            continue

        active, comment = split_comment(raw.rstrip("\r\n"))
        newline = "\n" if raw.endswith("\n") else ""
        active_stripped = active.strip()

        # Remove the unrestricted all-users/all-commands grant entirely.
        if re.match(r"^ALL\s+ALL\s*=\s*\(ALL(?::ALL)?\)\s+(?:(?:PASSWD|NOPASSWD):\s*)?ALL\s*$", active_stripped, re.I):
            counts["removed_broad_rules"] += 1
            local_changed = True
            continue

        # Root does not need a passwordless sudoers grant for every command.
        if re.match(r"^root\s+ALL\s*=\s*\(ALL(?::ALL)?\)\s+NOPASSWD:\s*ALL\s*$", active_stripped, re.I):
            counts["removed_broad_rules"] += 1
            local_changed = True
            continue

        if re.match(r"^\s*Defaults(?:[^\s]*)?\s+", active):
            normalized, changed, drop_line = normalize_defaults(raw)
            if changed:
                local_changed = True
            if drop_line:
                continue
            raw = normalized
            active, comment = split_comment(raw.rstrip("\r\n"))
            newline = "\n" if raw.endswith("\n") else ""

        # Also catch a continued Defaults directive whose !authenticate token
        # appears on a continuation line rather than the first physical line.
        if re.search(r"(?<![A-Za-z0-9_])!authenticate(?![A-Za-z0-9_])", active, re.I):
            active, n = re.subn(r"(?<![A-Za-z0-9_])!authenticate(?![A-Za-z0-9_])", "authenticate", active, flags=re.I)
            counts["authenticate"] += n
            local_changed = True
            raw = active + comment + newline

        if re.search(r"\bNOPASSWD\s*:", active, re.I) and not is_mintupdate_exception(path, active):
            active, n = re.subn(r"\bNOPASSWD\s*:", "PASSWD:", active, flags=re.I)
            if n:
                counts["passwd_tags"] += n
                local_changed = True
                comment = re.sub(r"NOPASSWD", "PASSWD", comment, flags=re.I)
                raw = active + comment + newline

        # Make sure stale !authenticate text cannot remain in an inline comment.
        if "!authenticate" in comment.lower():
            comment = re.sub(r"!authenticate", "authenticate", comment, flags=re.I)
            raw = active + comment + newline
            local_changed = True

        output.append(raw)

    if path == main_file:
        has_global_authenticate = any(
            re.match(r"^\s*Defaults\s+authenticate(?=\s*(?:,|#|$))", split_comment(line.rstrip("\r\n"))[0], re.I)
            for line in output
        )
        if not has_global_authenticate:
            output.insert(0, "# Local Policy: explicitly require sudo authentication\nDefaults authenticate\n")
            local_changed = True
        has_sudo_grant = any(
            re.match(r"^\s*%sudo\s+ALL\s*=\s*\(ALL(?::ALL)?\)\s+(?:PASSWD:\s*)?ALL(?:\s|$)", split_comment(line.rstrip("\r\n"))[0], re.I)
            for line in output
        )
        if not has_sudo_grant:
            output.append("\n# Local Policy: standard authenticated administrator access\n%sudo ALL=(ALL:ALL) PASSWD: ALL\n")
            local_changed = True

    new_content = "".join(output)
    old_content = "".join(original_lines)
    if new_content != old_content:
        directory = os.path.dirname(path) or "."
        fd, temp_path = tempfile.mkstemp(prefix=".lp-sudoers-", dir=directory, text=True)
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="") as stream:
                stream.write(new_content)
                stream.flush()
                os.fsync(stream.fileno())
            os.chown(temp_path, 0, 0)
            os.chmod(temp_path, 0o440)
            os.replace(temp_path, path)
        finally:
            if os.path.exists(temp_path):
                os.unlink(temp_path)
        counts["changed_files"] += 1
    else:
        # Enforce root ownership and read-only sudoers permissions even if the
        # contents were already compliant.
        os.chown(path, 0, 0)
        os.chmod(path, 0o440)

try:
    for path in files:
        normalize_file(path)
except Exception as exc:
    print(f"Sudo policy normalization failed: {exc}", file=sys.stderr)
    raise SystemExit(1)

print(
    "Sudo policy normalization: "
    f"!authenticate replaced={counts['authenticate']}; "
    f"NOPASSWD converted to PASSWD={counts['passwd_tags']}; "
    f"broad grants removed={counts['removed_broad_rules']}; "
    f"stale generated comments removed={counts['removed_stale_comments']}; "
    f"unsafe env_keep entries removed={counts['cleaned_env_keep']}; "
    f"files changed={counts['changed_files']}"
)
if trusted_mintupdate:
    print("Preserved the three verified package-owned Mint Update NOPASSWD helper rules.")
PY
}

# Verify the resulting active sudoers rules. The package-owned Mint Update
# helper exceptions are reported as informational rather than mistaken for a
# global authentication bypass.
lp_sudo_review_dropins(){
  local f line found=0 mintupdate_trusted=0
  shift 0
  if [[ -f /etc/sudoers.d/mintupdate ]] && dpkg-query -S /etc/sudoers.d/mintupdate 2>/dev/null | grep -q '^mintupdate:'; then
    mintupdate_trusted=1
  fi
  for f in "$@"; do
    [[ -f "$f" && -r "$f" ]] || continue
    while IFS= read -r line || [[ -n "$line" ]]; do
      [[ "$line" =~ ^[[:space:]]*# ]] && continue
      if [[ "$line" =~ !authenticate ]]; then
        lp_fail "Active !authenticate directive remains in $f: $line"
        found=1
      fi
      if [[ "$line" =~ NOPASSWD: ]]; then
        if (( mintupdate_trusted )) && [[ "$f" == /etc/sudoers.d/mintupdate ]] && [[ "$line" =~ ^[[:space:]]*ALL[[:space:]]+ALL[[:space:]]*=[[:space:]]*NOPASSWD:[[:space:]]*(/usr/bin/mint-refresh-cache|/usr/lib/linuxmint/mintUpdate/synaptic-workaround.py|/usr/lib/linuxmint/mintUpdate/dpkg_lock_check.sh)[[:space:]]*$ ]]; then
          lp_info "Preserved verified Linux Mint Update command-specific passwordless rule: $f"
        else
          lp_fail "Unapproved passwordless sudo rule remains in $f: $line"
          found=1
        fi
      fi
      if [[ "$line" =~ env_keep ]] && ! [[ "$line" =~ env_keep[[:space:]]*-[[:space:]]*= ]] && { [[ "$line" =~ LD_PRELOAD ]] || [[ "$line" =~ LD_LIBRARY_PATH ]] || [[ "$line" =~ HOME ]]; }; then
        lp_fail "Unsafe environment preservation remains in $f: $line"
        found=1
      fi
      # The three package-owned Mint Update helper rules are intentional
      # command-specific exceptions. They match ALL ALL syntactically, but do
      # not grant arbitrary commands; do not misclassify them as broad grants.
      if [[ "$line" =~ ^[[:space:]]*ALL[[:space:]]+ALL[[:space:]]*= ]]; then
        if ! { (( mintupdate_trusted )) &&
               [[ "$f" == /etc/sudoers.d/mintupdate ]] &&
               [[ "$line" =~ ^[[:space:]]*ALL[[:space:]]+ALL[[:space:]]*=[[:space:]]*NOPASSWD:[[:space:]]*(/usr/bin/mint-refresh-cache|/usr/lib/linuxmint/mintUpdate/synaptic-workaround.py|/usr/lib/linuxmint/mintUpdate/dpkg_lock_check.sh)[[:space:]]*$ ]]; }; then
          lp_fail "Unrestricted all-user sudo grant remains in $f: $line"
          found=1
        fi
      fi
    done < "$f"
  done
  if (( found == 0 )); then
    lp_pass 'No active !authenticate directives, unapproved NOPASSWD tags, unsafe env_keep entries, or all-user sudo grants remain.'
    return 0
  fi
  return 1
}

lp_secure_sudo(){
  [[ ${EUID:-$(id -u)} -eq 0 ]] || { lp_fail 'Sudo repair must run as root.'; return 1; }
  local backup_dir stamp f user admin_fail=0 discovered_file
  local -a sudo_group_members=() sudo_files=()
  stamp=$(date +%Y%m%d_%H%M%S)_$$
  backup_dir="/var/backups/sudo-before-local-policy-$stamp"

  # Installing sudo is only attempted if the package/executable is missing.
  # Reinstalling an already-installed sudo package is unnecessary here and can
  # introduce package/configuration changes unrelated to this policy repair.
  if ! dpkg-query -W -f='${Status}' sudo 2>/dev/null | grep -q '^install ok installed$' || [[ ! -x /usr/bin/sudo ]]; then
    if ! DEBIAN_FRONTEND=noninteractive apt-get install -y sudo; then
      lp_fail 'Sudo package installation failed.'
      return 1
    fi
    lp_pass 'Sudo package installed.'
  else
    lp_pass 'Sudo package is installed; no package reinstall was necessary.'
  fi

  [[ -f /etc/sudoers && ! -L /etc/sudoers ]] || { lp_fail '/etc/sudoers is missing or is a symbolic link.'; return 1; }
  mkdir -p /etc/sudoers.d || { lp_fail 'Could not ensure /etc/sudoers.d exists.'; return 1; }
  discovered_file=$(mktemp) || { lp_fail 'Could not create sudoers discovery list.'; return 1; }
  if ! lp_sudo_discover_files /etc/sudoers > "$discovered_file"; then
    rm -f "$discovered_file"
    lp_fail 'Could not safely discover all active sudoers include files; no hardening changes were made.'
    return 1
  fi
  mapfile -d '' -t sudo_files < "$discovered_file"
  rm -f "$discovered_file"
  if ((${#sudo_files[@]} == 0)); then lp_fail 'No active sudoers configuration files were discovered.'; return 1; fi
  for f in "${sudo_files[@]}"; do
    if [[ ! -f "$f" || -L "$f" ]]; then
      lp_fail "Unsupported sudoers include (not a regular file or is a symlink): $f"
      return 1
    fi
  done

  # Every active file is snapshotted before the first chmod or content edit.
  if ! lp_sudo_backup_configs "$backup_dir" "${sudo_files[@]}"; then
    lp_fail 'Sudo configuration backup was incomplete; no hardening changes were made.'
    return 1
  fi

  lp_info 'Existing active sudo policy inventory (all included files):'
  for f in "${sudo_files[@]}"; do
    printf '\n--- %s ---\n' "$f"
    nl -ba "$f" 2>/dev/null || true
  done

  if getent group sudo >/dev/null; then
    IFS=, read -r -a sudo_group_members <<< "$(getent group sudo | awk -F: '{print $4}')"
    lp_info "Existing sudo-group members: ${sudo_group_members[*]:-(none)}"
  fi

  # Keep the sudoers directory private to root, and make every active policy
  # file root-owned/read-only. Exact original metadata remains in the backup.
  if ! chown root:root /etc/sudoers || ! chmod 0440 /etc/sudoers; then
    lp_fail 'Could not secure /etc/sudoers ownership or permissions.'
    lp_sudo_restore_configs "$backup_dir" || true
    return 1
  fi
  for f in "${sudo_files[@]}"; do
    if ! chown root:root "$f" || ! chmod 0440 "$f"; then
      lp_fail "Could not secure ownership/permissions on $f"
      lp_sudo_restore_configs "$backup_dir" || true
      return 1
    fi
  done
  lp_pass 'The main sudoers file and all active included policy files are root-owned with mode 0440.'

  if ! lp_sudo_harden_main /etc/sudoers "${sudo_files[@]}"; then
    lp_fail 'Sudo policy normalization failed; restoring the complete pre-change configuration.'
    lp_sudo_restore_configs "$backup_dir" || lp_fail 'Automatic sudoers rollback was incomplete; restore from the backup directory manually.'
    return 1
  fi
  lp_info 'Normalized the existing main sudoers file and its included files in place; no new sudoers drop-in was created.'

  if ! visudo -c >/tmp/lp-visudo-after.log 2>&1; then
    lp_fail 'Final sudoers validation failed; restoring the complete pre-change configuration.'
    cat /tmp/lp-visudo-after.log
    lp_sudo_restore_configs "$backup_dir" || lp_fail 'Automatic sudoers rollback was incomplete; restore from the backup directory manually.'
    return 1
  fi
  lp_pass 'Main sudoers and all included files pass visudo -c.'

  if ! lp_sudo_review_dropins "${sudo_files[@]}"; then
    lp_fail 'One or more unsafe sudoers directives remain; restoring the pre-change configuration.'
    lp_sudo_restore_configs "$backup_dir" || lp_fail 'Automatic sudoers rollback was incomplete; restore from the backup directory manually.'
    return 1
  fi
  if ! grep -Eq '^[[:space:]]*Defaults[[:space:]]+authenticate([[:space:],#]|$)' /etc/sudoers; then
    lp_fail 'Explicit Defaults authenticate is missing from /etc/sudoers; restoring the pre-change configuration.'
    lp_sudo_restore_configs "$backup_dir" || lp_fail 'Automatic sudoers rollback was incomplete; restore from the backup directory manually.'
    return 1
  fi
  if grep -RInE '^[[:space:]]*[^#].*!authenticate' "${sudo_files[@]}" >/tmp/lp-authenticate-scan.log 2>/dev/null; then
    lp_fail 'An active !authenticate directive remains; see /tmp/lp-authenticate-scan.log.'
    cat /tmp/lp-authenticate-scan.log
    lp_sudo_restore_configs "$backup_dir" || lp_fail 'Automatic sudoers rollback was incomplete; restore from the backup directory manually.'
    return 1
  fi
  lp_pass 'Explicit Defaults authenticate is present and no active !authenticate directive remains.'

  if ((${#sudo_group_members[@]})); then
    for user in "${sudo_group_members[@]}"; do
      [[ -n "$user" ]] || continue
      if id "$user" >/dev/null 2>&1 && sudo -l -U "$user" >/tmp/lp-sudo-list-$$ 2>&1; then
        # sudo -l may display authenticated grants as either "(ALL) ALL"
        # or "(ALL) PASSWD: ALL". Accept both forms, but never treat
        # "NOPASSWD: ALL" as proof of password-authenticated admin access.
        if grep -qE '\([[:space:]]*ALL([[:space:]]*:[[:space:]]*ALL)?[[:space:]]*\)[[:space:]]+(PASSWD:[[:space:]]*)?ALL([[:space:]]|$)' /tmp/lp-sudo-list-$$; then
          lp_pass "Administrator sudo access verified for $user."
        else
          lp_fail "Could not confirm full administrator sudo access for $user; inspect sudo -l -U output."
          cat /tmp/lp-sudo-list-$$
          admin_fail=1
        fi
      else
        lp_fail "Could not query sudo privileges for $user."
        admin_fail=1
      fi
    done
  else
    lp_info 'No explicit sudo-group members were listed; no human administrator could be tested from this group.'
  fi
  rm -f /tmp/lp-sudo-list-$$
  (( admin_fail == 0 ))
}

invoke_local_policy(){
  LP_PASS=0; LP_FAIL=0
  printf '\n============================================================\n[Local Policy] Applying and verifying local policies\n============================================================\n'
  if ! lp_secure_sudo; then lp_info 'Sudo hardening/verification requires review.'; fi
  if ! lp_sysctl_persist_and_reload; then lp_info 'One or more sysctl checks failed; review the reported effective values and overrides.'; fi
  printf '\n---------------- Local Policy Results ----------------\n'
  printf '[PASS] Successful checks: %s\n' "$LP_PASS"
  printf '[FAIL] Failed checks:     %s\n' "$LP_FAIL"
  if (( LP_FAIL == 0 )); then lp_pass 'Local Policy completed; all implemented checks passed.'; else lp_fail 'Local Policy completed with failures. Review before considering the machine hardened.'; fi
  return $(( LP_FAIL > 0 ))
}
