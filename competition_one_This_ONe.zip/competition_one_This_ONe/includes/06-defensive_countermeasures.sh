#!/usr/bin/env bash

# Includes are normally sourced by harden.sh; do not leak strict mode into
# the parent shell. The main project runs this module as root.
if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
  set -euo pipefail
fi

# Optional scenario-specific allowlist. Define this in config.sh after reading
# the competition README, for example:
#   DCM_CRITICAL_SERVICES=("22/tcp" "80/tcp" "443/tcp" "Samba")
# If it is not defined, the operator is prompted for one UFW profile/port at a
# time. Do not populate this with generic services unless the scenario needs them.

# -----------------------------------------------------------------------------
# Public entry point
# -----------------------------------------------------------------------------
invoke_defensive_countermeasures () {
  local DCM_FAILURES=0
  local DCM_WARNINGS=0
  local DCM_BACKUP_DIR=""
  local DCM_RESET_ANSWER="N"
  local DCM_ENABLE_ANSWER="Y"
  local DCM_INSTALL_ANSWER="N"
  local DCM_SSH_ANSWER="N"
  local DCM_SSH_PORT_ANSWER="22"
  local DCM_UFW_BIN=""
  local -a DCM_SELECTED_SERVICES=()
  local service

  printf '%b[Defensive Countermeasures] Start%b\n' "${CYAN:-}" "${NC:-}"
  printf '\n============================================================\n'
  printf 'UFW FIREWALL CONFIGURATION\n'
  printf '============================================================\n'

  # UFW is optional on Debian/Ubuntu-family installations. Ask before adding
  # the package; if installed, continue through the same portable workflow.
  if ! dcm_ensure_ufw_installed; then
    dcm_info "Defensive Countermeasures stopped before making firewall changes."
    return 1
  fi

  # Show the existing state before asking about reset. Reset is deliberately
  # opt-in because it removes all existing UFW user rules and may remove a
  # challenge-required service allowance.
  dcm_review_existing_firewall

  # Build the challenge-specific allowlist before any reset can remove rules.
  dcm_collect_critical_services

  # SSH is not assumed to be required in every competition round. Ask for
  # this round's requirement and actual listening TCP port; the default is
  # conservative, and nonstandard SSH ports are supported.
  dcm_prompt DCM_SSH_ANSWER \
    "Does this competition round require inbound SSH access? [y/N] " "N"
  case "${DCM_SSH_ANSWER,,}" in
    y|yes)
      while true; do
        dcm_prompt DCM_SSH_PORT_ANSWER "SSH TCP port for this round [22]: " "22"
        if dcm_valid_tcp_port "$DCM_SSH_PORT_ANSWER"; then
          dcm_add_expected_service "${DCM_SSH_PORT_ANSWER}/tcp"
          dcm_info "Added this round's SSH allowance: TCP/${DCM_SSH_PORT_ANSWER}."
          break
        fi
        dcm_warn "Invalid TCP port '$DCM_SSH_PORT_ANSWER'. Enter a number from 1 through 65535."
      done
      ;;
    *)
      dcm_info "No additional SSH firewall allowance will be added unless SSH was explicitly included in the scenario service allowlist."
      ;;
  esac

  dcm_prompt DCM_RESET_ANSWER \
    "Reset UFW to factory defaults? This removes every existing UFW rule. [y/N] " "N"

  # Always preserve the current config and live rule view before modifying it,
  # even when the operator chooses to keep the existing rule set.
  if ! dcm_backup_current_ufw; then
    dcm_error "Could not create a complete UFW backup. Aborting before firewall changes."
    return 1
  fi

  case "${DCM_RESET_ANSWER,,}" in
    y|yes)
      dcm_ufw_reset_factory
      ;;
    *)
      dcm_info "Existing firewall rules will be preserved. The selected baseline rules will be added without deleting existing rules."
      ;;
  esac

  # Configure predictable host firewall defaults and loopback behavior.
  dcm_ufw_set_default_policies
  dcm_ufw_loopback_policy

  # Insert echo-request DROP rules in UFW's before-rules files. UFW evaluates
  # before.rules before user-created rules, so a normal `ufw deny` can be
  # overridden by the stock echo-request ACCEPT rule. See ufw-framework(8).
  dcm_ufw_deny_ping

  # Add scenario-specific service allowances, including SSH only when selected for this round.
  for service in "${DCM_SELECTED_SERVICES[@]}"; do
    dcm_ufw_allow_service "$service"
  done

  dcm_prompt DCM_ENABLE_ANSWER \
    "Enable UFW now and at boot after applying the selected rules? [Y/n] " "Y"
  case "${DCM_ENABLE_ANSWER,,}" in
    n|no)
      dcm_warn "UFW was configured but NOT enabled. The firewall checklist is not complete until it is enabled and verified."
      ;;
    *)
      dcm_ufw_enable_and_boot
      ;;
  esac

  # Reload after file edits and rule changes. This is safe whether UFW is
  # enabled or disabled; the final verification distinguishes active state.
  if dcm_ufw reload >/dev/null 2>&1; then
    dcm_pass "UFW reload completed."
  else
    dcm_error "UFW reload failed."
  fi

  if ! dcm_ufw_verify; then
    dcm_warn "Final UFW verification could not complete fully. Review the errors above."
  fi

  printf '\n============================================================\n'
  if (( DCM_FAILURES == 0 && DCM_WARNINGS == 0 )); then
    dcm_pass "Defensive Countermeasures completed; all requested firewall checks passed."
  elif (( DCM_FAILURES == 0 )); then
    dcm_warn "Defensive Countermeasures completed with ${DCM_WARNINGS} warning(s). Review skipped or incomplete items above."
  else
    dcm_error "Defensive Countermeasures finished with ${DCM_FAILURES} failed operation(s) and ${DCM_WARNINGS} warning(s). Review the report above."
  fi
  if [[ -n "$DCM_BACKUP_DIR" ]]; then
    dcm_info "Pre-change UFW backup: $DCM_BACKUP_DIR"
  fi
  printf '============================================================\n'
  printf '%b[Defensive Countermeasures] Done%b\n' "${CYAN:-}" "${NC:-}"

  (( DCM_FAILURES == 0 ))
}

# -----------------------------------------------------------------------------
# Privilege wrapper
# -----------------------------------------------------------------------------
# The main hardening script normally runs as root. Avoid calling sudo from an
# already-root process: sudoers may intentionally require authentication or
# deny root from invoking sudo. When this module is run by a regular user,
# retain the normal sudo escalation behavior.
dcm_run_root () {
  if [[ "${EUID:-$(id -u)}" -eq 0 ]]; then
    "$@"
  else
    if ! command -v sudo >/dev/null 2>&1; then
      printf '[ERROR] sudo is required for privileged command: %s\n' "$1" >&2
      return 127
    fi
    sudo -- "$@"
  fi
}

# -----------------------------------------------------------------------------
# UFW availability and optional installation
# -----------------------------------------------------------------------------
dcm_resolve_ufw_binary () {
  local found candidate

  found="$(command -v ufw 2>/dev/null || true)"
  if [[ -n "$found" && -x "$found" ]]; then
    DCM_UFW_BIN="$found"
    return 0
  fi

  # Administrative directories are sometimes omitted from a regular user's
  # PATH even though the package is installed.
  for candidate in /usr/sbin/ufw /sbin/ufw /usr/local/sbin/ufw; do
    if [[ -x "$candidate" ]]; then
      DCM_UFW_BIN="$candidate"
      return 0
    fi
  done

  found="$(dcm_run_root sh -c 'command -v ufw' 2>/dev/null || true)"
  if [[ -n "$found" ]]; then
    DCM_UFW_BIN="$found"
    return 0
  fi

  return 1
}

dcm_ufw () {
  if [[ -z "${DCM_UFW_BIN:-}" ]] && ! dcm_resolve_ufw_binary; then
    printf '[ERROR] UFW executable could not be located.\n' >&2
    return 127
  fi
  dcm_run_root "$DCM_UFW_BIN" "$@"
}

dcm_ensure_ufw_installed () {
  if dcm_resolve_ufw_binary; then
    dcm_pass "UFW is available at '$DCM_UFW_BIN'."
    return 0
  fi

  dcm_info "UFW is not installed or could not be found in the standard administrative paths."
  dcm_prompt DCM_INSTALL_ANSWER \
    "Install UFW now using APT? [y/N] " "N"

  case "${DCM_INSTALL_ANSWER,,}" in
    y|yes)
      if ! command -v apt-get >/dev/null 2>&1; then
        dcm_error "APT (apt-get) is unavailable; this module cannot install UFW on this system."
        return 1
      fi
      dcm_info "Installing the UFW package. Existing firewall settings will not be enabled until the later confirmation."
      if ! dcm_run_root env DEBIAN_FRONTEND=noninteractive apt-get install -y ufw; then
        dcm_error "UFW installation failed. No firewall configuration was attempted."
        return 1
      fi
      if ! dcm_resolve_ufw_binary; then
        dcm_error "The package manager reported success, but the UFW executable could not be located."
        return 1
      fi
      dcm_pass "UFW was installed and is available at '$DCM_UFW_BIN'."
      return 0
      ;;
    *)
      dcm_warn "UFW installation was declined. No firewall configuration was changed."
      return 1
      ;;
  esac
}

# -----------------------------------------------------------------------------
# Output and prompt helpers
# -----------------------------------------------------------------------------
dcm_pass () { printf '[PASS] %s\n' "$*"; }
dcm_info () { printf '[INFO] %s\n' "$*"; }
dcm_warn () {
  printf '[WARN] %s\n' "$*"
  if declare -p DCM_WARNINGS >/dev/null 2>&1; then
    DCM_WARNINGS=$((DCM_WARNINGS + 1))
  fi
}
dcm_error () {
  printf '[ERROR] %s\n' "$*" >&2
  if declare -p DCM_FAILURES >/dev/null 2>&1; then
    DCM_FAILURES=$((DCM_FAILURES + 1))
  fi
}

dcm_prompt () {
  local output_var="$1"
  local prompt_text="$2"
  local default_value="${3:-}"
  local answer=""

  if [[ -r /dev/tty ]]; then
    IFS= read -r -p "$prompt_text" answer </dev/tty || answer="$default_value"
  elif [[ -t 0 ]]; then
    IFS= read -r -p "$prompt_text" answer || answer="$default_value"
  else
    dcm_warn "No interactive terminal is available; using default answer '${default_value}'."
    answer="$default_value"
  fi

  [[ -n "$answer" ]] || answer="$default_value"
  printf -v "$output_var" '%s' "$answer"
}

# Validate a single UFW application profile or port/protocol expression.
# Passing the expression as one quoted argument avoids shell interpretation.
dcm_valid_service_spec () {
  local spec="$1"
  [[ -n "$spec" && ${#spec} -le 128 ]] || return 1
  [[ "$spec" != -* ]] || return 1
  [[ "$spec" =~ ^[[:alnum:]_.:+/-]+([[:space:]][[:alnum:]_.:+/-]+)*$ ]]
}

# Validate an SSH TCP port supplied for the current competition round.
dcm_valid_tcp_port () {
  local port="$1"
  local numeric_port
  [[ "$port" =~ ^[0-9]{1,5}$ ]] || return 1
  numeric_port=$((10#$port))
  (( numeric_port >= 1 && numeric_port <= 65535 ))
}

# Normalize common daemon/service names to the corresponding UFW profile.
# A process name is not necessarily a valid UFW application-profile name.
dcm_normalize_service_spec () {
  local service="$1"
  # Accept common daemon/process names from `ss -lntup` as well as UFW
  # application-profile names. Samba's smbd/nmbd daemons share one UFW
  # application profile, which opens the profile's defined Samba ports.
  case "${service,,}" in
    ssh|sshd|openssh)          printf '%s' "OpenSSH" ;;
    smbd|nmbd|samba)           printf '%s' "Samba" ;;
    *)                        printf '%s' "$service" ;;
  esac
}

dcm_add_expected_service () {
  local service="$1"
  local normalized existing
  normalized="$(dcm_normalize_service_spec "$service")"

  for existing in "${DCM_SELECTED_SERVICES[@]}"; do
    [[ "${existing,,}" == "${normalized,,}" ]] && return 0
  done
  DCM_SELECTED_SERVICES+=("$normalized")
}

# -----------------------------------------------------------------------------
# Existing state review and backup
# -----------------------------------------------------------------------------
dcm_review_existing_firewall () {
  printf '\n--- Current UFW status (verbose) ---\n'
  if ! dcm_ufw status verbose; then
    dcm_warn "Could not read the current verbose UFW status."
  fi

  printf '\n--- Current UFW rules (numbered) ---\n'
  if ! dcm_ufw status numbered; then
    dcm_warn "Could not read the current numbered UFW rules."
  fi

  if command -v ss >/dev/null 2>&1; then
    printf '\n--- Current listening TCP/UDP sockets (reference only; not automatically opened) ---\n'
    if ! dcm_run_root ss -lntup; then
      dcm_warn "Could not enumerate listening sockets."
    fi
  fi
}

dcm_backup_current_ufw () {
  local stamp backup_root backup_dir status_output numbered_output
  local config_dir defaults_file runtime_snapshot

  config_dir="${DCM_UFW_CONFIG_DIR:-/etc/ufw}"
  defaults_file="${DCM_UFW_DEFAULTS_FILE:-/etc/default/ufw}"
  backup_root="${DCM_UFW_BACKUP_ROOT:-/var/backups}"
  stamp="$(date +%Y%m%d_%H%M%S)"

  if ! dcm_run_root install -d -o root -g root -m 0700 "$backup_root"; then
    dcm_error "Could not create or access backup root '$backup_root'."
    return 1
  fi
  backup_dir="$(dcm_run_root mktemp -d "${backup_root%/}/ufw-before-defensive-countermeasures-${stamp}.XXXXXX" 2>/dev/null)" || {
    dcm_error "Could not create a unique UFW backup directory under '$backup_root'."
    return 1
  }
  dcm_run_root chmod 0700 "$backup_dir" || {
    dcm_error "Could not secure backup directory '$backup_dir'."
    return 1
  }

  if [[ -d "$config_dir" ]]; then
    if ! dcm_run_root cp -a -- "$config_dir" "$backup_dir/ufw"; then
      dcm_error "Could not back up '$config_dir'."
      return 1
    fi
  else
    dcm_error "UFW configuration directory '$config_dir' does not exist."
    return 1
  fi

  if [[ -f "$defaults_file" ]]; then
    if ! dcm_run_root cp -a -- "$defaults_file" "$backup_dir/default-ufw"; then
      dcm_error "Could not back up '$defaults_file'."
      return 1
    fi
  else
    dcm_warn "'$defaults_file' was not found; IPv6/default configuration could not be backed up."
  fi

  status_output="$(dcm_ufw status verbose 2>&1)" || {
    dcm_error "Could not capture the current UFW verbose status for the backup."
    return 1
  }
  numbered_output="$(dcm_ufw status numbered 2>&1)" || {
    dcm_error "Could not capture the current numbered UFW rules for the backup."
    return 1
  }

  if ! printf '%s\n' "$status_output" | dcm_run_root tee "$backup_dir/ufw-status-verbose.txt" >/dev/null; then
    dcm_error "Could not save the verbose UFW status snapshot."
    return 1
  fi
  if ! printf '%s\n' "$numbered_output" | dcm_run_root tee "$backup_dir/ufw-status-numbered.txt" >/dev/null; then
    dcm_error "Could not save the numbered UFW rules snapshot."
    return 1
  fi

  if command -v iptables-save >/dev/null 2>&1; then
    if runtime_snapshot="$(dcm_run_root iptables-save 2>/dev/null)"; then
      printf '%s\n' "$runtime_snapshot" | dcm_run_root tee "$backup_dir/iptables-save.txt" >/dev/null || \
        dcm_warn "Could not write the IPv4 runtime ruleset snapshot; UFW config/status backups remain available."
    else
      dcm_warn "Could not capture the IPv4 runtime ruleset; UFW config/status backups remain available."
    fi
  fi
  if command -v ip6tables-save >/dev/null 2>&1; then
    if runtime_snapshot="$(dcm_run_root ip6tables-save 2>/dev/null)"; then
      printf '%s\n' "$runtime_snapshot" | dcm_run_root tee "$backup_dir/ip6tables-save.txt" >/dev/null || \
        dcm_warn "Could not write the IPv6 runtime ruleset snapshot; UFW config/status backups remain available."
    else
      dcm_warn "Could not capture the IPv6 runtime ruleset; UFW config/status backups remain available."
    fi
  fi

  DCM_BACKUP_DIR="$backup_dir"
  dcm_pass "Backed up UFW configuration and existing rule/status snapshots to '$backup_dir'."
  return 0
}

# -----------------------------------------------------------------------------
# Scenario-specific critical service allowlist
# -----------------------------------------------------------------------------
dcm_collect_critical_services () {
  local spec configured=0
  local declaration=""
  local input=""
  local -a configured_services=()

  printf '\n============================================================\n'
  printf 'SCENARIO-SPECIFIC CRITICAL SERVICE ALLOWLIST\n'
  printf '============================================================\n'
  printf 'Use the competition README to identify services that must accept inbound traffic.\n'
  printf 'Examples: 22/tcp, 80/tcp, 443/tcp, Samba, Apache Full, OpenSSH.\n'
  printf 'Aliases: ssh/sshd -> OpenSSH; smbd/nmbd -> Samba.\n'
  printf 'Listening sockets are shown for reference only; they are NOT automatically opened.\n'

  if declaration="$(declare -p DCM_CRITICAL_SERVICES 2>/dev/null)"; then
    if [[ "$declaration" == declare\ -a* || "$declaration" == declare\ -ax* ]]; then
      configured_services=("${DCM_CRITICAL_SERVICES[@]}")
    elif [[ -n "${DCM_CRITICAL_SERVICES:-}" ]]; then
      IFS=',' read -r -a configured_services <<< "$DCM_CRITICAL_SERVICES"
    fi
  fi

  for spec in "${configured_services[@]}"; do
    # Trim surrounding whitespace from comma-separated scalar values.
    spec="${spec#"${spec%%[![:space:]]*}"}"
    spec="${spec%"${spec##*[![:space:]]}"}"
    [[ -z "$spec" ]] && continue
    if dcm_valid_service_spec "$spec"; then
      dcm_add_expected_service "$spec"
      configured=1
      local normalized_spec
      normalized_spec="$(dcm_normalize_service_spec "$spec")"
      if [[ "$normalized_spec" != "$spec" ]]; then
        dcm_info "Configured critical service '$spec' mapped to UFW profile '$normalized_spec'."
      else
        dcm_info "Configured critical service: $spec"
      fi
    else
      dcm_warn "Ignoring invalid DCM_CRITICAL_SERVICES entry: '$spec'."
    fi
  done

  if (( configured == 0 )); then
    dcm_info "No DCM_CRITICAL_SERVICES allowlist was supplied in config.sh. Enter the services required by this competition README."
    while true; do
      dcm_prompt input "Required service/profile or port/protocol (blank to finish): " ""
      [[ -z "$input" ]] && break
      if dcm_valid_service_spec "$input"; then
        dcm_add_expected_service "$input"
        local normalized_input
        normalized_input="$(dcm_normalize_service_spec "$input")"
        if [[ "$normalized_input" != "$input" ]]; then
          dcm_info "Added '$input' to the challenge allowlist as UFW profile '$normalized_input'."
        else
          dcm_info "Added to challenge allowlist: $input"
        fi
      else
        dcm_warn "Invalid service expression '$input'. Use one UFW application profile or port/protocol per entry."
      fi
    done
  fi

  if (( ${#DCM_SELECTED_SERVICES[@]} == 0 )); then
    dcm_warn "No scenario-specific inbound services were selected. With deny-incoming as the default, unsolicited inbound connections will remain blocked unless an existing rule is preserved."
  else
    printf '\nSelected challenge services:\n'
    printf '  - %s\n' "${DCM_SELECTED_SERVICES[@]}"
  fi
}

# -----------------------------------------------------------------------------
# UFW operations
# -----------------------------------------------------------------------------
dcm_ufw_reset_factory () {
  if dcm_ufw --force reset; then
    dcm_pass "UFW reset completed after the existing configuration and rules were backed up."
  else
    dcm_error "UFW reset failed. Continuing with additive configuration and final verification."
  fi
}

dcm_ufw_set_default_policies () {
  if dcm_ufw default deny incoming; then
    dcm_pass "UFW default incoming policy set to deny."
  else
    dcm_error "Failed to set the default incoming policy to deny."
  fi

  if dcm_ufw default allow outgoing; then
    dcm_pass "UFW default outgoing policy set to allow."
  else
    dcm_error "Failed to set the default outgoing policy to allow."
  fi
}

dcm_ufw_loopback_policy () {
  if dcm_ufw allow in on lo; then
    dcm_pass "Allowed inbound loopback traffic."
  else
    dcm_error "Failed to allow inbound loopback traffic."
  fi

  if dcm_ufw allow out on lo; then
    dcm_pass "Allowed outbound loopback traffic."
  else
    dcm_error "Failed to allow outbound loopback traffic."
  fi

  if dcm_ufw deny in from 127.0.0.0/8; then
    dcm_pass "Added inbound IPv4 loopback-source protection."
  else
    dcm_error "Failed to add inbound IPv4 loopback-source protection."
  fi

  if dcm_ufw deny in from ::1; then
    dcm_pass "Added inbound IPv6 loopback-source protection."
  else
    dcm_error "Failed to add inbound IPv6 loopback-source protection."
  fi
}

dcm_ufw_allow_service () {
  local service="$1"
  if dcm_ufw allow "$service"; then
    dcm_pass "Allowed required challenge service/profile '$service'."
  else
    dcm_error "Failed to allow challenge service/profile '$service'. Check that the UFW application profile exists or that the port/protocol syntax is valid."
  fi
}

dcm_ufw_enable_and_boot () {
  if dcm_ufw --force enable; then
    dcm_pass "UFW enabled."
  else
    dcm_error "Failed to enable UFW."
  fi

  if dcm_run_root systemctl enable ufw.service; then
    dcm_pass "UFW enabled at boot."
  else
    dcm_error "Failed to enable ufw.service at boot."
  fi
}

# -----------------------------------------------------------------------------
# ICMP echo-request drops in before.rules / before6.rules
# -----------------------------------------------------------------------------
dcm_ufw_insert_icmp_drop_rule () {
  local file="$1"
  local chain="$2"
  local type_match="$3"
  local marker="$4"
  local rule="$5"
  local tmp=""

  if [[ ! -f "$file" ]]; then
    dcm_error "Required UFW rules file '$file' is missing; ICMP drop rule was not inserted."
    return 1
  fi

  # Rebuild this small section on each run rather than merely checking for
  # text presence. That also repairs a pre-existing DROP rule placed below the
  # stock ACCEPT rule, where it would never take effect.
  tmp="$(dcm_run_root mktemp "${file}.dcm.XXXXXX" 2>/dev/null)" || {
    dcm_error "Could not create a temporary file beside '$file'."
    return 1
  }

  # Place DROP before UFW's stock echo-request ACCEPT if present; otherwise
  # insert immediately before COMMIT in the filter table.
  if ! dcm_run_root awk \
    -v chain="$chain" \
    -v type_match="$type_match" \
    -v marker="$marker" \
    -v rule="$rule" '
      BEGIN { inserted = 0 }
      {
        # Remove stale copies/markers so the file remains idempotent.
        if ($0 == rule || $0 == marker) next
        if (!inserted && index($0, chain) > 0 && index($0, type_match) > 0 && $0 ~ /-j[[:space:]]+ACCEPT/) {
          print marker
          print rule
          inserted = 1
        }
        if (!inserted && $0 ~ /^COMMIT[[:space:]]*$/) {
          print marker
          print rule
          inserted = 1
        }
        print
      }
      END { if (!inserted) exit 42 }
    ' "$file" | dcm_run_root tee "$tmp" >/dev/null; then
    dcm_run_root rm -f -- "$tmp"
    dcm_error "Could not locate a valid insertion point in '$file'; original file was left unchanged."
    return 1
  fi

  # A sourced parent shell may not have pipefail enabled. Independently verify
  # that awk actually inserted the intended rule before replacing the source.
  if ! dcm_run_root grep -Fq -- "$rule" "$tmp"; then
    dcm_run_root rm -f -- "$tmp"
    dcm_error "Temporary edit did not contain the expected ICMP rule; original file was left unchanged."
    return 1
  fi

  if ! dcm_run_root chown --reference="$file" "$tmp" ||
     ! dcm_run_root chmod --reference="$file" "$tmp" ||
     ! dcm_run_root mv -f -- "$tmp" "$file"; then
    dcm_run_root rm -f -- "$tmp" 2>/dev/null || true
    dcm_error "Could not safely replace '$file' with the updated ICMP rules."
    return 1
  fi

  if dcm_run_root grep -Fq -- "$rule" "$file"; then
    dcm_pass "Inserted and verified ICMP echo-request DROP rule in '$file'."
    return 0
  fi

  dcm_error "ICMP echo-request DROP rule was not present after editing '$file'."
  return 1
}

dcm_ufw_deny_ping () {
  local config_dir="${DCM_UFW_CONFIG_DIR:-/etc/ufw}"
  local ipv6_enabled="yes"
  local defaults_file="${DCM_UFW_DEFAULTS_FILE:-/etc/default/ufw}"
  local ipv4_file="${config_dir%/}/before.rules"
  local ipv6_file="${config_dir%/}/before6.rules"

  if ! dcm_ufw_insert_icmp_drop_rule \
    "$ipv4_file" \
    "ufw-before-input" \
    "--icmp-type echo-request" \
    "# DCM: Drop IPv4 ICMP echo-request" \
    "-A ufw-before-input -p icmp --icmp-type echo-request -j DROP"; then
    :
  fi

  if [[ -f "$defaults_file" ]]; then
    ipv6_enabled="$(dcm_run_root awk -F= '/^[[:space:]]*IPV6[[:space:]]*=/{gsub(/[[:space:]]/, "", $2); value=tolower($2)} END {if (value != "") print value; else print "yes"}' "$defaults_file" 2>/dev/null || printf 'unknown')"
  else
    ipv6_enabled="unknown"
  fi

  # Insert and verify the IPv6 rule in its file regardless of whether the
  # host currently enables IPv6; verification reports the runtime applicability.
  if ! dcm_ufw_insert_icmp_drop_rule \
    "$ipv6_file" \
    "ufw6-before-input" \
    "--icmpv6-type echo-request" \
    "# DCM: Drop IPv6 ICMP echo-request" \
    "-A ufw6-before-input -p icmpv6 --icmpv6-type echo-request -j DROP"; then
    :
  fi

  if [[ "$ipv6_enabled" == "yes" ]]; then
    dcm_info "IPv6 firewall handling is enabled; the IPv6 ICMP drop rule will be checked at runtime."
  elif [[ "$ipv6_enabled" == "no" ]]; then
    dcm_warn "UFW IPv6 handling is disabled in '$defaults_file'. The IPv6 ICMP rule is recorded in before6.rules but will not be active until IPV6=yes is configured."
  else
    dcm_warn "Could not determine whether UFW IPv6 handling is enabled. The IPv6 rule file was still checked."
  fi
}

# -----------------------------------------------------------------------------
# Final verification
# -----------------------------------------------------------------------------
dcm_ufw_verify () {
  local status_output=""
  local ipv4_file="${DCM_UFW_CONFIG_DIR:-/etc/ufw}/before.rules"
  local ipv6_file="${DCM_UFW_CONFIG_DIR:-/etc/ufw}/before6.rules"
  local defaults_file="${DCM_UFW_DEFAULTS_FILE:-/etc/default/ufw}"
  local service
  local ipv6_enabled="yes"

  printf '\n============================================================\n'
  printf 'UFW FINAL VERIFICATION\n'
  printf '============================================================\n'

  if ! status_output="$(dcm_ufw status verbose 2>&1)"; then
    dcm_error "Could not retrieve 'ufw status verbose'."
    return 1
  fi
  printf '%s\n' "$status_output"

  if grep -Fq 'Status: active' <<< "$status_output"; then
    dcm_pass "UFW is active."
  else
    dcm_error "UFW is not active."
  fi

  if grep -Eiq 'Default:[[:space:]]*deny[[:space:]]*\(incoming\)' <<< "$status_output"; then
    dcm_pass "Default incoming policy is deny."
  else
    dcm_error "Default incoming policy is not verified as deny."
  fi

  if grep -Eiq 'Default:.*allow[[:space:]]*\(outgoing\)' <<< "$status_output"; then
    dcm_pass "Default outgoing policy is allow."
  else
    dcm_error "Default outgoing policy is not verified as allow."
  fi

  if grep -Eiq 'on lo.*ALLOW IN|ALLOW IN.*on lo' <<< "$status_output"; then
    dcm_pass "Inbound loopback allowance is present."
  else
    dcm_error "Inbound loopback allowance was not found in UFW status."
  fi

  if grep -Eiq 'on lo.*ALLOW OUT|ALLOW OUT.*on lo' <<< "$status_output"; then
    dcm_pass "Outbound loopback allowance is present."
  else
    dcm_error "Outbound loopback allowance was not found in UFW status."
  fi

  if grep -Eiq '127\.0\.0\.0/8.*DENY IN|DENY IN.*127\.0\.0\.0/8' <<< "$status_output"; then
    dcm_pass "IPv4 loopback-source deny rule is present."
  else
    dcm_error "IPv4 loopback-source deny rule was not found in UFW status."
  fi

  if grep -Eiq '::1.*DENY IN|DENY IN.*::1' <<< "$status_output"; then
    dcm_pass "IPv6 loopback-source deny rule is present."
  else
    dcm_error "IPv6 loopback-source deny rule was not found in UFW status."
  fi

  for service in "${DCM_SELECTED_SERVICES[@]}"; do
    if grep -Fqi -- "$service" <<< "$status_output"; then
      dcm_pass "Expected inbound service '$service' appears in UFW status."
    else
      dcm_error "Expected inbound service '$service' was not found in UFW status."
    fi
  done

  if dcm_run_root grep -Fq -- '-A ufw-before-input -p icmp --icmp-type echo-request -j DROP' "$ipv4_file"; then
    dcm_pass "IPv4 ICMP echo-request DROP rule is present in before.rules."
  else
    dcm_error "IPv4 ICMP echo-request DROP rule is missing from before.rules."
  fi

  if [[ -f "$defaults_file" ]]; then
    ipv6_enabled="$(dcm_run_root awk -F= '/^[[:space:]]*IPV6[[:space:]]*=/{gsub(/[[:space:]]/, "", $2); value=tolower($2)} END {if (value != "") print value; else print "yes"}' "$defaults_file" 2>/dev/null || printf 'unknown')"
  else
    ipv6_enabled="unknown"
  fi

  if dcm_run_root grep -Fq -- '-A ufw6-before-input -p icmpv6 --icmpv6-type echo-request -j DROP' "$ipv6_file"; then
    dcm_pass "IPv6 ICMP echo-request DROP rule is present in before6.rules."
    if [[ "$ipv6_enabled" == "yes" ]]; then
      if command -v ip6tables >/dev/null 2>&1 && dcm_run_root ip6tables -C ufw6-before-input -p icmpv6 --icmpv6-type echo-request -j DROP >/dev/null 2>&1; then
        dcm_pass "IPv6 ICMP echo-request DROP rule is loaded in the running firewall."
      else
        dcm_error "IPv6 ICMP DROP rule is in before6.rules but was not verified in the running ip6tables chain."
      fi
    else
      dcm_warn "IPv6 rule is present in the configuration file, but runtime verification is not applicable because UFW IPV6 is '${ipv6_enabled}'."
    fi
  else
    dcm_error "IPv6 ICMP echo-request DROP rule is missing from before6.rules."
  fi

  if command -v iptables >/dev/null 2>&1; then
    if dcm_run_root iptables -C ufw-before-input -p icmp --icmp-type echo-request -j DROP >/dev/null 2>&1; then
      dcm_pass "IPv4 ICMP echo-request DROP rule is loaded in the running firewall."
    else
      dcm_error "IPv4 ICMP DROP rule is in before.rules but was not verified in the running iptables chain."
    fi
  else
    dcm_warn "iptables command is unavailable; IPv4 ICMP runtime verification was skipped."
  fi

  if systemctl is-enabled --quiet ufw.service; then
    dcm_pass "UFW systemd service is enabled at boot."
  else
    dcm_error "UFW systemd service is not enabled at boot."
  fi

  printf '\n--- Final numbered rules ---\n'
  if ! dcm_ufw status numbered; then
    dcm_error "Could not retrieve final numbered UFW rules."
  fi

  return 0
}
