#!/usr/bin/env bash
# Module 07 - Uncategorized OS Settings
# Intended to be sourced by the main hardening script and invoked as root.

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    set -euo pipefail
fi

# Per-run results are reset by invoke_uncategorized_os.
UOS_PASS=0
UOS_FAIL=0
UOS_WARN=0
UOS_UNOWNED_REPORT=""

uos_pass() {
    UOS_PASS=$((UOS_PASS + 1))
    printf '[PASS] %s\n' "$*"
}

uos_fail() {
    UOS_FAIL=$((UOS_FAIL + 1))
    printf '[FAIL] %s\n' "$*"
}

uos_warn() {
    UOS_WARN=$((UOS_WARN + 1))
    printf '[WARN] %s\n' "$*"
}

uos_info() {
    printf '[INFO] %s\n' "$*"
}

uos_is_package_installed() {
    local status
    status=$(dpkg-query -W -f='${db:Status-Status}' "$1" 2>/dev/null || true)
    [[ "$status" == "installed" ]]
}

invoke_uncategorized_os() {
    UOS_PASS=0
    UOS_FAIL=0
    UOS_WARN=0
    UOS_UNOWNED_REPORT=""

    printf '\n============================================================\n'
    printf '[Uncategorized OS] Applying filesystem and OS security settings\n'
    printf '============================================================\n'

    if (( EUID != 0 )); then
        uos_fail "This module must run as root. Launch the main script with sudo."
        printf '\n[Uncategorized OS] PASS=%s FAIL=%s WARN=%s\n' "$UOS_PASS" "$UOS_FAIL" "$UOS_WARN"
        return 0
    fi

    uos_home_dir_permissions
    uos_login_defs_permissions
    uos_shadow_gshadow_permissions
    uos_passwd_group_permissions
    uos_grub_permissions
    uos_system_map_permissions
    uos_ssh_host_keys_permissions
    uos_sshd_config_permissions
    uos_audit_rules_permissions
    uos_remove_world_writable_files
    uos_report_unowned_files
    uos_review_unowned_files
    uos_var_log_permissions
    uos_tmp_permissions

    # One consolidated verification pass after all permission changes.
    uos_final_permission_verification

    # Deliberately separate from the guest-session setting in Module 03.
    uos_lightdm_default_check

    printf '\n---------------- Uncategorized OS Results ----------------\n'
    printf '[PASS] Successful checks: %s\n' "$UOS_PASS"
    printf '[FAIL] Failed checks:     %s\n' "$UOS_FAIL"
    printf '[WARN] Warnings:          %s\n' "$UOS_WARN"
    if (( UOS_FAIL == 0 )); then
        printf '[PASS] Uncategorized OS checks completed without failures.\n'
    else
        printf '[FAIL] Uncategorized OS completed with failures. Review the reported paths.\n'
    fi
}

# -------------------------------------------------------------------
# Home directories: 0700; verify that the directory owner matches the
# account whose passwd home field points to that directory. Only the
# directory itself is changed; contents are not recursively chowned.
# -------------------------------------------------------------------
uos_home_dir_permissions() {
    local dir user uid gid home found=0
    [[ -d /home ]] || { uos_warn "/home does not exist; home-directory check skipped."; return 0; }

    while IFS= read -r -d '' dir; do
        found=1
        user=""; uid=""; gid=""; home=""
        while IFS=: read -r user _ uid gid _ home _; do
            if [[ "$home" == "$dir" ]]; then
                break
            fi
            user=""; uid=""; gid=""; home=""
        done < <(getent passwd)

        if [[ -n "$user" && -n "$uid" ]]; then
            if ! chown "$uid:$gid" -- "$dir"; then
                uos_fail "Could not set home-directory ownership to $user ($uid:$gid): $dir"
            fi
        else
            uos_warn "No passwd account has this exact home path; owner left unchanged: $dir"
        fi

        if ! chmod 0700 -- "$dir"; then
            uos_fail "Could not set home-directory mode to 0700: $dir"
        fi
    done < <(find /home -mindepth 1 -maxdepth 1 -type d -print0 2>/dev/null)

    (( found == 1 )) || uos_info "No immediate subdirectories found under /home."
}

# -------------------------------------------------------------------
# Apply a required owner/group/mode tuple. Missing optional files are
# reported as not applicable; required paths are reported as failures.
# -------------------------------------------------------------------
uos_apply_path_policy() {
    local path="$1" owner="$2" group="$3" mode="$4" required="$5"

    if [[ ! -e "$path" && ! -L "$path" ]]; then
        if [[ "$required" == "required" ]]; then
            uos_fail "Required path is missing and cannot be secured: $path"
        else
            uos_info "Optional path not present; skipped: $path"
        fi
        return 0
    fi

    if ! chown "$owner:$group" -- "$path"; then
        uos_fail "Could not set ownership ${owner}:${group}: $path"
    fi
    if ! chmod "$mode" -- "$path"; then
        uos_fail "Could not set mode $mode: $path"
    fi
}

# -------------------------------------------------------------------
# /etc/login.defs: 0600 root:root
# -------------------------------------------------------------------
uos_login_defs_permissions() {
    uos_apply_path_policy /etc/login.defs root root 0600 required
}

# -------------------------------------------------------------------
# shadow/gshadow and backups: 0640 root:shadow
# -------------------------------------------------------------------
uos_shadow_gshadow_permissions() {
    local file
    for file in /etc/shadow /etc/shadow- /etc/gshadow /etc/gshadow-; do
        case "$file" in
            */shadow-|*/gshadow-) uos_apply_path_policy "$file" root shadow 0640 optional ;;
            *)                    uos_apply_path_policy "$file" root shadow 0640 required ;;
        esac
    done
}

# -------------------------------------------------------------------
# passwd/group and backups: 0644 root:root
# -------------------------------------------------------------------
uos_passwd_group_permissions() {
    local file
    for file in /etc/passwd /etc/passwd- /etc/group /etc/group-; do
        case "$file" in
            */passwd-|*/group-) uos_apply_path_policy "$file" root root 0644 optional ;;
            *)                  uos_apply_path_policy "$file" root root 0644 required ;;
        esac
    done
}

# -------------------------------------------------------------------
# GRUB config: 0600 root:root
# -------------------------------------------------------------------
uos_grub_permissions() {
    uos_apply_path_policy /boot/grub/grub.cfg root root 0600 required
}

# -------------------------------------------------------------------
# System.map files (if present): 0600 root:root
# -------------------------------------------------------------------
uos_system_map_permissions() {
    local file found=0
    while IFS= read -r -d '' file; do
        found=1
        uos_apply_path_policy "$file" root root 0600 optional
    done < <(find /boot -maxdepth 1 -type f -name 'System.map-*' -print0 2>/dev/null)
    (( found == 1 )) || uos_info "No /boot/System.map-* files found; skipped."
}

# -------------------------------------------------------------------
# SSH host keys: private 0600 and public 0644, root:root.
# -------------------------------------------------------------------
uos_ssh_host_keys_permissions() {
    local file found_private=0 found_public=0

    while IFS= read -r -d '' file; do
        found_private=1
        uos_apply_path_policy "$file" root root 0600 required
    done < <(find /etc/ssh -maxdepth 1 -type f -name 'ssh_host_*_key' ! -name '*.pub' -print0 2>/dev/null)

    while IFS= read -r -d '' file; do
        found_public=1
        uos_apply_path_policy "$file" root root 0644 required
    done < <(find /etc/ssh -maxdepth 1 -type f -name 'ssh_host_*_key.pub' -print0 2>/dev/null)

    (( found_private == 1 )) || uos_info "No SSH private host keys found; skipped."
    (( found_public == 1 )) || uos_info "No SSH public host keys found; skipped."
}

# -------------------------------------------------------------------
# sshd_config: checklist requirement 0600 root:root.
# -------------------------------------------------------------------
uos_sshd_config_permissions() {
    uos_apply_path_policy /etc/ssh/sshd_config root root 0600 optional
}

# -------------------------------------------------------------------
# Audit rules: remove setuid/setgid, group-write, and all other-user bits.
# -------------------------------------------------------------------
uos_audit_rules_permissions() {
    local file found=0
    [[ -d /etc/audit/rules.d ]] || { uos_info "/etc/audit/rules.d not present; audit-rule file check skipped."; return 0; }

    while IFS= read -r -d '' file; do
        found=1
        if chmod u-s,g-ws,o-wrx -- "$file"; then
            uos_info "Normalized audit-rule file permissions: $file"
        else
            uos_fail "Could not normalize audit-rule file permissions: $file"
        fi
    done < <(find /etc/audit/rules.d -maxdepth 1 -type f -name '*.rules' -print0 2>/dev/null)

    (( found == 1 )) || uos_info "No audit .rules files found under /etc/audit/rules.d."
}

# -------------------------------------------------------------------
# Find only files on the root filesystem. -xdev stops traversal onto
# other filesystems; explicit mountpoint pruning also avoids same-device
# bind mounts when findmnt can enumerate them.
# -------------------------------------------------------------------
uos_find_rootfs_world_writable() {
    local mount
    local -a prune_expr=()

    if command -v findmnt >/dev/null 2>&1; then
        while IFS= read -r mount; do
            [[ -n "$mount" && "$mount" != "/" ]] || continue
            # findmnt escapes unusual path characters; decode its common
            # hex-space form for safe -path matching.
            mount=${mount//\\x20/ }
            if (( ${#prune_expr[@]} > 0 )); then
                prune_expr+=(-o)
            fi
            prune_expr+=(-path "$mount")
        done < <(findmnt -rn -o TARGET 2>/dev/null)
    fi

    if (( ${#prune_expr[@]} > 0 )); then
        find / -xdev \( "${prune_expr[@]}" \) -prune -o -type f -perm -0002 -print0 2>/dev/null
    else
        find / -xdev -type f -perm -0002 -print0 2>/dev/null
    fi
}

# -------------------------------------------------------------------
# Remove world-write permission from regular files on the root FS only.
# Other mounted filesystems are deliberately not modified.
# -------------------------------------------------------------------
uos_remove_world_writable_files() {
    local list file pass pass_count total_seen=0 changed=0
    local -A attempted=()
    list=$(mktemp) || { uos_fail "Could not create temporary world-writable-file inventory."; return 0; }

    # Desktop services such as GVFS can create/rotate metadata files while the
    # scan is running. Use a small bounded number of fresh passes so newly
    # created files are caught, without looping forever on active services.
    for pass in 1 2 3; do
        : > "$list"
        if ! uos_find_rootfs_world_writable > "$list"; then
            uos_fail "Could not complete root-filesystem world-writable scan (pass $pass)."
            rm -f -- "$list"
            return 0
        fi

        pass_count=$(tr -cd '\0' < "$list" | wc -c)
        if (( pass_count == 0 )); then
            uos_info "World-writable scan is clean after cleanup pass $pass."
            break
        fi

        uos_info "Cleanup pass $pass found $pass_count world-writable regular file(s)."
        while IFS= read -r -d '' file; do
            [[ -n "${attempted["$file"]+x}" ]] && continue
            attempted["$file"]=1
            total_seen=$((total_seen + 1))
            if uos_harden_world_writable_file "$file"; then
                changed=$((changed + 1))
            fi
        done < "$list"
    done

    rm -f -- "$list"
    uos_info "Root-filesystem world-writable files encountered: $total_seen; permissions corrected: $changed."
    uos_info "Other mounted filesystems were not traversed or modified."
    # Final verification below is authoritative and prints every residual path.
}

# Try chmod first. If an immutable bit is the specific blocker, ask before
# clearing only that bit; never silently remove filesystem flags.
uos_harden_world_writable_file() {
    local file="$1" attr_line="" attr_flags="" answer=""

    if chmod o-w -- "$file"; then
        uos_info "Removed world-write permission: $file"
        return 0
    fi

    if command -v lsattr >/dev/null 2>&1; then
        attr_line=$(lsattr -d -- "$file" 2>/dev/null || true)
        attr_flags=${attr_line%%[[:space:]]*}
    fi

    if [[ "$attr_flags" == *i* ]] && command -v chattr >/dev/null 2>&1; then
        uos_warn "Immutable attribute prevents permission repair: $file"
        if [[ -r /dev/tty ]]; then
            printf 'Clear the immutable flag on this world-writable file and remove world-write permission? [y/N] ' > /dev/tty
            IFS= read -r answer < /dev/tty || answer=""
        fi
        case "$answer" in
            y|Y|yes|YES)
                if chattr -i -- "$file" && chmod o-w -- "$file"; then
                    uos_info "Cleared immutable flag and removed world-write permission: $file"
                    return 0
                fi
                uos_warn "The requested immutable/permission repair did not complete: $file"
                ;;
            *)
                uos_info "Left immutable flag unchanged by operator choice: $file"
                ;;
        esac
    fi

    uos_report_world_writable_blocker "$file"
    return 1
}

# Report why a file could not be corrected. Final verification records the
# actual remaining failure once, after all cleanup operations are complete.
uos_report_world_writable_blocker() {
    local file="$1" attrs="" mount_info="" metadata=""

    metadata=$(stat -c 'owner=%U:%G uid:gid=%u:%g mode=%a type=%F' -- "$file" 2>/dev/null || true)
    if command -v lsattr >/dev/null 2>&1; then
        attrs=$(lsattr -d -- "$file" 2>/dev/null || true)
    fi
    if command -v findmnt >/dev/null 2>&1; then
        mount_info=$(findmnt -T "$file" -no TARGET,FSTYPE,OPTIONS 2>/dev/null || true)
    fi

    [[ -n "$metadata" ]] && uos_info "Blocked-file metadata: $metadata"
    [[ -n "$attrs" ]] && uos_info "Blocked-file attributes (lsattr): $attrs"
    [[ -n "$mount_info" ]] && uos_info "Blocked-file mount: $mount_info"
    uos_warn "Could not correct this world-writable file; final verification will report it: $file"
}

# -------------------------------------------------------------------
# Inventory unowned files/directories across local filesystems. This is
# intentionally read-only: never chown or delete an unowned item blindly.
# -------------------------------------------------------------------
uos_report_unowned_files() {
    local docs_dir report errors mount count report_owner report_group
    docs_dir="${DOCS:-/var/log/linux-hardening}"
    report="$docs_dir/unowned_files.txt"
    errors="$docs_dir/unowned_files_scan_errors.txt"

    if ! mkdir -p -- "$docs_dir"; then
        uos_fail "Could not create report directory: $docs_dir"
        return 0
    fi

    # The module normally runs through sudo. Make reports readable by the
    # invoking administrator, but never world-writable. Explicit install
    # modes avoid inheriting a permissive shell/session umask (e.g. 000).
    report_owner="${SUDO_USER:-root}"
    if ! id "$report_owner" >/dev/null 2>&1; then
        report_owner=root
    fi
    report_group=$(id -gn "$report_owner" 2>/dev/null || printf 'root')

    if ! install -o "$report_owner" -g "$report_group" -m 0600 /dev/null "$report"; then
        uos_fail "Could not create protected unowned-file report: $report"
        return 0
    fi
    if ! install -o "$report_owner" -g "$report_group" -m 0600 /dev/null "$errors"; then
        uos_fail "Could not create protected scan-error report: $errors"
        return 0
    fi

    {
        printf '# Unowned-file inventory generated: %s\n' "$(date '+%F %T %z')"
        printf '# Inventory only. Do not automatically chown or delete entries.\n'
        while IFS= read -r mount; do
            # Skip these FUSE mountpoints before invoking find. find must stat
            # its starting path before evaluating -prune, so pruning inside
            # find still emits Permission denied for an inaccessible start.
            case "$mount" in
                /run/user/*/doc|/run/user/*/gvfs)
                    uos_info "Skipping inaccessible desktop portal mount: $mount"
                    continue
                    ;;
            esac
            find "$mount" -xdev \
                \( -path '/run/user/*/doc' -o -path '/run/user/*/gvfs' \) -prune -o \
                \( -nouser -o -nogroup \) -print 2>> "$errors" || true
        done < <(df --local -P 2>/dev/null | awk 'NR > 1 {print $6}')
    } > "$report"

    # Reassert exact protections after writing, and make the files belong to
    # the invoking user so they can inspect the inventory without sudo.
    if ! chown "$report_owner:$report_group" "$report" "$errors" ||
       ! chmod 0600 "$report" "$errors"; then
        uos_fail "Could not secure ownership/permissions on the unowned-file reports."
    fi

    count=$(grep -vc '^#' "$report" || true)
    UOS_UNOWNED_REPORT="$report"
    uos_info "Found $count unowned files/directories. Inventory: $report"

    if [[ -s "$errors" ]]; then
        uos_warn "Some paths could not be scanned; first scan errors follow (full log: $errors):"
        sed -n '1,5{s/^/[WARN] /;p;}' "$errors"
    else
        rm -f -- "$errors"
        uos_info "No scan errors were reported while building the unowned-file inventory."
    fi
}

# -------------------------------------------------------------------
# Give the operator a safe review procedure; no ownership is changed.
# -------------------------------------------------------------------
uos_review_unowned_files() {
    local answer
    [[ -n "$UOS_UNOWNED_REPORT" && -f "$UOS_UNOWNED_REPORT" ]] || return 0

    printf '\n[INFO] Unowned-file review procedure:\n'
    printf '       1. Inspect each path and its current UID/GID with: stat -c "%%n %%u:%%g %%a" PATH\n'
    printf '       2. For package files, identify the owning package with: dpkg -S PATH\n'
    printf '       3. Compare against the application/service that should own the file.\n'
    printf '       4. Only correct ownership after confirming the intended account and group.\n'
    printf '       The script will not automatically change or delete unowned items.\n'

    if [[ -r /dev/tty ]]; then
        printf 'Display the unowned-file inventory now? [y/N] ' > /dev/tty
        IFS= read -r answer < /dev/tty || answer=""
        case "$answer" in
            y|Y|yes|YES)
                if command -v less >/dev/null 2>&1; then
                    less -FX "$UOS_UNOWNED_REPORT" < /dev/tty
                else
                    cat -- "$UOS_UNOWNED_REPORT"
                fi
                ;;
            *) uos_info "Unowned-file inventory saved for later review: $UOS_UNOWNED_REPORT" ;;
        esac
    else
        uos_info "No interactive terminal available; review the inventory later: $UOS_UNOWNED_REPORT"
    fi
}

# -------------------------------------------------------------------
# /var/log: deliberately do not blanket-chmod files. Log files can have
# service-specific owners and modes; preserve them and report that choice.
# -------------------------------------------------------------------
uos_var_log_permissions() {
    uos_info "Preserving existing /var/log ownership and modes; no blanket chmod is applied."
}

# -------------------------------------------------------------------
# /tmp and /var/tmp: 1777 root:root
# -------------------------------------------------------------------
uos_tmp_permissions() {
    uos_apply_path_policy /tmp root root 1777 required
    uos_apply_path_policy /var/tmp root root 1777 required
}

# -------------------------------------------------------------------
# Final permission verification. All applicable file and directory
# targets are checked after the entire enforcement pass has completed.
# -------------------------------------------------------------------
uos_verify_path_policy() {
    local path="$1" expected_owner="$2" expected_group="$3" expected_mode="$4" required="$5"
    local actual_owner actual_group actual_mode

    if [[ ! -e "$path" && ! -L "$path" ]]; then
        if [[ "$required" == "required" ]]; then
            uos_fail "Final verification: required path is missing: $path"
        else
            uos_info "Final verification: optional path absent: $path"
        fi
        return 0
    fi

    if ! actual_owner=$(stat -c '%U' -- "$path" 2>/dev/null) ||
       ! actual_group=$(stat -c '%G' -- "$path" 2>/dev/null) ||
       ! actual_mode=$(stat -c '%a' -- "$path" 2>/dev/null); then
        uos_fail "Final verification: could not stat $path"
        return 0
    fi

    if [[ "$actual_owner" == "$expected_owner" && "$actual_group" == "$expected_group" && "$actual_mode" == "$expected_mode" ]]; then
        uos_pass "$path is ${expected_owner}:${expected_group} mode ${expected_mode}."
    else
        uos_fail "$path expected ${expected_owner}:${expected_group} ${expected_mode}; found ${actual_owner}:${actual_group} ${actual_mode}."
    fi
}

uos_verify_home_directories() {
    local dir user uid gid home found=0 actual_uid actual_gid actual_mode
    [[ -d /home ]] || { uos_info "Final verification: /home not present."; return 0; }

    while IFS= read -r -d '' dir; do
        found=1
        user=""; uid=""; gid=""; home=""
        while IFS=: read -r user _ uid gid _ home _; do
            if [[ "$home" == "$dir" ]]; then
                break
            fi
            user=""; uid=""; gid=""; home=""
        done < <(getent passwd)

        if ! actual_uid=$(stat -c '%u' -- "$dir" 2>/dev/null) ||
           ! actual_gid=$(stat -c '%g' -- "$dir" 2>/dev/null) ||
           ! actual_mode=$(stat -c '%a' -- "$dir" 2>/dev/null); then
            uos_fail "Could not verify home directory: $dir"
            continue
        fi

        if [[ -z "$user" || -z "$uid" ]]; then
            uos_warn "Could not determine the expected account ownership for home directory: $dir (actual UID:GID $actual_uid:$actual_gid, mode $actual_mode)."
            continue
        fi

        if [[ "$actual_uid" == "$uid" && "$actual_gid" == "$gid" && "$actual_mode" == "700" ]]; then
            uos_pass "Home directory $dir is owned by $user ($uid:$gid) with mode 0700."
        else
            uos_fail "Home directory $dir expected ownership $user ($uid:$gid), mode 0700; found $actual_uid:$actual_gid, mode $actual_mode."
        fi
    done < <(find /home -mindepth 1 -maxdepth 1 -type d -print0 2>/dev/null)

    (( found == 1 )) || uos_info "Final verification: no immediate /home directories to check."
}

uos_verify_ssh_host_keys() {
    local file found=0

    while IFS= read -r -d '' file; do
        found=1
        uos_verify_path_policy "$file" root root 600 required
    done < <(find /etc/ssh -maxdepth 1 -type f -name 'ssh_host_*_key' ! -name '*.pub' -print0 2>/dev/null)
    (( found == 1 )) || uos_info "Final verification: no SSH private host keys found."

    found=0
    while IFS= read -r -d '' file; do
        found=1
        uos_verify_path_policy "$file" root root 644 required
    done < <(find /etc/ssh -maxdepth 1 -type f -name 'ssh_host_*_key.pub' -print0 2>/dev/null)
    (( found == 1 )) || uos_info "Final verification: no SSH public host keys found."
}

uos_verify_system_map() {
    local file found=0
    while IFS= read -r -d '' file; do
        found=1
        uos_verify_path_policy "$file" root root 600 optional
    done < <(find /boot -maxdepth 1 -type f -name 'System.map-*' -print0 2>/dev/null)
    (( found == 1 )) || uos_info "Final verification: no /boot/System.map-* files found."
}

uos_verify_audit_rules() {
    local file mode mode_num found=0
    [[ -d /etc/audit/rules.d ]] || { uos_info "Final verification: audit rules directory absent."; return 0; }

    while IFS= read -r -d '' file; do
        found=1
        if ! mode=$(stat -c '%a' -- "$file" 2>/dev/null); then
            uos_fail "Could not verify audit-rule file: $file"
            continue
        fi
        mode_num=$((8#$mode))
        if (( (mode_num & 06027) == 0 )); then
            uos_pass "Audit-rule file has no setuid/setgid, group-write, or other-user permissions: $file"
        else
            uos_fail "Audit-rule file retains prohibited permission bits: $file (mode $mode)"
        fi
    done < <(find /etc/audit/rules.d -maxdepth 1 -type f -name '*.rules' -print0 2>/dev/null)

    (( found == 1 )) || uos_info "Final verification: no audit .rules files found."
}

uos_verify_rootfs_world_writable() {
    local list count file
    list=$(mktemp) || { uos_fail "Could not create temporary final world-writable scan."; return 0; }
    if ! uos_find_rootfs_world_writable > "$list"; then
        uos_fail "Could not complete the final root-filesystem world-writable scan."
        rm -f -- "$list"
        return 0
    fi
    count=$(tr -cd '\0' < "$list" | wc -c)

    if (( count == 0 )); then
        uos_pass "No world-writable regular files remain on the root filesystem."
    else
        uos_fail "$count world-writable regular file(s) remain on the root filesystem. Full remaining-file list:"
        while IFS= read -r -d '' file; do
            uos_info "Still world-writable: $file"
            stat -c '  owner=%U:%G mode=%a' -- "$file" 2>/dev/null || true
        done < "$list"
    fi
    rm -f -- "$list"
}

uos_final_permission_verification() {
    printf '\n[INFO] Running final permission verification pass...\n'

    uos_verify_home_directories
    uos_verify_path_policy /etc/login.defs root root 600 required
    uos_verify_path_policy /etc/shadow root shadow 640 required
    uos_verify_path_policy /etc/shadow- root shadow 640 optional
    uos_verify_path_policy /etc/gshadow root shadow 640 required
    uos_verify_path_policy /etc/gshadow- root shadow 640 optional
    uos_verify_path_policy /etc/passwd root root 644 required
    uos_verify_path_policy /etc/passwd- root root 644 optional
    uos_verify_path_policy /etc/group root root 644 required
    uos_verify_path_policy /etc/group- root root 644 optional
    uos_verify_path_policy /boot/grub/grub.cfg root root 600 required
    uos_verify_system_map
    uos_verify_ssh_host_keys
    uos_verify_path_policy /etc/ssh/sshd_config root root 600 optional
    uos_verify_path_policy /tmp root root 1777 required
    uos_verify_path_policy /var/tmp root root 1777 required
    uos_verify_audit_rules
    uos_verify_rootfs_world_writable
}

# -------------------------------------------------------------------
# LightDM challenge requirement. Kept as its own independent subfunction
# and does not alter the guest-session setting managed by Module 03.
# -------------------------------------------------------------------
uos_lightdm_default_is_correct() {
    local configured configured_real unit_target

    uos_is_package_installed lightdm || return 1

    [[ -f /etc/X11/default-display-manager ]] || return 1
    configured=$(tr -d '\r\n' < /etc/X11/default-display-manager 2>/dev/null || true)
    [[ -n "$configured" && "${configured##*/}" == "lightdm" && -x "$configured" ]] || return 1
    configured_real=$(readlink -f -- "$configured" 2>/dev/null || true)
    [[ -n "$configured_real" && "${configured_real##*/}" == "lightdm" ]] || return 1

    unit_target=$(systemctl show -p FragmentPath --value display-manager.service 2>/dev/null || true)
    if [[ -z "$unit_target" ]]; then
        unit_target=$(readlink -f /etc/systemd/system/display-manager.service 2>/dev/null || true)
    fi
    [[ -n "$unit_target" && "${unit_target##*/}" == "lightdm.service" ]]
}

uos_lightdm_repair() {
    local lightdm_bin backup_dir alias_path alias_target stamp

    if (( EUID != 0 )); then
        uos_fail "LightDM repair requires root privileges."
        return 1
    fi

    # Preserve the current selection and systemd alias before any package or
    # default-display-manager changes. The repair is only entered after the
    # operator explicitly approves it.
    stamp=$(date '+%Y%m%d_%H%M%S')_$$
    backup_dir="/var/backups/lightdm-repair-$stamp"
    if ! mkdir -p -- "$backup_dir" || ! chmod 0700 -- "$backup_dir"; then
        uos_fail "Could not create a protected LightDM repair backup directory."
        return 1
    fi
    if [[ -e /etc/X11/default-display-manager ]]; then
        if ! cp -a -- /etc/X11/default-display-manager "$backup_dir/default-display-manager.before"; then
            uos_fail "Could not back up /etc/X11/default-display-manager."
            return 1
        fi
    fi
    alias_path=/etc/systemd/system/display-manager.service
    if [[ -e "$alias_path" || -L "$alias_path" ]]; then
        if ! cp -a -- "$alias_path" "$backup_dir/display-manager.service.before"; then
            uos_fail "Could not back up the existing systemd display-manager alias."
            return 1
        fi
    fi
    uos_info "Previous LightDM selection state backed up to: $backup_dir"

    if ! uos_is_package_installed lightdm; then
        uos_info "LightDM is not installed; installing the lightdm package."
        if ! apt-get update || ! DEBIAN_FRONTEND=noninteractive apt-get install -y lightdm; then
            uos_fail "Could not install LightDM."
            return 1
        fi
    fi

    lightdm_bin=$(command -v lightdm 2>/dev/null || true)
    if [[ -z "$lightdm_bin" || ! -x "$lightdm_bin" ]]; then
        uos_fail "The LightDM executable is not available after installation."
        return 1
    fi

    if ! printf '%s\n' 'shared/default-x-display-manager select lightdm' | debconf-set-selections; then
        uos_fail "Could not set the default display-manager selection in debconf."
        return 1
    fi

    if ! DEBIAN_FRONTEND=noninteractive dpkg-reconfigure lightdm; then
        uos_fail "dpkg-reconfigure could not select LightDM."
        return 1
    fi

    # Explicitly enforce the X11 default.
    if ! printf '%s\n' "$lightdm_bin" > /etc/X11/default-display-manager; then
        uos_fail "Could not write /etc/X11/default-display-manager."
        return 1
    fi
    if ! chown root:root /etc/X11/default-display-manager || ! chmod 0644 /etc/X11/default-display-manager; then
        uos_fail "Could not secure /etc/X11/default-display-manager."
        return 1
    fi

    # If the standard systemd alias still points at another manager, remove
    # only that alias (its original copy is in backup_dir) before enabling
    # LightDM. Other display-manager packages are not removed or purged.
    if [[ -e "$alias_path" || -L "$alias_path" ]]; then
        alias_target=$(readlink -f -- "$alias_path" 2>/dev/null || true)
        if [[ "${alias_target##*/}" != "lightdm.service" ]]; then
            if ! rm -f -- "$alias_path"; then
                uos_fail "Could not replace the existing systemd display-manager alias."
                return 1
            fi
        fi
    fi

    if ! systemctl enable lightdm.service; then
        uos_fail "Could not enable LightDM's systemd service alias."
        return 1
    fi
    if ! systemctl daemon-reload; then
        uos_fail "systemd daemon-reload failed after selecting LightDM."
        return 1
    fi

    uos_info "LightDM has been selected as the default for the next display-manager start. The current graphical session was not stopped or switched."
}

uos_lightdm_report_selection() {
    local configured unit_target

    if [[ -f /etc/X11/default-display-manager ]]; then
        configured=$(tr -d '\r\n' < /etc/X11/default-display-manager 2>/dev/null || true)
        uos_info "/etc/X11/default-display-manager selects: ${configured:-<empty>}"
    else
        uos_info "/etc/X11/default-display-manager is missing."
    fi

    unit_target=$(systemctl show -p FragmentPath --value display-manager.service 2>/dev/null || true)
    if [[ -z "$unit_target" ]]; then
        unit_target=$(readlink -f /etc/systemd/system/display-manager.service 2>/dev/null || true)
    fi
    uos_info "systemd display-manager.service resolves to: ${unit_target:-<unresolved>}"
}

uos_lightdm_default_check() {
    local package answer

    printf '\n------------------------------------------------------------\n'
    printf '[LightDM] Default display-manager check\n'
    printf '%s\n' '------------------------------------------------------------'

    for package in gdm gdm3 sddm lxdm mdm xdm; do
        if uos_is_package_installed "$package"; then
            uos_info "Alternative display-manager package is installed: $package (it will not be removed automatically)."
        fi
    done

    if uos_lightdm_default_is_correct; then
        uos_pass "LightDM is installed, selected in /etc/X11/default-display-manager, and referenced by systemd display-manager.service."
        return 0
    fi

    uos_warn "LightDM is not fully configured as the default display manager."
    uos_lightdm_report_selection
    if [[ -r /dev/tty ]]; then
        printf 'Attempt to restore LightDM as the default display manager now? [y/N] ' > /dev/tty
        IFS= read -r answer < /dev/tty || answer=""
    else
        answer=""
        uos_info "No interactive terminal; LightDM repair was not started."
    fi

    case "$answer" in
        y|Y|yes|YES)
            if uos_lightdm_repair; then
                if uos_lightdm_default_is_correct; then
                    uos_pass "LightDM default-display-manager and systemd target verification passed after repair."
                else
                    uos_fail "LightDM repair completed, but final default-display-manager verification still failed."
                fi
            fi
            ;;
        *)
            uos_fail "LightDM is not confirmed as the default display manager; no repair was made."
            ;;
    esac
}
