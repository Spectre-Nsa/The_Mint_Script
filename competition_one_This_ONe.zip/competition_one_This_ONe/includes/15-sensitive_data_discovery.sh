#!/usr/bin/env bash
# Sensitive Data Discovery
# Read-only discovery/reporting for Linux competition hardening.
# Source this file from harden.sh, then call invoke_sensitive_data_discovery.
# No credentials, PII values, or matched file contents are printed or recorded.

if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
  set -euo pipefail
fi

sdd_info()  { printf '[INFO] %s\n' "$*"; }
sdd_pass()  { printf '[PASS] %s\n' "$*"; }
sdd_warn()  { printf '[WARN] %s\n' "$*"; }
sdd_error() { printf '[ERROR] %s\n' "$*" >&2; }

invoke_sensitive_data_discovery() {
  local report='/root/sensitive-discovery.txt'
  local workdir='' find_errors='' report_tmp='' scanner_status_file='' scanner_status=''
  local old_umask script_path scan_root max_file_size_mb

  if [[ "${EUID:-$(id -u)}" -ne 0 ]]; then
    sdd_error 'Sensitive data discovery must run as root. Run the hardening script with sudo.'
    return 1
  fi

  if ! command -v find >/dev/null 2>&1 || ! command -v python3 >/dev/null 2>&1 || ! command -v install >/dev/null 2>&1; then
    sdd_error 'Required command missing: find, python3, or install.'
    return 1
  fi

  if [[ ! -d /root ]]; then
    sdd_error 'The /root directory does not exist; cannot create the protected report.'
    return 1
  fi

  # SDD_SCAN_ROOT is retained as a test/diagnostic override. In normal use the
  # scanner checks a curated set of likely data locations rather than all of /.
  scan_root="${SDD_SCAN_ROOT:-/}"
  max_file_size_mb="${SDD_MAX_FILE_SIZE_MB:-100}"
  if [[ ! "$max_file_size_mb" =~ ^[0-9]+$ ]] || (( max_file_size_mb < 1 || max_file_size_mb > 1024 )); then
    sdd_warn 'SDD_MAX_FILE_SIZE_MB must be an integer from 1 to 1024; using 100 MiB.'
    max_file_size_mb=100
  fi
  if [[ ! -d "$scan_root" ]]; then
    sdd_error "Scan root is not a directory: $scan_root"
    return 1
  fi
  scan_root="$(cd -- "$scan_root" && pwd -P)" || {
    sdd_error 'Could not resolve the scan root.'
    return 1
  }

  script_path="$(readlink -f -- "${BASH_SOURCE[0]}" 2>/dev/null || printf '%s' "${BASH_SOURCE[0]}")"
  old_umask="$(umask)"
  umask 077

  workdir="$(mktemp -d /run/sensitive-discovery.XXXXXX 2>/dev/null)" || {
    umask "$old_umask"
    sdd_error 'Could not create a private temporary directory under /run.'
    return 1
  }
  chmod 0700 "$workdir" || {
    rm -rf -- "$workdir"
    umask "$old_umask"
    sdd_error 'Could not secure the temporary directory.'
    return 1
  }

  find_errors="$workdir/find-errors.txt"
  report_tmp="$workdir/report.txt"
  scanner_status_file="$workdir/status.txt"

  printf '\n============================================================\n'
  printf 'SENSITIVE DATA DISCOVERY\n'
  printf '============================================================\n'
  sdd_info 'Read-only scan. Matching values and file contents will not be printed or stored in the report.'
  if [[ "$scan_root" == '/' ]]; then
    sdd_info 'Targeted locations: /home, /root, /etc, /tmp, /var/tmp, /var/mail, /var/spool/mail, /var/spool/cron, /var/www, /var/log, /var/backups, /srv, /backup, and /backups (existing directories only).'
  else
    sdd_info "Test/diagnostic scope override: $scan_root only."
  fi
  sdd_info "Each target is scanned on its own filesystem only (-xdev); files up to ${max_file_size_mb} MiB are content-scanned."
  sdd_info 'Excluded directory trees: .git, node_modules, .cache, __pycache__, .venv, venv, and /var/log/journal; also the report, scanner, and temporary directory.'
  sdd_info 'Large OS/application trees such as /usr, /opt, and /var/lib are not part of the default scan.'
  sdd_info 'SSN detection runs across every selected location, including /etc and logs; broad email/phone/card detection remains limited to personal/data locations.'
  sdd_info 'Streaming mode: files are processed as they are discovered; periodic progress is displayed.'

  if ! python3 - "$report_tmp" "$find_errors" "$scanner_status_file" "$scan_root" "$report" "$script_path" "$workdir" "$max_file_size_mb" <<'PY'
import csv
import os
import re
import select
import subprocess
import sys
import time
from collections import Counter
from datetime import datetime, timezone

(report_path, find_errors_path, status_path, scan_root, final_report_path,
 script_path, workdir, max_mb_text) = sys.argv[1:]
max_file_bytes = int(max_mb_text) * 1024 * 1024

# These are intentional, high-probability locations for personal data,
# credentials, application secrets, mail, web content, and backups.
DEFAULT_SCAN_ROOTS = [
    "/home", "/root", "/etc", "/tmp", "/var/tmp",
    "/var/mail", "/var/spool/mail", "/var/spool/cron",
    "/var/www", "/var/log", "/var/backups", "/srv",
    "/backup", "/backups",
]
# Generic PII-value patterns are restricted to locations where user records,
# mail, web data, temporary exports, or backups are expected. /etc, /var/log,
# and cron spool remain credential/path-audited, but are not scanned for every
# incidental email or number sequence.
DEFAULT_PII_ROOTS = [
    "/home", "/root", "/tmp", "/var/tmp", "/var/mail",
    "/var/spool/mail", "/var/www", "/srv", "/var/backups",
    "/backup", "/backups",
]

content_patterns = [
    # Report likely credential assignments, not every mention of the words.
    ("password_keyword", re.compile(r"\b(?:password|passwd|pwd|secret|token|key)\b[\"']?\s*[:=]\s*[\"']?\S{4,}", re.I)),
    ("aws_credentials", re.compile(r"\b(?:aws_access_key_id|aws_secret_access_key)\b\s*[:=]|\b(?:AKIA|ASIA)[A-Z0-9]{16}\b", re.I)),
    ("azure_credentials", re.compile(r"\bAZURE_(?:CLIENT_SECRET|CLIENT_ID|TENANT_ID)\b\s*[:=]|\bazure[_ -]?(?:client[_ -]?)?(?:secret|password|token)\b\s*[:=]|\bAccountKey\s*=", re.I)),
    ("google_cloud_credentials", re.compile(r"\bGOOGLE_APPLICATION_CREDENTIALS\b\s*[:=]|\bgcp_service_account\b|\bprivate_key_id\b|[\"']type[\"']\s*:\s*[\"']service_account[\"']", re.I)),
    ("api_key_or_token", re.compile(r"\b(?:api[_ -]?key|access[_ -]?key|secret[_ -]?key|token)\b[\"']?\s*[:=]\s*[\"']?\S{4,}", re.I)),
    ("bearer_token", re.compile(r"\bBearer\s+[A-Za-z0-9._~+/-]{8,}={0,2}", re.I)),
    ("email_address", re.compile(r"(?<![A-Z0-9._%+-])[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}(?![A-Z0-9._%+-])", re.I)),
]

# SSN detection accepts the common hyphenated, spaced, dotted, and compact
# forms. Compact nine-digit values require an SSN label or an SSN column header
# so ordinary IDs, timestamps, and numeric values are not treated as SSNs.
ssn_candidate_pattern = re.compile(
    r"(?<!\d)(?P<area>\d{3})(?P<sep1>[- .]?)(?P<group>\d{2})(?P<sep2>[- .]?)(?P<serial>\d{4})(?!\d)"
)
ssn_label_pattern = re.compile(r"\b(?:ssn|social[ _-]*security(?:[ _-]*number)?)\b", re.I)
ssn_header_token_pattern = re.compile(r"^(?:ssn|social[ _-]*security(?:[ _-]*number)?)$", re.I)
card_candidate_pattern = re.compile(r"(?<!\d)(?:\d[ -]?){12,18}\d(?!\d)")
us_phone_pattern = re.compile(
    r"(?<!\d)(?:\+?1[ .-]?)?(?:\([2-9]\d{2}\)|[2-9]\d{2})[ .-]?[2-9]\d{2}[ .-]?\d{4}(?!\d)"
)
intl_phone_pattern = re.compile(r"(?<![A-Za-z0-9])(?:\+|00)[1-9](?:[ .()/-]*\d){7,14}(?![A-Za-z0-9])")
context_phone_pattern = re.compile(r"\b(?:phone|mobile|telephone|cell|tel)\b", re.I)
context_number_pattern = re.compile(r"(?<!\d)\+?\d[\d .()/-]{7,}\d(?!\d)")

# Field-name indicators are only examined in structured-data files or files
# whose paths are themselves PII-related, avoiding ordinary source-code/docs.
field_prefix = r"(?:^|[,{;\t])\s*[\"']?"
field_suffix = r"[\"']?\s*(?::|=|,|;|\t|$)"
pii_field_patterns = [
    ("first_name_field", re.compile(field_prefix + r"(?:first|given)[_ -]?name" + field_suffix, re.I)),
    ("middle_name_field", re.compile(field_prefix + r"middle[_ -]?name" + field_suffix, re.I)),
    ("last_name_field", re.compile(field_prefix + r"(?:last|family|sur)[_ -]?name" + field_suffix, re.I)),
    ("full_name_field", re.compile(field_prefix + r"(?:full[_ -]?name|person[_ -]?name)" + field_suffix, re.I)),
    ("name_field", re.compile(field_prefix + r"(?:customer|employee|contact|account[_ -]?holder|recipient|person)[_ -]?name" + field_suffix, re.I)),
    ("date_of_birth_field", re.compile(field_prefix + r"(?:dob|birth[_ -]?date|date[_ -]?of[_ -]?birth)" + field_suffix, re.I)),
    ("address_field", re.compile(field_prefix + r"(?:street|home|mailing|postal)[_ -]?address|address(?:[_ -]?(?:line[ _-]?[12]))?" + field_suffix, re.I)),
    ("postal_code_field", re.compile(field_prefix + r"(?:postal|zip)[_ -]?code" + field_suffix, re.I)),
    ("government_id_field", re.compile(field_prefix + r"(?:ssn|social[_ -]?security(?:[_ -]?number)?|passport(?:[_ -]?(?:no|number))?|driver'?s?[_ -]?licen[cs]e(?:[_ -]?(?:no|number))?|national[_ -]?id|taxpayer[_ -]?id|tax[_ -]?id|itin|ein)" + field_suffix, re.I)),
    ("financial_account_field", re.compile(field_prefix + r"(?:bank[_ -]?account(?:[_ -]?(?:no|number))?|routing[_ -]?number|account[_ -]?number|card[_ -]?(?:number|no))" + field_suffix, re.I)),
    ("medical_identifier_field", re.compile(field_prefix + r"(?:medical[_ -]?record(?:[_ -]?(?:no|number))?|patient[_ -]?id|insurance[_ -]?(?:member|policy)[_ -]?(?:id|number))" + field_suffix, re.I)),
    ("email_field", re.compile(field_prefix + r"(?:e[_ -]?mail|email[_ -]?address)" + field_suffix, re.I)),
    ("phone_field", re.compile(field_prefix + r"(?:phone|mobile|telephone|cell)[_ -]?(?:number|no)?" + field_suffix, re.I)),
]
structured_extensions = {
    ".csv", ".tsv", ".json", ".jsonl", ".ndjson", ".xml", ".yaml", ".yml", ".toml", ".sql"
}

pii_path_pattern = re.compile(
    r"(?i)(?:^|[^a-z0-9])(?:pii|personal(?:[_ -]?data)?|customers?|clients?|employees?|personnel|contacts?|payroll|patients?|members?|identity|user[_ -]?data|address[_ -]?books?|subscribers?|students?|applicants?)(?:$|[^a-z0-9])"
)
def pii_scan_eligible(path):
    normalized = os.path.normpath(path).replace(os.sep, "/")
    if scan_root != "/":
        return True  # Diagnostic fixture/root override: inspect all supplied files.
    if pii_path_pattern.search(normalized):
        return True
    for root in DEFAULT_PII_ROOTS:
        root = root.rstrip("/") or "/"
        if normalized == root or normalized.startswith(root + "/"):
            return True
    return False


private_key_begin = re.compile(r"-----BEGIN\s+(?:(?:RSA|OPENSSH|DSA|EC)\s+)?PRIVATE\s+KEY-----", re.I)
private_key_end = re.compile(r"-----END\s+(?:(?:RSA|OPENSSH|DSA|EC)\s+)?PRIVATE\s+KEY-----", re.I)
credential_path_names = {".netrc", ".git-credentials"}

counts = Counter()  # Number of UNIQUE files with each category.
findings = {}       # (path, category) -> up to five line numbers; never stores matched values.
MAX_LINES_PER_FILE_CATEGORY = 5
files_seen = 0
files_content_scanned = 0
binary_skipped = 0
large_skipped = 0
read_errors = 0
oversized_line_skipped = 0
find_error_lines = 0
last_progress_time = time.monotonic()
find_rc_total = 0
scan_roots_checked = []
scan_roots_missing = []


def luhn_valid(digits):
    total = 0
    parity = len(digits) % 2
    for index, char in enumerate(digits):
        value = ord(char) - 48
        if index % 2 == parity:
            value *= 2
            if value > 9:
                value -= 9
        total += value
    return total % 10 == 0


def valid_ssn(match):
    area = match.group("area")
    group = match.group("group")
    serial = match.group("serial")
    return area not in {"000", "666"} and not area.startswith("9") and group != "00" and serial != "0000"


def line_has_ssn(line, csv_ssn_columns):
    """Detect formatted SSNs, labelled compact SSNs, and SSN CSV columns."""
    labelled = bool(ssn_label_pattern.search(line))
    for match in ssn_candidate_pattern.finditer(line):
        if not valid_ssn(match):
            continue
        has_separator = bool(match.group("sep1") or match.group("sep2"))
        if has_separator or labelled:
            return True

    # A compact 9-digit value is only a candidate when the same line labels it.
    if labelled:
        for match in re.finditer(r"(?<!\d)(\d{9})(?!\d)", line):
            digits = match.group(1)
            synthetic = type("SSNMatch", (), {
                "group": lambda self, name, d=digits: d[:3] if name == "area" else (d[3:5] if name == "group" else d[5:])
            })()
            if valid_ssn(synthetic):
                return True

    # CSV exports commonly put the SSN label in the header and values on later
    # rows. Keep only the delimiter and column indexes, never the cell values.
    for delimiter, indexes in csv_ssn_columns:
        try:
            row = next(csv.reader([line], delimiter=delimiter, strict=False))
        except (csv.Error, StopIteration):
            continue
        for index in indexes:
            if index < len(row):
                cell = row[index].strip()
                match = ssn_candidate_pattern.fullmatch(cell)
                if match and valid_ssn(match):
                    return True
                if re.fullmatch(r"\d{9}", cell):
                    digits = cell
                    area, group, serial = digits[:3], digits[3:5], digits[5:]
                    if area not in {"000", "666"} and not area.startswith("9") and group != "00" and serial != "0000":
                        return True
    return False


def discover_ssn_csv_columns(line):
    """Return potential SSN column indexes for a CSV-like header line."""
    for delimiter in (",", "\t", ";", "|"):
        try:
            row = next(csv.reader([line], delimiter=delimiter, strict=False))
        except (csv.Error, StopIteration):
            continue
        indexes = [i for i, cell in enumerate(row) if ssn_header_token_pattern.fullmatch(cell.strip().strip('"\''))]
        if indexes and len(row) > 1:
            return [(delimiter, indexes)]
    return []


def report_phone_matches(line):
    matches = set()
    has_phone_context = bool(context_phone_pattern.search(line))
    for pattern in (us_phone_pattern, intl_phone_pattern):
        for match in pattern.finditer(line):
            value = match.group(0)
            digits = re.sub(r"\D", "", value)
            if not (8 <= len(digits) <= 15):
                continue
            # A plain 10-digit string is only accepted when explicitly labelled.
            formatted = any(char in value for char in " +-()./")
            if len(digits) == 10 and not formatted and not has_phone_context:
                continue
            if len(digits) == 11 and digits.startswith("1") and not formatted and not has_phone_context:
                continue
            matches.add(value)
    if has_phone_context:
        for match in context_number_pattern.finditer(line):
            value = match.group(0)
            digits = re.sub(r"\D", "", value)
            if 10 <= len(digits) <= 15:
                matches.add(value)
    return bool(matches)


def write_finding(report, category, path, line_number="n/a"):
    key = (path, category)
    if key not in findings:
        findings[key] = []
        counts[category] += 1
    if line_number != "n/a":
        lines = findings[key]
        if line_number not in lines and len(lines) < MAX_LINES_PER_FILE_CATEGORY:
            lines.append(line_number)


def scan_file(raw_path, report):
    global files_seen, files_content_scanned, binary_skipped, large_skipped
    global read_errors, oversized_line_skipped

    path = os.fsdecode(raw_path)
    files_seen += 1
    normalized = path.replace(os.sep, "/")
    base = os.path.basename(path)

    if pii_path_pattern.search(normalized):
        write_finding(report, "pii_related_path", path)
    if base in credential_path_names or normalized.endswith("/.aws/credentials"):
        write_finding(report, "common_credential_file", path)

    file_pii_fields = set()
    file_pii_values = set()
    try:
        file_size = os.stat(path, follow_symlinks=False).st_size
        if file_size > max_file_bytes:
            large_skipped += 1
            return

        with open(path, "rb") as stream:
            first = stream.read(8192)
            if b"\0" in first:
                binary_skipped += 1
                return
            stream.seek(0)
            files_content_scanned += 1
            inside_private_key = False
            line_number = 0
            ssn_csv_columns = []
            while True:
                # Bound memory for minified/one-line files.
                raw_line = stream.readline(1024 * 1024 + 1)
                if not raw_line:
                    break
                line_number += 1
                if len(raw_line) > 1024 * 1024:
                    oversized_line_skipped += 1
                    if not raw_line.endswith(b"\n"):
                        while True:
                            remainder = stream.readline(65536)
                            if not remainder or remainder.endswith(b"\n"):
                                break
                    continue

                line = raw_line.decode("utf-8", errors="replace")
                new_ssn_columns = discover_ssn_csv_columns(line)
                if new_ssn_columns:
                    ssn_csv_columns = new_ssn_columns
                if private_key_begin.search(line):
                    write_finding(report, "private_key_material", path, line_number)
                    inside_private_key = True
                    continue
                if inside_private_key:
                    if private_key_end.search(line):
                        inside_private_key = False
                    continue

                found_categories = set()
                pii_eligible = pii_scan_eligible(path)
                for category, pattern in content_patterns:
                    if pattern.search(line):
                        # Emails are PII indicators only in likely data locations.
                        if category == "email_address":
                            if not pii_eligible:
                                continue
                            emails = pattern.findall(line)
                            emails = [e for e in emails if not e.lower().endswith(("@example.com", "@example.net", "@example.org", ".example", ".invalid", ".test"))]
                            if not emails:
                                continue
                        found_categories.add(category)
                        if category == "email_address":
                            file_pii_values.add(category)

                # SSNs are checked across every selected scan root, not just
                # the narrower roots used for broad email/phone/number patterns.
                if line_has_ssn(line, ssn_csv_columns):
                    found_categories.add("ssn_pattern")
                    file_pii_values.add("ssn_pattern")

                if pii_eligible:
                    for match in card_candidate_pattern.finditer(line):
                        digits = re.sub(r"\D", "", match.group(0))
                        if 13 <= len(digits) <= 19 and len(set(digits)) > 1 and luhn_valid(digits):
                            found_categories.add("credit_card_like")
                            file_pii_values.add("credit_card_like")
                            break

                    if report_phone_matches(line):
                        found_categories.add("phone_number")
                        file_pii_values.add("phone_number")

                structured_file = pii_eligible and (
                    os.path.splitext(base)[1].lower() in structured_extensions
                    or bool(pii_path_pattern.search(normalized))
                )
                matched_pii_fields = []
                if structured_file:
                    for category, pattern in pii_field_patterns:
                        if pattern.search(line):
                            found_categories.add(category)
                            matched_pii_fields.append(category)
                            file_pii_fields.add(category)
                if len(matched_pii_fields) >= 2:
                    found_categories.add("pii_record_schema")

                for category in sorted(found_categories):
                    write_finding(report, category, path, line_number)

        if len(file_pii_fields) >= 3:
            write_finding(report, "pii_dataset_schema", path)
        if len(file_pii_values) >= 2:
            write_finding(report, "pii_dataset_content", path)
    except OSError:
        read_errors += 1


def build_find_command(root):
    # Each target uses -xdev relative to that target. This allows /home or
    # /mnt-style dedicated data partitions to be scanned when explicitly
    # selected, without traversing every unrelated mounted filesystem.
    command = ["find", root, "-xdev"]
    command += [
        "(", "-type", "d", "(",
        "-name", ".git", "-o", "-name", "node_modules", "-o",
        "-name", ".cache", "-o", "-name", "__pycache__", "-o",
        "-name", ".venv", "-o", "-name", "venv",
        ")", "-prune", ")", "-o",
        "(", "-path", "/var/log/journal", ")", "-prune", "-o",
        "(", "-path", final_report_path, "-o", "-path", script_path,
        "-o", "-path", workdir, ")", "-prune", "-o",
        "-type", "f", "-print0",
    ]
    return command


def emit_progress(waiting=False):
    global last_progress_time
    now = time.monotonic()
    if waiting:
        print(
            f"[INFO] Still traversing/scanning; {files_seen} files discovered so far "
            f"({files_content_scanned} content-scanned).",
            flush=True,
        )
    else:
        print(
            f"[INFO] Progress: {files_seen} files discovered; "
            f"{files_content_scanned} content-scanned; {large_skipped} oversized; "
            f"{binary_skipped} binary.",
            flush=True,
        )
    last_progress_time = now


with open(report_path, "w", encoding="utf-8", newline="\n") as report:
    report.write("SENSITIVE DATA DISCOVERY REPORT\n")
    report.write("=" * 72 + "\n")
    report.write(f"Generated (UTC): {datetime.now(timezone.utc).isoformat(timespec='seconds')}\n")
    report.write("Mode: read-only discovery; no credentials, PII values, or matched contents are recorded\n")
    report.write(f"Maximum content scan size: {max_mb_text} MiB per file\n")
    report.write("Excluded directory trees: .git, node_modules, .cache, __pycache__, .venv, venv, /var/log/journal\n")
    report.write("Each selected scan root is traversed only on its own filesystem (-xdev).\n")
    report.write("Large OS/application trees such as /usr, /opt, and /var/lib are outside the default scope.\n")
    report.write("SSN detection runs across every selected root; broad email/phone/card detection is limited to personal/data roots.\n")
    report.write("SSNs are recognized in hyphenated, spaced, dotted, and labelled compact forms; CSV SSN columns are tracked across rows.\n")
    report.write("Path/filename indicators are checked even for oversized or binary files.\n")
    report.write("Findings are indicators for manual investigation, not proof of exposed/valid data.\n\n")
    report.write("FINDINGS (path | category | line numbers; maximum five line numbers shown per file/category)\n")
    report.write("-" * 72 + "\n")
    report.flush()

    if scan_root != "/":
        candidate_roots = [scan_root]
    else:
        candidate_roots = DEFAULT_SCAN_ROOTS

    with open(find_errors_path, "wb") as find_error_stream:
        for root in candidate_roots:
            real_root = os.path.realpath(root)
            if not os.path.isdir(real_root):
                scan_roots_missing.append(root)
                continue
            # Resolve command-line symlinks before invoking find (find does
            # not recurse through a starting symlink by default). Also avoid
            # duplicate traversal when two configured paths resolve alike.
            if any(real_root == old for old in scan_roots_checked):
                continue
            scan_roots_checked.append(real_root)
            display_root = root if root == real_root else f"{root} -> {real_root}"
            print(f"[INFO] Scanning location: {display_root}", flush=True)
            find_rc = 0
            try:
                proc = subprocess.Popen(
                    build_find_command(real_root),
                    stdout=subprocess.PIPE,
                    stderr=find_error_stream,
                    bufsize=0,
                )
                assert proc.stdout is not None
                fd = proc.stdout.fileno()
                pending = bytearray()
                last_progress_time = time.monotonic()

                while True:
                    ready, _, _ = select.select([fd], [], [], 5.0)
                    if not ready:
                        if proc.poll() is None:
                            emit_progress(waiting=True)
                            continue
                        chunk = os.read(fd, 65536)
                        if not chunk:
                            break
                    else:
                        chunk = os.read(fd, 65536)
                        if not chunk:
                            break

                    pending.extend(chunk)
                    while True:
                        separator = pending.find(0)
                        if separator < 0:
                            break
                        raw_path = bytes(pending[:separator])
                        del pending[:separator + 1]
                        if raw_path:
                            scan_file(raw_path, report)
                            if files_seen == 1:
                                print("[INFO] First file discovered; content scanning is active.", flush=True)
                            if files_seen % 500 == 0:
                                emit_progress()
                            elif time.monotonic() - last_progress_time >= 5.0:
                                emit_progress()

                if pending:
                    scan_file(bytes(pending), report)
                    pending.clear()
                find_rc = proc.wait()
            except OSError as exc:
                find_rc = 1
                print(f"[WARN] Could not scan {root}: {type(exc).__name__}", flush=True)

            find_rc_total = find_rc_total or find_rc
            report.flush()

    try:
        with open(find_errors_path, "r", encoding="utf-8", errors="replace") as errors_stream:
            find_error_lines = sum(1 for _ in errors_stream)
    except OSError:
        find_error_lines = 1

    for (finding_path, category), line_numbers in sorted(findings.items(), key=lambda item: (item[0][0], item[0][1])):
        line_text = ",".join(str(number) for number in line_numbers) if line_numbers else "n/a"
        report.write(f"{finding_path!r} | {category} | {line_text}\n")
    report.write(f"\nFiles with one or more indicators: {len({path for path, _ in findings})}\n")

    report.write("\nSCAN LOCATIONS CHECKED\n")
    report.write("-" * 72 + "\n")
    for root in scan_roots_checked:
        report.write(f"Scanned: {root}\n")
    for root in scan_roots_missing:
        report.write(f"Not present: {root}\n")
    if not scan_roots_checked:
        report.write("No configured scan locations were available.\n")

    report.write("\nSUMMARY (category totals are unique-file counts, not raw match counts)\n")
    report.write("-" * 72 + "\n")
    report.write(f"Files enumerated: {files_seen}\n")
    report.write(f"Files content-scanned: {files_content_scanned}\n")
    report.write(f"Oversized files skipped for content: {large_skipped}\n")
    report.write(f"Binary files skipped for content: {binary_skipped}\n")
    report.write(f"Oversized lines skipped: {oversized_line_skipped}\n")
    report.write(f"File read/stat errors: {read_errors}\n")
    report.write(f"Find exit status: {find_rc_total}\n")
    report.write(f"Find diagnostic lines: {find_error_lines}\n")
    for category, _ in content_patterns:
        report.write(f"{category}: {counts[category]} unique files\n")
    for category in ("ssn_pattern", "credit_card_like", "phone_number"):
        report.write(f"{category}: {counts[category]} unique files\n")
    for category, _ in pii_field_patterns:
        report.write(f"{category}: {counts[category]} unique files\n")
    for category in ("pii_record_schema", "pii_dataset_schema", "pii_dataset_content", "pii_related_path", "private_key_material", "common_credential_file"):
        report.write(f"{category}: {counts[category]} unique files\n")

    incomplete = bool(find_rc_total or find_error_lines or read_errors or large_skipped or binary_skipped or oversized_line_skipped)
    if incomplete:
        report.write("Coverage status: PARTIAL - review skipped-file counts and scan errors before relying on this report.\n")
    else:
        report.write("Coverage status: COMPLETE for the configured locations and file-size limit.\n")
    report.write("\nNo matched line contents, secret values, tokens, private-key blocks, or PII values are included.\n")

print(f"Files enumerated: {files_seen}")
print(f"Files content-scanned: {files_content_scanned}")
print(f"Oversized files skipped for content: {large_skipped}")
print(f"Binary files skipped for content: {binary_skipped}")
print(f"Oversized lines skipped: {oversized_line_skipped}")
print(f"File read/stat errors: {read_errors}")
print(f"Find exit status: {find_rc_total}; diagnostic lines: {find_error_lines}")
print("Finding counts (unique files per category; not raw match counts):")
for category, _ in content_patterns:
    print(f"  {category}: {counts[category]} unique files")
for category in ("ssn_pattern", "credit_card_like", "phone_number"):
    print(f"  {category}: {counts[category]} unique files")
for category, _ in pii_field_patterns:
    print(f"  {category}: {counts[category]} unique files")
for category in ("pii_record_schema", "pii_dataset_schema", "pii_dataset_content", "pii_related_path", "private_key_material", "common_credential_file"):
    print(f"  {category}: {counts[category]} unique files")

scan_status = "PARTIAL" if (find_rc_total or find_error_lines or read_errors or large_skipped or binary_skipped or oversized_line_skipped) else "COMPLETE"
with open(status_path, "w", encoding="ascii") as status_stream:
    status_stream.write(scan_status + "\n")
print(scan_status, flush=True)
PY
  then
    rm -rf -- "$workdir"
    umask "$old_umask"
    sdd_error 'The discovery scanner failed; no report was installed.'
    return 1
  fi

  if ! install -o root -g root -m 0600 -- "$report_tmp" "$report"; then
    rm -rf -- "$workdir"
    umask "$old_umask"
    sdd_error "Could not safely install the report at $report."
    return 1
  fi
  chmod 0600 "$report" || {
    rm -rf -- "$workdir"
    umask "$old_umask"
    sdd_error "Could not enforce mode 0600 on $report."
    return 1
  }

  scanner_status="$(cat "$scanner_status_file" 2>/dev/null || printf 'PARTIAL')"
  rm -rf -- "$workdir"
  umask "$old_umask"

  printf '\n'
  sdd_pass "Discovery report saved to $report"
  sdd_pass 'Report ownership and permissions: root:root 0600.'
  sdd_info 'The console and report contain only file paths, match categories, line numbers, and counts - no matched content.'

  if [[ "$scanner_status" != "COMPLETE" ]]; then
    sdd_warn 'The scan was partial because files/lines were skipped or filesystem errors occurred. Review the report summary.'
    return 1
  fi
  return 0
}

if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
  invoke_sensitive_data_discovery
fi
